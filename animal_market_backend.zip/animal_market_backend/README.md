# 🐐 بيع حيوانات — Backend (Django REST API)

Backend كامل لتطبيق بيع وشراء الحيوانات والمواشي والطيور في العراق.
يوفّر REST API + WebSocket (دردشة وإشعارات فورية) + تخزين صور عبر Cloudinary.

## 🧱 التقنيات
- Python 3.12 + Django 5 + Django REST Framework
- PostgreSQL
- Django Channels (WebSocket) + Redis
- Cloudinary لتخزين الصور
- JWT Authentication + Email OTP
- Swagger / ReDoc لتوثيق API

## 📂 هيكل المشروع
```
animal_market_backend/
├── config/                # الإعدادات، urls، asgi/wsgi
├── apps/
│   ├── accounts/          # المستخدمون، OTP، المتابعة، التقييم، الحظر
│   ├── core/               # المحافظات، تصنيفات الحيوانات، إحصائيات الإدارة
│   ├── animals/            # الإعلانات، الصور، الإعجابات، التعليقات، المفضلة، التبليغ
│   ├── chat/                # المحادثات + WebSocket Consumer
│   └── notifications/      # الإشعارات + WebSocket Consumer
├── requirements.txt
├── docker-compose.yml
├── Dockerfile
└── .env.example
```

## ⚙️ التشغيل محلياً (بدون Docker)

### 1) المتطلبات الأساسية
- Python 3.12+
- PostgreSQL 14+ (قيد التشغيل محلياً)
- Redis (قيد التشغيل محلياً — مطلوب لـ Channels)

### 2) إنشاء بيئة افتراضية وتثبيت المكتبات
```bash
python -m venv venv
source venv/bin/activate        # على Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3) إعداد متغيرات البيئة
```bash
cp .env.example .env
# ثم عدّل القيم داخل .env: بيانات PostgreSQL، Redis، Cloudinary، بريد SMTP
```

### 4) إنشاء قاعدة البيانات في PostgreSQL
```sql
CREATE DATABASE animal_market_db;
```

### 5) تطبيق الـ Migrations (جاهزة مسبقاً - لا حاجة لـ makemigrations)
ملفات الـ migrations الأولية مكتوبة ومرفقة بالفعل مع المشروع (`apps/*/migrations/0001_initial.py`)
ومطابقة تماماً للموديلات. فقط طبّقها على قاعدة البيانات:
```bash
python manage.py migrate
```
> ملاحظة: إذا عدّلت أي موديل لاحقاً، استخدم `python manage.py makemigrations` كالمعتاد لتوليد migration جديدة.

### 6) تعبئة البيانات الأساسية (المحافظات + تصنيفات الحيوانات)
```bash
python manage.py seed_core_data
```

### 7) إنشاء حساب مدير للوصول إلى لوحة الإدارة
```bash
python manage.py createsuperuser
```

### 8) تشغيل السيرفر (يدعم HTTP + WebSocket معاً عبر Daphne)
```bash
daphne -b 0.0.0.0 -p 8000 config.asgi:application
```
أو أثناء التطوير فقط (بدون WebSocket):
```bash
python manage.py runserver
```

الآن المشروع يعمل على: `http://127.0.0.1:8000`

## 🐳 التشغيل عبر Docker (أسهل طريقة)
```bash
cp .env.example .env   # وعدّل القيم
docker-compose up --build
```
سيقوم Docker Compose بتشغيل PostgreSQL و Redis و Django تلقائياً.
بعدها نفّذ داخل الحاوية:
```bash
docker-compose exec web python manage.py migrate
docker-compose exec web python manage.py seed_core_data
docker-compose exec web python manage.py createsuperuser
```

## 🔗 الروابط المهمة
| الوصف | الرابط |
|---|---|
| لوحة الإدارة (Admin) | `/admin/` |
| توثيق Swagger | `/api/docs/` |
| توثيق ReDoc | `/api/redoc/` |
| تسجيل حساب جديد | `POST /api/accounts/register/` |
| التحقق من OTP | `POST /api/accounts/verify-otp/` |
| تسجيل الدخول | `POST /api/accounts/login/` |
| قائمة المحافظات | `GET /api/core/governorates/` |
| قائمة تصنيفات الحيوانات | `GET /api/core/categories/` |
| الإعلانات (الصفحة الرئيسية) | `GET /api/animals/` |
| إضافة إعلان | `POST /api/animals/` |
| إعجاب بإعلان | `POST /api/animals/{id}/like/` |
| تعليقات إعلان | `GET/POST /api/animals/{id}/comments/` |
| حفظ في المفضلة | `POST /api/animals/{id}/save/` |
| التبليغ عن إعلان | `POST /api/animals/{id}/report/` |
| متابعة بائع | `POST /api/accounts/users/{id}/follow/` |
| تقييم بائع | `POST /api/accounts/users/{id}/rate/` |
| قائمة المحادثات | `GET /api/chat/conversations/` |
| بدء محادثة | `POST /api/chat/conversations/start/` |
| رسائل محادثة | `GET /api/chat/conversations/{id}/messages/` |
| رفع صورة للدردشة | `POST /api/chat/upload-image/` (multipart، حقل `image`) → يرجع `{"url": "..."}` |
| WebSocket دردشة | `ws://host/ws/chat/{conversation_id}/?token=<access_token>` |
| WebSocket إشعارات | `ws://host/ws/notifications/?token=<access_token>` |
| إحصائيات الإدارة | `GET /api/core/admin/stats/` (staff فقط) |

## 🔐 المصادقة (Authentication)
1. `POST /api/accounts/register/` — التسجيل بالبريد + كلمة المرور
2. يصل رمز OTP إلى البريد (في وضع `DEBUG=True` يُطبع الرمز في الطرفية بدل الإرسال الفعلي)
3. `POST /api/accounts/verify-otp/` — يُفعّل الحساب ويُعيد `access` و`refresh` token
4. أرسل التوكن في كل طلب: `Authorization: Bearer <access_token>`
5. لتجديد التوكن: `POST /api/accounts/token/refresh/`

## 💬 الدردشة الفورية عبر WebSocket
الاتصال:
```
ws://127.0.0.1:8000/ws/chat/<conversation_id>/?token=<access_token>
```
إرسال رسالة نصية:
```json
{"type": "message", "message_type": "text", "text": "السلام عليكم، هل الحيوان متوفر؟"}
```
إشعار الكتابة الآن:
```json
{"type": "typing"}
```
تصنيف الرسائل كمقروءة:
```json
{"type": "read"}
```

## 🖼️ رفع الصور
- الإعلانات: أرسل الصور كـ `multipart/form-data` بالحقل `uploaded_images` (حتى 10 صور) عند `POST /api/animals/`
- تُخزَّن الصور تلقائياً على Cloudinary حسب إعدادات `.env`
- الدردشة: ارفع الصورة أولاً عبر `POST /api/chat/upload-image/` (حقل `image`)، ثم أرسل الرابط الناتج
  كرسالة عبر WebSocket بالشكل: `{"type": "message", "message_type": "image", "image_url": "<الرابط>"}`

## 🛠️ لوحة الإدارة (Django Admin)
من `/admin/` يمكن للمشرف:
- إدارة المستخدمين وحظرهم
- حذف/إخفاء الإعلانات المخالفة
- مراجعة التبليغات (Reports) واتخاذ إجراء مباشر
- استعراض كل المحادثات والرسائل والتعليقات

## 📌 ملاحظات مهمة قبل الإنتاج (Production)
- غيّر `SECRET_KEY` وفعّل `DEBUG=False`
- اضبط `ALLOWED_HOSTS` و`CORS_ALLOWED_ORIGINS` على نطاقك الفعلي
- استخدم بريد SMTP حقيقي (Gmail App Password أو مزود مثل SendGrid) لإرسال OTP فعلياً
- استخدم `gunicorn`/`daphne` خلف Nginx في الإنتاج، وفعّل HTTPS
- فعّل نسخ احتياطي دوري لقاعدة بيانات PostgreSQL
