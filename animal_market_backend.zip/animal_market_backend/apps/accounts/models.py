import random
from datetime import timedelta

from django.conf import settings
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.utils import timezone


class UserManager(BaseUserManager):
    """مدير المستخدمين - التسجيل بالبريد الإلكتروني فقط (بدون username)"""

    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('البريد الإلكتروني مطلوب')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_verified', True)
        return self.create_user(email, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    """المستخدم الأساسي - يسجّل الدخول عبر البريد الإلكتروني فقط"""
    email = models.EmailField('البريد الإلكتروني', unique=True)
    username = models.CharField('اسم المستخدم', max_length=50, unique=True)
    phone_number = models.CharField('رقم الهاتف', max_length=20, blank=True)

    is_verified = models.BooleanField('تم التحقق من البريد', default=False)
    is_active = models.BooleanField('نشط', default=True)
    is_staff = models.BooleanField('موظف إداري', default=False)
    is_banned = models.BooleanField('محظور', default=False)
    ban_reason = models.TextField('سبب الحظر', blank=True)

    date_joined = models.DateTimeField('تاريخ الانضمام', auto_now_add=True)

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    class Meta:
        verbose_name = 'مستخدم'
        verbose_name_plural = 'المستخدمون'
        ordering = ['-date_joined']

    def __str__(self):
        return f'{self.username} ({self.email})'


class Profile(models.Model):
    """الملف الشخصي للمستخدم"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile', verbose_name='المستخدم')
    avatar = models.ImageField('الصورة الشخصية', upload_to='avatars/', blank=True, null=True)
    bio = models.TextField('نبذة تعريفية', max_length=500, blank=True)
    governorate = models.ForeignKey(
        'core.Governorate', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='profiles', verbose_name='المحافظة'
    )
    rating_average = models.DecimalField('متوسط التقييم', max_digits=3, decimal_places=2, default=0)
    rating_count = models.PositiveIntegerField('عدد التقييمات', default=0)
    followers_count = models.PositiveIntegerField('عدد المتابعين', default=0)
    following_count = models.PositiveIntegerField('عدد المتابَعين', default=0)
    animals_count = models.PositiveIntegerField('عدد الإعلانات', default=0)
    created_at = models.DateTimeField('تاريخ الإنشاء', auto_now_add=True)
    updated_at = models.DateTimeField('تاريخ التحديث', auto_now=True)

    class Meta:
        verbose_name = 'ملف شخصي'
        verbose_name_plural = 'الملفات الشخصية'

    def __str__(self):
        return f'ملف {self.user.username}'


def generate_otp():
    return str(random.randint(100000, 999999))


class OTPVerification(models.Model):
    """رمز التحقق OTP المرسل عبر البريد الإلكتروني"""

    class Purpose(models.TextChoices):
        REGISTER = 'register', 'تفعيل الحساب'
        RESET_PASSWORD = 'reset_password', 'استعادة كلمة المرور'
        LOGIN = 'login', 'تسجيل دخول'

    email = models.EmailField('البريد الإلكتروني')
    code = models.CharField('الرمز', max_length=6, default=generate_otp)
    purpose = models.CharField('الغرض', max_length=20, choices=Purpose.choices, default=Purpose.REGISTER)
    is_used = models.BooleanField('تم استخدامه', default=False)
    created_at = models.DateTimeField('تاريخ الإنشاء', auto_now_add=True)
    expires_at = models.DateTimeField('تاريخ الانتهاء')

    class Meta:
        verbose_name = 'رمز تحقق OTP'
        verbose_name_plural = 'رموز التحقق OTP'
        ordering = ['-created_at']

    def save(self, *args, **kwargs):
        if not self.expires_at:
            self.expires_at = timezone.now() + timedelta(minutes=settings.OTP_EXPIRY_MINUTES)
        super().save(*args, **kwargs)

    @property
    def is_expired(self):
        return timezone.now() > self.expires_at

    def __str__(self):
        return f'{self.email} - {self.code} ({self.get_purpose_display()})'


class Follow(models.Model):
    """متابعة بين المستخدمين (بائع/مشتري)"""
    follower = models.ForeignKey(User, on_delete=models.CASCADE, related_name='following', verbose_name='المتابِع')
    following = models.ForeignKey(User, on_delete=models.CASCADE, related_name='followers', verbose_name='المتابَع')
    created_at = models.DateTimeField('تاريخ المتابعة', auto_now_add=True)

    class Meta:
        verbose_name = 'متابعة'
        verbose_name_plural = 'المتابعات'
        unique_together = ('follower', 'following')

    def __str__(self):
        return f'{self.follower.username} يتابع {self.following.username}'


class SellerRating(models.Model):
    """تقييم البائعين من 1 إلى 5 نجوم"""
    seller = models.ForeignKey(User, on_delete=models.CASCADE, related_name='received_ratings', verbose_name='البائع')
    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='given_ratings', verbose_name='المقيّم')
    stars = models.PositiveSmallIntegerField('عدد النجوم')  # 1-5
    comment = models.CharField('تعليق', max_length=300, blank=True)
    created_at = models.DateTimeField('تاريخ التقييم', auto_now_add=True)

    class Meta:
        verbose_name = 'تقييم بائع'
        verbose_name_plural = 'تقييمات البائعين'
        unique_together = ('seller', 'buyer')

    def __str__(self):
        return f'{self.seller.username}: {self.stars} نجوم من {self.buyer.username}'


class BlockedUser(models.Model):
    """حظر المستخدمين لبعضهم البعض"""
    blocker = models.ForeignKey(User, on_delete=models.CASCADE, related_name='blocked_users', verbose_name='الحاظر')
    blocked = models.ForeignKey(User, on_delete=models.CASCADE, related_name='blocked_by', verbose_name='المحظور')
    created_at = models.DateTimeField('تاريخ الحظر', auto_now_add=True)

    class Meta:
        verbose_name = 'مستخدم محظور'
        verbose_name_plural = 'المستخدمون المحظورون'
        unique_together = ('blocker', 'blocked')

    def __str__(self):
        return f'{self.blocker.username} حظر {self.blocked.username}'
