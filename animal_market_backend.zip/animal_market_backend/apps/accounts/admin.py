from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, Profile, OTPVerification, Follow, SellerRating, BlockedUser


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """لوحة إدارة المستخدمين - تدعم البحث، الحظر، وعرض الإحصائيات"""
    list_display = ['email', 'username', 'is_verified', 'is_banned', 'is_staff', 'date_joined']
    list_filter = ['is_verified', 'is_banned', 'is_staff', 'is_active']
    search_fields = ['email', 'username']
    ordering = ['-date_joined']
    actions = ['ban_users', 'unban_users']

    fieldsets = (
        (None, {'fields': ('email', 'username', 'password')}),
        ('الصلاحيات', {'fields': ('is_active', 'is_staff', 'is_superuser', 'is_verified', 'groups', 'user_permissions')}),
        ('الحظر', {'fields': ('is_banned', 'ban_reason')}),
        ('تواريخ', {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = (
        (None, {'classes': ('wide',), 'fields': ('email', 'username', 'password1', 'password2')}),
    )
    readonly_fields = ['date_joined', 'last_login']

    @admin.action(description='حظر المستخدمين المحددين')
    def ban_users(self, request, queryset):
        queryset.update(is_banned=True)

    @admin.action(description='إلغاء حظر المستخدمين المحددين')
    def unban_users(self, request, queryset):
        queryset.update(is_banned=False)


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'governorate', 'animals_count', 'followers_count', 'rating_average']
    search_fields = ['user__username', 'user__email']
    list_filter = ['governorate']


@admin.register(OTPVerification)
class OTPVerificationAdmin(admin.ModelAdmin):
    list_display = ['email', 'code', 'purpose', 'is_used', 'created_at', 'expires_at']
    list_filter = ['purpose', 'is_used']
    search_fields = ['email']


@admin.register(Follow)
class FollowAdmin(admin.ModelAdmin):
    list_display = ['follower', 'following', 'created_at']
    search_fields = ['follower__username', 'following__username']


@admin.register(SellerRating)
class SellerRatingAdmin(admin.ModelAdmin):
    list_display = ['seller', 'buyer', 'stars', 'created_at']
    list_filter = ['stars']


@admin.register(BlockedUser)
class BlockedUserAdmin(admin.ModelAdmin):
    list_display = ['blocker', 'blocked', 'created_at']
