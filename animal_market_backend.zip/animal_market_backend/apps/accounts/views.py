from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import check_password
from django.utils import timezone
from rest_framework import generics, status, permissions, viewsets
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from drf_yasg.utils import swagger_auto_schema

from .models import Profile, OTPVerification, Follow, SellerRating, BlockedUser
from .serializers import (
    RegisterSerializer, VerifyOTPSerializer, ResendOTPSerializer, LoginSerializer,
    ForgotPasswordSerializer, ResetPasswordSerializer, ProfileSerializer,
    PublicProfileSerializer, ChangePasswordSerializer, SellerRatingSerializer,
)
from .utils import create_and_send_otp

User = get_user_model()


class RegisterView(generics.CreateAPIView):
    """
    POST /api/accounts/register/
    تسجيل حساب جديد بالبريد الإلكتروني - يرسل رمز OTP للتفعيل
    """
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        create_and_send_otp(user.email, OTPVerification.Purpose.REGISTER)
        return Response(
            {'message': 'تم إنشاء الحساب بنجاح، تم إرسال رمز التحقق إلى بريدك الإلكتروني', 'email': user.email},
            status=status.HTTP_201_CREATED,
        )


class VerifyOTPView(APIView):
    """
    POST /api/accounts/verify-otp/
    التحقق من رمز OTP وتفعيل الحساب (أو إتمام عملية استعادة كلمة المرور)
    """
    permission_classes = [permissions.AllowAny]

    @swagger_auto_schema(request_body=VerifyOTPSerializer)
    def post(self, request):
        serializer = VerifyOTPSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        otp = serializer.validated_data['otp_instance']
        otp.is_used = True
        otp.save(update_fields=['is_used'])

        if otp.purpose == OTPVerification.Purpose.REGISTER:
            User.objects.filter(email=otp.email).update(is_verified=True)
            user = User.objects.get(email=otp.email)
            refresh = RefreshToken.for_user(user)
            return Response({
                'message': 'تم تفعيل الحساب بنجاح',
                'access': str(refresh.access_token),
                'refresh': str(refresh),
            })

        return Response({'message': 'تم التحقق من الرمز بنجاح', 'reset_token': otp.code})


class ResendOTPView(APIView):
    """POST /api/accounts/resend-otp/ - إعادة إرسال رمز OTP"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = ResendOTPSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        create_and_send_otp(serializer.validated_data['email'], serializer.validated_data['purpose'])
        return Response({'message': 'تم إرسال رمز تحقق جديد إلى بريدك الإلكتروني'})


class LoginView(APIView):
    """POST /api/accounts/login/ - تسجيل الدخول بالبريد وكلمة المرور"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        tokens = serializer.get_tokens(user)
        return Response({
            'message': 'تم تسجيل الدخول بنجاح',
            **tokens,
            'user': {'id': user.id, 'username': user.username, 'email': user.email},
        })


class ForgotPasswordView(APIView):
    """POST /api/accounts/forgot-password/ - إرسال رمز OTP لاستعادة كلمة المرور"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = ForgotPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email']
        if not User.objects.filter(email=email).exists():
            return Response({'error': 'لا يوجد حساب بهذا البريد الإلكتروني'}, status=status.HTTP_404_NOT_FOUND)
        create_and_send_otp(email, OTPVerification.Purpose.RESET_PASSWORD)
        return Response({'message': 'تم إرسال رمز استعادة كلمة المرور إلى بريدك الإلكتروني'})


class ResetPasswordView(APIView):
    """POST /api/accounts/reset-password/ - تعيين كلمة مرور جديدة بعد التحقق من OTP"""
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = ResetPasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        try:
            otp = OTPVerification.objects.filter(
                email=data['email'], purpose=OTPVerification.Purpose.RESET_PASSWORD,
                code=data['code'], is_used=False,
            ).latest('created_at')
        except OTPVerification.DoesNotExist:
            return Response({'error': 'رمز التحقق غير صحيح'}, status=status.HTTP_400_BAD_REQUEST)

        if otp.is_expired:
            return Response({'error': 'انتهت صلاحية رمز التحقق'}, status=status.HTTP_400_BAD_REQUEST)

        user = User.objects.get(email=data['email'])
        user.set_password(data['new_password'])
        user.save(update_fields=['password'])
        otp.is_used = True
        otp.save(update_fields=['is_used'])

        return Response({'message': 'تم تغيير كلمة المرور بنجاح، يمكنك تسجيل الدخول الآن'})


class ChangePasswordView(APIView):
    """POST /api/accounts/change-password/ - تغيير كلمة المرور (للمستخدم المسجل دخوله)"""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = request.user
        if not check_password(serializer.validated_data['old_password'], user.password):
            return Response({'error': 'كلمة المرور الحالية غير صحيحة'}, status=status.HTTP_400_BAD_REQUEST)
        user.set_password(serializer.validated_data['new_password'])
        user.save(update_fields=['password'])
        return Response({'message': 'تم تغيير كلمة المرور بنجاح'})


class MyProfileView(generics.RetrieveUpdateAPIView):
    """
    GET/PUT/PATCH /api/accounts/me/
    عرض وتعديل الملف الشخصي للمستخدم الحالي (الصورة، الاسم، الوصف، المحافظة)
    """
    serializer_class = ProfileSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        profile, _ = Profile.objects.get_or_create(user=self.request.user)
        return profile


class PublicProfileView(generics.RetrieveAPIView):
    """
    GET /api/accounts/users/<id>/
    صفحة بائع عامة: صورة، إعلاناته، متابعيه، تقييمه
    """
    queryset = Profile.objects.select_related('user', 'governorate')
    serializer_class = PublicProfileSerializer
    permission_classes = [permissions.AllowAny]
    lookup_field = 'user_id'
    lookup_url_kwarg = 'user_id'


class FollowToggleView(APIView):
    """POST /api/accounts/users/<user_id>/follow/ - متابعة أو إلغاء متابعة مستخدم"""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, user_id):
        if request.user.id == user_id:
            return Response({'error': 'لا يمكنك متابعة نفسك'}, status=status.HTTP_400_BAD_REQUEST)
        target = generics.get_object_or_404(User, id=user_id)
        follow, created = Follow.objects.get_or_create(follower=request.user, following=target)

        if not created:
            follow.delete()
            Profile.objects.filter(user=target).update(followers_count=max(0, target.profile.followers_count - 1))
            Profile.objects.filter(user=request.user).update(
                following_count=max(0, request.user.profile.following_count - 1))
            return Response({'message': 'تم إلغاء المتابعة', 'is_following': False})

        Profile.objects.filter(user=target).update(followers_count=target.profile.followers_count + 1)
        Profile.objects.filter(user=request.user).update(following_count=request.user.profile.following_count + 1)
        return Response({'message': 'تمت المتابعة بنجاح', 'is_following': True})


class RateSellerView(generics.CreateAPIView):
    """POST /api/accounts/users/<user_id>/rate/ - تقييم بائع من 1 إلى 5 نجوم"""
    serializer_class = SellerRatingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def create(self, request, *args, **kwargs):
        seller_id = kwargs['user_id']
        if request.user.id == seller_id:
            return Response({'error': 'لا يمكنك تقييم نفسك'}, status=status.HTTP_400_BAD_REQUEST)

        data = request.data.copy()
        data['seller'] = seller_id
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        rating, created = SellerRating.objects.update_or_create(
            seller_id=seller_id, buyer=request.user,
            defaults={'stars': serializer.validated_data['stars'], 'comment': serializer.validated_data.get('comment', '')}
        )

        seller_profile = Profile.objects.get(user_id=seller_id)
        agg = SellerRating.objects.filter(seller_id=seller_id)
        seller_profile.rating_count = agg.count()
        seller_profile.rating_average = round(sum(r.stars for r in agg) / agg.count(), 2)
        seller_profile.save(update_fields=['rating_count', 'rating_average'])

        return Response({'message': 'تم إرسال التقييم بنجاح'}, status=status.HTTP_201_CREATED)


class BlockUserView(APIView):
    """POST /api/accounts/users/<user_id>/block/ - حظر مستخدم (لن تظهر رسائله أو إعلاناته)"""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, user_id):
        target = generics.get_object_or_404(User, id=user_id)
        block, created = BlockedUser.objects.get_or_create(blocker=request.user, blocked=target)
        if not created:
            block.delete()
            return Response({'message': 'تم إلغاء الحظر', 'is_blocked': False})
        return Response({'message': 'تم حظر المستخدم', 'is_blocked': True})
