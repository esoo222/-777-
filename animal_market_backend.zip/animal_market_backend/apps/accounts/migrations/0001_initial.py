from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion

import apps.accounts.models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('auth', '0012_alter_user_first_name_max_length'),
        ('core', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='User',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('password', models.CharField(max_length=128, verbose_name='password')),
                ('last_login', models.DateTimeField(blank=True, null=True, verbose_name='last login')),
                ('is_superuser', models.BooleanField(
                    default=False,
                    help_text='Designates that this user has all permissions without explicitly assigning them.',
                    verbose_name='superuser status',
                )),
                ('email', models.EmailField(max_length=254, unique=True, verbose_name='البريد الإلكتروني')),
                ('username', models.CharField(max_length=50, unique=True, verbose_name='اسم المستخدم')),
                ('phone_number', models.CharField(blank=True, max_length=20, verbose_name='رقم الهاتف')),
                ('is_verified', models.BooleanField(default=False, verbose_name='تم التحقق من البريد')),
                ('is_active', models.BooleanField(default=True, verbose_name='نشط')),
                ('is_staff', models.BooleanField(default=False, verbose_name='موظف إداري')),
                ('is_banned', models.BooleanField(default=False, verbose_name='محظور')),
                ('ban_reason', models.TextField(blank=True, verbose_name='سبب الحظر')),
                ('date_joined', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ الانضمام')),
                ('groups', models.ManyToManyField(
                    blank=True,
                    help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.',
                    related_name='user_set', related_query_name='user', to='auth.group', verbose_name='groups',
                )),
                ('user_permissions', models.ManyToManyField(
                    blank=True,
                    help_text='Specific permissions for this user.',
                    related_name='user_set', related_query_name='user', to='auth.permission', verbose_name='user permissions',
                )),
            ],
            options={
                'verbose_name': 'مستخدم',
                'verbose_name_plural': 'المستخدمون',
                'ordering': ['-date_joined'],
            },
            managers=[
                ('objects', apps.accounts.models.UserManager()),
            ],
        ),
        migrations.CreateModel(
            name='Profile',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('avatar', models.ImageField(blank=True, null=True, upload_to='avatars/', verbose_name='الصورة الشخصية')),
                ('bio', models.TextField(blank=True, max_length=500, verbose_name='نبذة تعريفية')),
                ('rating_average', models.DecimalField(decimal_places=2, default=0, max_digits=3, verbose_name='متوسط التقييم')),
                ('rating_count', models.PositiveIntegerField(default=0, verbose_name='عدد التقييمات')),
                ('followers_count', models.PositiveIntegerField(default=0, verbose_name='عدد المتابعين')),
                ('following_count', models.PositiveIntegerField(default=0, verbose_name='عدد المتابَعين')),
                ('animals_count', models.PositiveIntegerField(default=0, verbose_name='عدد الإعلانات')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ الإنشاء')),
                ('updated_at', models.DateTimeField(auto_now=True, verbose_name='تاريخ التحديث')),
                ('governorate', models.ForeignKey(
                    blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL,
                    related_name='profiles', to='core.governorate', verbose_name='المحافظة',
                )),
                ('user', models.OneToOneField(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='profile', to=settings.AUTH_USER_MODEL, verbose_name='المستخدم',
                )),
            ],
            options={
                'verbose_name': 'ملف شخصي',
                'verbose_name_plural': 'الملفات الشخصية',
            },
        ),
        migrations.CreateModel(
            name='OTPVerification',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('email', models.EmailField(max_length=254, verbose_name='البريد الإلكتروني')),
                ('code', models.CharField(default=apps.accounts.models.generate_otp, max_length=6, verbose_name='الرمز')),
                ('purpose', models.CharField(
                    choices=[('register', 'تفعيل الحساب'), ('reset_password', 'استعادة كلمة المرور'), ('login', 'تسجيل دخول')],
                    default='register', max_length=20, verbose_name='الغرض',
                )),
                ('is_used', models.BooleanField(default=False, verbose_name='تم استخدامه')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ الإنشاء')),
                ('expires_at', models.DateTimeField(verbose_name='تاريخ الانتهاء')),
            ],
            options={
                'verbose_name': 'رمز تحقق OTP',
                'verbose_name_plural': 'رموز التحقق OTP',
                'ordering': ['-created_at'],
            },
        ),
        migrations.CreateModel(
            name='Follow',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ المتابعة')),
                ('follower', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='following',
                    to=settings.AUTH_USER_MODEL, verbose_name='المتابِع',
                )),
                ('following', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='followers',
                    to=settings.AUTH_USER_MODEL, verbose_name='المتابَع',
                )),
            ],
            options={
                'verbose_name': 'متابعة',
                'verbose_name_plural': 'المتابعات',
                'unique_together': {('follower', 'following')},
            },
        ),
        migrations.CreateModel(
            name='SellerRating',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('stars', models.PositiveSmallIntegerField(verbose_name='عدد النجوم')),
                ('comment', models.CharField(blank=True, max_length=300, verbose_name='تعليق')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ التقييم')),
                ('buyer', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='given_ratings',
                    to=settings.AUTH_USER_MODEL, verbose_name='المقيّم',
                )),
                ('seller', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='received_ratings',
                    to=settings.AUTH_USER_MODEL, verbose_name='البائع',
                )),
            ],
            options={
                'verbose_name': 'تقييم بائع',
                'verbose_name_plural': 'تقييمات البائعين',
                'unique_together': {('seller', 'buyer')},
            },
        ),
        migrations.CreateModel(
            name='BlockedUser',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ الحظر')),
                ('blocked', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='blocked_by',
                    to=settings.AUTH_USER_MODEL, verbose_name='المحظور',
                )),
                ('blocker', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='blocked_users',
                    to=settings.AUTH_USER_MODEL, verbose_name='الحاظر',
                )),
            ],
            options={
                'verbose_name': 'مستخدم محظور',
                'verbose_name_plural': 'المستخدمون المحظورون',
                'unique_together': {('blocker', 'blocked')},
            },
        ),
    ]
