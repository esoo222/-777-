from django.core.mail import send_mail
from django.conf import settings
from .models import OTPVerification


def create_and_send_otp(email, purpose=OTPVerification.Purpose.REGISTER):
    """ينشئ رمز OTP جديد ويرسله عبر البريد الإلكتروني"""
    otp = OTPVerification.objects.create(email=email, purpose=purpose)

    subject_map = {
        OTPVerification.Purpose.REGISTER: 'تفعيل حسابك في تطبيق بيع حيوانات',
        OTPVerification.Purpose.RESET_PASSWORD: 'استعادة كلمة المرور - بيع حيوانات',
        OTPVerification.Purpose.LOGIN: 'رمز تسجيل الدخول - بيع حيوانات',
    }

    message = (
        f'مرحباً بك في تطبيق "بيع حيوانات"\n\n'
        f'رمز التحقق الخاص بك هو: {otp.code}\n\n'
        f'هذا الرمز صالح لمدة {settings.OTP_EXPIRY_MINUTES} دقائق فقط.\n'
        f'إذا لم تطلب هذا الرمز، يمكنك تجاهل هذه الرسالة.'
    )

    send_mail(
        subject=subject_map.get(purpose, 'رمز التحقق'),
        message=message,
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[email],
        fail_silently=False,
    )
    return otp
