from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from . import views

urlpatterns = [
    # المصادقة
    path('register/', views.RegisterView.as_view(), name='register'),
    path('verify-otp/', views.VerifyOTPView.as_view(), name='verify-otp'),
    path('resend-otp/', views.ResendOTPView.as_view(), name='resend-otp'),
    path('login/', views.LoginView.as_view(), name='login'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token-refresh'),
    path('forgot-password/', views.ForgotPasswordView.as_view(), name='forgot-password'),
    path('reset-password/', views.ResetPasswordView.as_view(), name='reset-password'),
    path('change-password/', views.ChangePasswordView.as_view(), name='change-password'),

    # الملف الشخصي
    path('me/', views.MyProfileView.as_view(), name='my-profile'),
    path('users/<int:user_id>/', views.PublicProfileView.as_view(), name='public-profile'),
    path('users/<int:user_id>/follow/', views.FollowToggleView.as_view(), name='follow-toggle'),
    path('users/<int:user_id>/rate/', views.RateSellerView.as_view(), name='rate-seller'),
    path('users/<int:user_id>/block/', views.BlockUserView.as_view(), name='block-user'),
]
