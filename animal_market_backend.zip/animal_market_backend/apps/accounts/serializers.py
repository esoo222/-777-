from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.utils import timezone
from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken

from apps.core.serializers import GovernorateSerializer
from .models import Profile, OTPVerification, Follow, SellerRating

User = get_user_model()


# ---------- التسجيل ----------
class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, validators=[validate_password])
    password_confirm = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['email', 'username', 'password', 'password_confirm']

    def validate(self, attrs):
        if attrs['password'] != attrs.pop('password_confirm'):
            raise serializers.ValidationError({'password_confirm': 'كلمتا المرور غير متطابقتين'})
        return attrs

    def create(self, validated_data):
        user = User.objects.create_user(
            email=validated_data['email'],
            username=validated_data['username'],
            password=validated_data['password'],
            is_active=True,
            is_verified=False,  # يحتاج تفعيل OTP
        )
        Profile.objects.create(user=user)
        return user


# ---------- التحقق من OTP ----------
class VerifyOTPSerializer(serializers.Serializer):
    email = serializers.EmailField()
    code = serializers.CharField(max_length=6)
    purpose = serializers.ChoiceField(choices=OTPVerification.Purpose.choices, default=OTPVerification.Purpose.REGISTER)

    def validate(self, attrs):
        try:
            otp = OTPVerification.objects.filter(
                email=attrs['email'], purpose=attrs['purpose'], is_used=False
            ).latest('created_at')
        except OTPVerification.DoesNotExist:
            raise serializers.ValidationError('لم يتم إرسال رمز تحقق لهذا البريد')

        if otp.code != attrs['code']:
            raise serializers.ValidationError('رمز التحقق غير صحيح')
        if otp.is_expired:
            raise serializers.ValidationError('انتهت صلاحية رمز التحقق، يرجى طلب رمز جديد')

        attrs['otp_instance'] = otp
        return attrs


class ResendOTPSerializer(serializers.Serializer):
    email = serializers.EmailField()
    purpose = serializers.ChoiceField(choices=OTPVerification.Purpose.choices, default=OTPVerification.Purpose.REGISTER)


# ---------- تسجيل الدخول ----------
class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        from django.contrib.auth import authenticate
        user = authenticate(email=attrs['email'], password=attrs['password'])
        if not user:
            raise serializers.ValidationError('البريد الإلكتروني أو كلمة المرور غير صحيحة')
        if user.is_banned:
            raise serializers.ValidationError('تم حظر هذا الحساب: ' + (user.ban_reason or ''))
        if not user.is_verified:
            raise serializers.ValidationError('يرجى تفعيل الحساب أولاً عبر رمز OTP المرسل لبريدك')
        attrs['user'] = user
        return attrs

    def get_tokens(self, user):
        refresh = RefreshToken.for_user(user)
        return {'refresh': str(refresh), 'access': str(refresh.access_token)}


# ---------- استعادة كلمة المرور ----------
class ForgotPasswordSerializer(serializers.Serializer):
    email = serializers.EmailField()


class ResetPasswordSerializer(serializers.Serializer):
    email = serializers.EmailField()
    code = serializers.CharField(max_length=6)
    new_password = serializers.CharField(write_only=True, validators=[validate_password])


# ---------- الملف الشخصي ----------
class ProfileSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username')
    email = serializers.EmailField(source='user.email', read_only=True)
    governorate_detail = GovernorateSerializer(source='governorate', read_only=True)
    is_following = serializers.SerializerMethodField()

    class Meta:
        model = Profile
        fields = [
            'id', 'username', 'email', 'avatar', 'bio', 'governorate', 'governorate_detail',
            'rating_average', 'rating_count', 'followers_count', 'following_count',
            'animals_count', 'is_following', 'created_at',
        ]
        read_only_fields = ['rating_average', 'rating_count', 'followers_count', 'following_count', 'animals_count']

    def get_is_following(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        return Follow.objects.filter(follower=request.user, following=obj.user).exists()

    def update(self, instance, validated_data):
        user_data = validated_data.pop('user', {})
        if 'username' in user_data:
            instance.user.username = user_data['username']
            instance.user.save(update_fields=['username'])
        return super().update(instance, validated_data)


class PublicProfileSerializer(ProfileSerializer):
    """نسخة عامة من الملف الشخصي تظهر لبقية المستخدمين عند زيارة صفحة بائع"""
    class Meta(ProfileSerializer.Meta):
        pass


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(write_only=True)
    new_password = serializers.CharField(write_only=True, validators=[validate_password])


class SellerRatingSerializer(serializers.ModelSerializer):
    buyer_username = serializers.CharField(source='buyer.username', read_only=True)

    class Meta:
        model = SellerRating
        fields = ['id', 'seller', 'buyer', 'buyer_username', 'stars', 'comment', 'created_at']
        read_only_fields = ['buyer']
