from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('animals', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Notification',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('notif_type', models.CharField(
                    choices=[
                        ('like', 'إعجاب'), ('comment', 'تعليق'), ('follow', 'متابعة'),
                        ('message', 'رسالة'), ('rating', 'تقييم'), ('system', 'إشعار نظام'),
                    ],
                    max_length=10, verbose_name='نوع الإشعار',
                )),
                ('message', models.CharField(max_length=255, verbose_name='نص الإشعار')),
                ('is_read', models.BooleanField(default=False, verbose_name='تمت القراءة')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ الإنشاء')),
                ('animal', models.ForeignKey(
                    blank=True, null=True, on_delete=django.db.models.deletion.CASCADE,
                    related_name='notifications', to='animals.animal', verbose_name='الإعلان المرتبط',
                )),
                ('recipient', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='notifications',
                    to=settings.AUTH_USER_MODEL, verbose_name='المستلم',
                )),
                ('sender', models.ForeignKey(
                    blank=True, null=True, on_delete=django.db.models.deletion.CASCADE,
                    related_name='sent_notifications', to=settings.AUTH_USER_MODEL, verbose_name='المرسل',
                )),
            ],
            options={
                'verbose_name': 'إشعار',
                'verbose_name_plural': 'الإشعارات',
                'ordering': ['-created_at'],
            },
        ),
    ]
