from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Notification
from .serializers import NotificationSerializer


class NotificationListView(generics.ListAPIView):
    """GET /api/notifications/ - كل إشعارات المستخدم الحالي"""
    serializer_class = NotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Notification.objects.filter(recipient=self.request.user).select_related('sender', 'sender__profile')


class MarkNotificationReadView(APIView):
    """POST /api/notifications/{id}/read/ - تصنيف إشعار كمقروء"""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        Notification.objects.filter(id=pk, recipient=request.user).update(is_read=True)
        return Response({'message': 'تم'})


class MarkAllReadView(APIView):
    """POST /api/notifications/read-all/ - تصنيف كل الإشعارات كمقروءة"""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        Notification.objects.filter(recipient=request.user, is_read=False).update(is_read=True)
        return Response({'message': 'تم تصنيف كل الإشعارات كمقروءة'})


class UnreadCountView(APIView):
    """GET /api/notifications/unread-count/ - عدد الإشعارات غير المقروءة (لعرضه كـ badge)"""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        count = Notification.objects.filter(recipient=request.user, is_read=False).count()
        return Response({'unread_count': count})
