from django.conf import settings
from django.db import models


class Notification(models.Model):
    """إشعار: إعجاب، تعليق، متابعة، رسالة جديدة"""

    class NotifType(models.TextChoices):
        LIKE = 'like', 'إعجاب'
        COMMENT = 'comment', 'تعليق'
        FOLLOW = 'follow', 'متابعة'
        MESSAGE = 'message', 'رسالة'
        RATING = 'rating', 'تقييم'
        SYSTEM = 'system', 'إشعار نظام'

    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications', verbose_name='المستلم'
    )
    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_notifications',
        null=True, blank=True, verbose_name='المرسل'
    )
    notif_type = models.CharField('نوع الإشعار', max_length=10, choices=NotifType.choices)
    animal = models.ForeignKey(
        'animals.Animal', on_delete=models.CASCADE, related_name='notifications',
        null=True, blank=True, verbose_name='الإعلان المرتبط'
    )
    message = models.CharField('نص الإشعار', max_length=255)
    is_read = models.BooleanField('تمت القراءة', default=False)
    created_at = models.DateTimeField('تاريخ الإنشاء', auto_now_add=True)

    class Meta:
        verbose_name = 'إشعار'
        verbose_name_plural = 'الإشعارات'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.get_notif_type_display()} إلى {self.recipient.username}'
