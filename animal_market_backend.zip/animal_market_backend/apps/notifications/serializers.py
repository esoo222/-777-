from rest_framework import serializers
from .models import Notification


class NotificationSerializer(serializers.ModelSerializer):
    sender_username = serializers.CharField(source='sender.username', read_only=True)
    sender_avatar = serializers.ImageField(source='sender.profile.avatar', read_only=True)

    class Meta:
        model = Notification
        fields = ['id', 'notif_type', 'sender', 'sender_username', 'sender_avatar', 'animal', 'message', 'is_read', 'created_at']
