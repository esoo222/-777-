from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer


def create_notification(recipient, notif_type, message, sender=None, animal=None):
    """
    ينشئ إشعاراً في قاعدة البيانات ويبثّه فوراً للمستخدم إذا كان متصلاً عبر WebSocket
    (نتجنب استيراد الموديل في الأعلى لمنع الاستيراد الدائري بين التطبيقات)
    """
    from .models import Notification

    notification = Notification.objects.create(
        recipient=recipient, sender=sender, notif_type=notif_type, message=message, animal=animal,
    )

    channel_layer = get_channel_layer()
    if channel_layer:
        async_to_sync(channel_layer.group_send)(
            f'notifications_{recipient.id}',
            {
                'type': 'send_notification',
                'notification': {
                    'id': notification.id,
                    'notif_type': notif_type,
                    'message': message,
                    'sender': sender.username if sender else None,
                    'animal_id': animal.id if animal else None,
                    'created_at': notification.created_at.isoformat(),
                },
            },
        )
    return notification
