from django.contrib.auth import get_user_model
from django.db.models import Count, Sum
from django.utils import timezone
from datetime import timedelta
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser

from apps.animals.models import Animal, Report
from apps.chat.models import Message

User = get_user_model()


class AdminDashboardStatsView(APIView):
    """
    GET /api/core/admin/stats/
    إحصائيات عامة للوحة تحكم الإدارة: المستخدمون، الإعلانات، التبليغات، النشاط الأخير
    (متاح فقط للمشرفين is_staff)
    """
    permission_classes = [IsAdminUser]

    def get(self, request):
        now = timezone.now()
        last_7_days = now - timedelta(days=7)
        last_30_days = now - timedelta(days=30)

        data = {
            'users': {
                'total': User.objects.count(),
                'verified': User.objects.filter(is_verified=True).count(),
                'banned': User.objects.filter(is_banned=True).count(),
                'new_last_7_days': User.objects.filter(date_joined__gte=last_7_days).count(),
                'new_last_30_days': User.objects.filter(date_joined__gte=last_30_days).count(),
            },
            'animals': {
                'total': Animal.objects.count(),
                'active': Animal.objects.filter(status=Animal.Status.ACTIVE).count(),
                'sold': Animal.objects.filter(status=Animal.Status.SOLD).count(),
                'removed': Animal.objects.filter(status=Animal.Status.REMOVED).count(),
                'new_last_7_days': Animal.objects.filter(created_at__gte=last_7_days).count(),
                'by_category': list(
                    Animal.objects.values('category__name_ar').annotate(count=Count('id')).order_by('-count')
                ),
                'by_governorate': list(
                    Animal.objects.values('governorate__name_ar').annotate(count=Count('id')).order_by('-count')
                ),
            },
            'reports': {
                'total': Report.objects.count(),
                'pending': Report.objects.filter(status=Report.Status.PENDING).count(),
            },
            'messages': {
                'total': Message.objects.count(),
                'last_7_days': Message.objects.filter(created_at__gte=last_7_days).count(),
            },
        }
        return Response(data)
