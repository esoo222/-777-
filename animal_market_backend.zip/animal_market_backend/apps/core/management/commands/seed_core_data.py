"""
أمر Django لتعبئة قاعدة البيانات بالمحافظات وتصنيفات الحيوانات الافتراضية
الاستخدام: python manage.py seed_core_data
"""
from django.core.management.base import BaseCommand
from apps.core.models import Governorate, AnimalCategory, DEFAULT_CATEGORIES, DEFAULT_GOVERNORATES


class Command(BaseCommand):
    help = 'تعبئة قاعدة البيانات بالمحافظات وتصنيفات الحيوانات الافتراضية'

    def handle(self, *args, **options):
        created_gov = 0
        for i, name in enumerate(DEFAULT_GOVERNORATES):
            obj, created = Governorate.objects.get_or_create(name_ar=name, defaults={'order': i})
            created_gov += int(created)

        created_cat = 0
        for i, (name_ar, name_en, slug) in enumerate(DEFAULT_CATEGORIES):
            obj, created = AnimalCategory.objects.get_or_create(
                slug=slug, defaults={'name_ar': name_ar, 'name_en': name_en, 'order': i}
            )
            created_cat += int(created)

        self.stdout.write(self.style.SUCCESS(
            f'تمت الإضافة: {created_gov} محافظة جديدة، {created_cat} تصنيف جديد.'
        ))
