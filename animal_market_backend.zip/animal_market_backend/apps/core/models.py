from django.db import models


class Governorate(models.Model):
    """محافظات العراق الـ 18"""
    name_ar = models.CharField('الاسم بالعربية', max_length=100, unique=True)
    name_en = models.CharField('الاسم بالإنجليزية', max_length=100, blank=True)
    is_active = models.BooleanField('مفعّلة', default=True)
    order = models.PositiveSmallIntegerField('الترتيب', default=0)

    class Meta:
        verbose_name = 'محافظة'
        verbose_name_plural = 'المحافظات'
        ordering = ['order', 'name_ar']

    def __str__(self):
        return self.name_ar


class AnimalCategory(models.Model):
    """تصنيفات الحيوانات: أغنام، ماعز، أبقار... إلخ"""
    name_ar = models.CharField('الاسم بالعربية', max_length=100, unique=True)
    name_en = models.CharField('الاسم بالإنجليزية', max_length=100, blank=True)
    slug = models.SlugField('المعرّف', max_length=100, unique=True)
    icon = models.CharField('أيقونة (اسم أو رابط)', max_length=255, blank=True,
                             help_text='اسم أيقونة Flutter أو رابط صورة صغيرة')
    is_active = models.BooleanField('مفعّلة', default=True)
    order = models.PositiveSmallIntegerField('الترتيب', default=0)

    class Meta:
        verbose_name = 'تصنيف حيوان'
        verbose_name_plural = 'تصنيفات الحيوانات'
        ordering = ['order', 'name_ar']

    def __str__(self):
        return self.name_ar


# التصنيفات الافتراضية التي يتم إنشاؤها عبر data migration / fixture
DEFAULT_CATEGORIES = [
    ('أغنام', 'Sheep', 'sheep'),
    ('ماعز', 'Goats', 'goats'),
    ('أبقار', 'Cows', 'cows'),
    ('جاموس', 'Buffalo', 'buffalo'),
    ('خيول', 'Horses', 'horses'),
    ('إبل', 'Camels', 'camels'),
    ('دواجن', 'Poultry', 'poultry'),
    ('طيور', 'Birds', 'birds'),
    ('قطط', 'Cats', 'cats'),
    ('كلاب', 'Dogs', 'dogs'),
]

DEFAULT_GOVERNORATES = [
    'بغداد', 'البصرة', 'نينوى', 'أربيل', 'النجف', 'كربلاء', 'الأنبار',
    'ذي قار', 'ديالى', 'كركوك', 'واسط', 'ميسان', 'صلاح الدين',
    'القادسية', 'بابل', 'المثنى', 'دهوك', 'السليمانية',
]
