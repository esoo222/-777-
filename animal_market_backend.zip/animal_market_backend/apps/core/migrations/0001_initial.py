from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='Governorate',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name_ar', models.CharField(max_length=100, unique=True, verbose_name='الاسم بالعربية')),
                ('name_en', models.CharField(blank=True, max_length=100, verbose_name='الاسم بالإنجليزية')),
                ('is_active', models.BooleanField(default=True, verbose_name='مفعّلة')),
                ('order', models.PositiveSmallIntegerField(default=0, verbose_name='الترتيب')),
            ],
            options={
                'verbose_name': 'محافظة',
                'verbose_name_plural': 'المحافظات',
                'ordering': ['order', 'name_ar'],
            },
        ),
        migrations.CreateModel(
            name='AnimalCategory',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name_ar', models.CharField(max_length=100, unique=True, verbose_name='الاسم بالعربية')),
                ('name_en', models.CharField(blank=True, max_length=100, verbose_name='الاسم بالإنجليزية')),
                ('slug', models.SlugField(max_length=100, unique=True, verbose_name='المعرّف')),
                ('icon', models.CharField(
                    blank=True, max_length=255,
                    help_text='اسم أيقونة Flutter أو رابط صورة صغيرة',
                    verbose_name='أيقونة (اسم أو رابط)',
                )),
                ('is_active', models.BooleanField(default=True, verbose_name='مفعّلة')),
                ('order', models.PositiveSmallIntegerField(default=0, verbose_name='الترتيب')),
            ],
            options={
                'verbose_name': 'تصنيف حيوان',
                'verbose_name_plural': 'تصنيفات الحيوانات',
                'ordering': ['order', 'name_ar'],
            },
        ),
    ]
