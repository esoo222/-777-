from rest_framework import serializers
from .models import Governorate, AnimalCategory


class GovernorateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Governorate
        fields = ['id', 'name_ar', 'name_en', 'order']


class AnimalCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = AnimalCategory
        fields = ['id', 'name_ar', 'name_en', 'slug', 'icon', 'order']
