from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import GovernorateViewSet, AnimalCategoryViewSet
from .dashboard_views import AdminDashboardStatsView

router = DefaultRouter()
router.register('governorates', GovernorateViewSet, basename='governorate')
router.register('categories', AnimalCategoryViewSet, basename='animal-category')

urlpatterns = [
    path('admin/stats/', AdminDashboardStatsView.as_view(), name='admin-dashboard-stats'),
] + router.urls
