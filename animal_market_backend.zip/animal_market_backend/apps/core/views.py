from rest_framework import viewsets, permissions
from .models import Governorate, AnimalCategory
from .serializers import GovernorateSerializer, AnimalCategorySerializer


class GovernorateViewSet(viewsets.ReadOnlyModelViewSet):
    """
    قائمة محافظات العراق - للقراءة فقط
    GET /api/core/governorates/
    """
    queryset = Governorate.objects.filter(is_active=True)
    serializer_class = GovernorateSerializer
    permission_classes = [permissions.AllowAny]
    pagination_class = None


class AnimalCategoryViewSet(viewsets.ReadOnlyModelViewSet):
    """
    قائمة تصنيفات الحيوانات - للقراءة فقط
    GET /api/core/categories/
    """
    queryset = AnimalCategory.objects.filter(is_active=True)
    serializer_class = AnimalCategorySerializer
    permission_classes = [permissions.AllowAny]
    pagination_class = None
