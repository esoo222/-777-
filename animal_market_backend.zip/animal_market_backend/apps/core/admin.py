from django.contrib import admin
from .models import Governorate, AnimalCategory


@admin.register(Governorate)
class GovernorateAdmin(admin.ModelAdmin):
    list_display = ['name_ar', 'name_en', 'is_active', 'order']
    list_editable = ['is_active', 'order']
    search_fields = ['name_ar', 'name_en']


@admin.register(AnimalCategory)
class AnimalCategoryAdmin(admin.ModelAdmin):
    list_display = ['name_ar', 'name_en', 'slug', 'is_active', 'order']
    list_editable = ['is_active', 'order']
    prepopulated_fields = {'slug': ('name_en',)}
    search_fields = ['name_ar', 'name_en']
