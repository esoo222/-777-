from django.contrib import admin
from .models import Animal, AnimalImage, Comment, Like, Favorite, Report


class AnimalImageInline(admin.TabularInline):
    model = AnimalImage
    extra = 0


@admin.register(Animal)
class AnimalAdmin(admin.ModelAdmin):
    """إدارة الإعلانات - حذف المحتوى المخالف وتغيير الحالة"""
    list_display = ['name', 'seller', 'category', 'governorate', 'price', 'status', 'likes_count', 'created_at']
    list_filter = ['status', 'category', 'governorate', 'gender']
    search_fields = ['name', 'breed', 'seller__username', 'seller__email']
    list_editable = ['status']
    inlines = [AnimalImageInline]
    actions = ['mark_removed', 'mark_active']
    date_hierarchy = 'created_at'

    @admin.action(description='حذف الإعلانات المخالفة (إخفاء)')
    def mark_removed(self, request, queryset):
        queryset.update(status=Animal.Status.REMOVED)

    @admin.action(description='إعادة تفعيل الإعلانات')
    def mark_active(self, request, queryset):
        queryset.update(status=Animal.Status.ACTIVE)


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ['user', 'animal', 'text', 'created_at']
    search_fields = ['text', 'user__username']


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    """مراجعة التبليغات عن الإعلانات المخالفة"""
    list_display = ['animal', 'reporter', 'reason', 'status', 'created_at']
    list_filter = ['reason', 'status']
    list_editable = ['status']
    actions = ['mark_reviewed', 'remove_reported_animal']

    @admin.action(description='وضع علامة "تمت المراجعة"')
    def mark_reviewed(self, request, queryset):
        queryset.update(status=Report.Status.REVIEWED)

    @admin.action(description='حذف الإعلان المبلّغ عنه')
    def remove_reported_animal(self, request, queryset):
        for report in queryset:
            report.animal.status = Animal.Status.REMOVED
            report.animal.save(update_fields=['status'])
        queryset.update(status=Report.Status.REVIEWED)


admin.site.register(Like)
admin.site.register(Favorite)
