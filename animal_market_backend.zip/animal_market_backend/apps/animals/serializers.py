from rest_framework import serializers
from apps.core.serializers import AnimalCategorySerializer, GovernorateSerializer
from .models import Animal, AnimalImage, Comment, Like, Favorite, Report


class AnimalImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = AnimalImage
        fields = ['id', 'image', 'order', 'is_cover']


class SellerMiniSerializer(serializers.Serializer):
    """معلومات مختصرة عن البائع تُعرض مع كل إعلان (مثل إنستغرام)"""
    id = serializers.IntegerField(source='user.id')
    username = serializers.CharField(source='user.username')
    avatar = serializers.ImageField()
    rating_average = serializers.DecimalField(max_digits=3, decimal_places=2)


class CommentSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    avatar = serializers.ImageField(source='user.profile.avatar', read_only=True)

    class Meta:
        model = Comment
        fields = ['id', 'animal', 'user', 'username', 'avatar', 'text', 'created_at']
        read_only_fields = ['user']


class AnimalListSerializer(serializers.ModelSerializer):
    """للعرض في الصفحة الرئيسية (Feed) - مختصر وسريع"""
    cover_image = serializers.SerializerMethodField()
    category_name = serializers.CharField(source='category.name_ar', read_only=True)
    governorate_name = serializers.CharField(source='governorate.name_ar', read_only=True)
    seller_username = serializers.CharField(source='seller.username', read_only=True)
    seller_avatar = serializers.ImageField(source='seller.profile.avatar', read_only=True)
    is_liked = serializers.SerializerMethodField()
    is_saved = serializers.SerializerMethodField()

    class Meta:
        model = Animal
        fields = [
            'id', 'name', 'breed', 'age_value', 'age_unit', 'gender', 'price', 'is_negotiable',
            'governorate', 'governorate_name', 'category', 'category_name', 'status',
            'cover_image', 'seller', 'seller_username', 'seller_avatar',
            'likes_count', 'comments_count', 'saves_count', 'is_liked', 'is_saved', 'created_at',
        ]

    def get_cover_image(self, obj):
        cover = obj.images.filter(is_cover=True).first() or obj.images.first()
        return cover.image.url if cover else None

    def get_is_liked(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        return obj.likes.filter(user=request.user).exists()

    def get_is_saved(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        return obj.favorited_by.filter(user=request.user).exists()


class AnimalDetailSerializer(AnimalListSerializer):
    """تفاصيل الإعلان الكاملة مع كل الصور والوصف"""
    images = AnimalImageSerializer(many=True, read_only=True)
    category_detail = AnimalCategorySerializer(source='category', read_only=True)
    governorate_detail = GovernorateSerializer(source='governorate', read_only=True)

    class Meta(AnimalListSerializer.Meta):
        fields = AnimalListSerializer.Meta.fields + [
            'description', 'contact_phone', 'images', 'category_detail', 'governorate_detail', 'views_count', 'updated_at',
        ]


class AnimalCreateUpdateSerializer(serializers.ModelSerializer):
    """إنشاء/تعديل إعلان مع رفع حتى 10 صور"""
    uploaded_images = serializers.ListField(
        child=serializers.ImageField(), write_only=True, required=False, max_length=10,
        help_text='حتى 10 صور للإعلان'
    )

    class Meta:
        model = Animal
        fields = [
            'id', 'category', 'governorate', 'name', 'breed', 'age_value', 'age_unit',
            'gender', 'price', 'is_negotiable', 'description', 'contact_phone',
            'uploaded_images', 'status',
        ]
        read_only_fields = ['status']

    def validate_uploaded_images(self, value):
        if len(value) > 10:
            raise serializers.ValidationError('لا يمكن رفع أكثر من 10 صور')
        return value

    def create(self, validated_data):
        images = validated_data.pop('uploaded_images', [])
        animal = Animal.objects.create(seller=self.context['request'].user, **validated_data)
        self._save_images(animal, images)
        animal.seller.profile.animals_count += 1
        animal.seller.profile.save(update_fields=['animals_count'])
        return animal

    def update(self, instance, validated_data):
        images = validated_data.pop('uploaded_images', [])
        instance = super().update(instance, validated_data)
        if images:
            self._save_images(instance, images)
        return instance

    def _save_images(self, animal, images):
        start_order = animal.images.count()
        for i, img in enumerate(images):
            AnimalImage.objects.create(
                animal=animal, image=img, order=start_order + i,
                is_cover=(start_order + i == 0),
            )


class FavoriteSerializer(serializers.ModelSerializer):
    animal_detail = AnimalListSerializer(source='animal', read_only=True)

    class Meta:
        model = Favorite
        fields = ['id', 'animal', 'animal_detail', 'created_at']


class ReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = Report
        fields = ['id', 'animal', 'reason', 'details', 'status', 'created_at']
        read_only_fields = ['status']
