import django_filters
from .models import Animal


class AnimalFilter(django_filters.FilterSet):
    """فلاتر البحث المتقدم: المحافظة، السعر، النوع، العمر"""
    min_price = django_filters.NumberFilter(field_name='price', lookup_expr='gte')
    max_price = django_filters.NumberFilter(field_name='price', lookup_expr='lte')
    min_age = django_filters.NumberFilter(field_name='age_value', lookup_expr='gte')
    max_age = django_filters.NumberFilter(field_name='age_value', lookup_expr='lte')
    governorate = django_filters.NumberFilter(field_name='governorate_id')
    category = django_filters.NumberFilter(field_name='category_id')
    gender = django_filters.ChoiceFilter(choices=Animal.Gender.choices)

    class Meta:
        model = Animal
        fields = ['governorate', 'category', 'gender', 'min_price', 'max_price', 'min_age', 'max_age']
