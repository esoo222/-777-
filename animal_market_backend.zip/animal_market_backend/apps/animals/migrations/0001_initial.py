import cloudinary.models
import django.core.validators
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('core', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Animal',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=100, verbose_name='اسم الحيوان')),
                ('breed', models.CharField(blank=True, max_length=100, verbose_name='السلالة')),
                ('age_value', models.PositiveSmallIntegerField(verbose_name='العمر (رقم)')),
                ('age_unit', models.CharField(
                    choices=[('month', 'شهر'), ('year', 'سنة')], default='month', max_length=10, verbose_name='وحدة العمر',
                )),
                ('gender', models.CharField(choices=[('male', 'ذكر'), ('female', 'أنثى')], max_length=10, verbose_name='الجنس')),
                ('price', models.DecimalField(
                    decimal_places=0, max_digits=12,
                    validators=[django.core.validators.MinValueValidator(0)],
                    verbose_name='السعر (دينار عراقي)',
                )),
                ('is_negotiable', models.BooleanField(default=True, verbose_name='السعر قابل للتفاوض')),
                ('description', models.TextField(blank=True, max_length=2000, verbose_name='الوصف')),
                ('contact_phone', models.CharField(max_length=20, verbose_name='رقم التواصل')),
                ('status', models.CharField(
                    choices=[('active', 'متاح'), ('sold', 'تم البيع'), ('hidden', 'مخفي'), ('removed', 'محذوف من الإدارة')],
                    default='active', max_length=10, verbose_name='الحالة',
                )),
                ('likes_count', models.PositiveIntegerField(default=0, verbose_name='عدد الإعجابات')),
                ('comments_count', models.PositiveIntegerField(default=0, verbose_name='عدد التعليقات')),
                ('views_count', models.PositiveIntegerField(default=0, verbose_name='عدد المشاهدات')),
                ('saves_count', models.PositiveIntegerField(default=0, verbose_name='عدد مرات الحفظ')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ النشر')),
                ('updated_at', models.DateTimeField(auto_now=True, verbose_name='تاريخ التحديث')),
                ('category', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT, related_name='animals',
                    to='core.animalcategory', verbose_name='النوع',
                )),
                ('governorate', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT, related_name='animals',
                    to='core.governorate', verbose_name='المحافظة',
                )),
                ('seller', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='animals',
                    to=settings.AUTH_USER_MODEL, verbose_name='البائع',
                )),
            ],
            options={
                'verbose_name': 'إعلان حيوان',
                'verbose_name_plural': 'إعلانات الحيوانات',
                'ordering': ['-created_at'],
            },
        ),
        migrations.CreateModel(
            name='Report',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('reason', models.CharField(
                    choices=[
                        ('scam', 'احتيال / نصب'), ('fake', 'معلومات مزيفة'),
                        ('inappropriate', 'محتوى غير لائق'), ('sold', 'الحيوان تم بيعه بالفعل'), ('other', 'أخرى'),
                    ],
                    max_length=20, verbose_name='السبب',
                )),
                ('details', models.TextField(blank=True, verbose_name='تفاصيل إضافية')),
                ('status', models.CharField(
                    choices=[('pending', 'قيد المراجعة'), ('reviewed', 'تمت المراجعة'), ('dismissed', 'مرفوض')],
                    default='pending', max_length=10, verbose_name='حالة المراجعة',
                )),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ التبليغ')),
                ('animal', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='reports',
                    to='animals.animal', verbose_name='الإعلان',
                )),
                ('reporter', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='reports',
                    to=settings.AUTH_USER_MODEL, verbose_name='المبلّغ',
                )),
            ],
            options={
                'verbose_name': 'تبليغ',
                'verbose_name_plural': 'التبليغات',
                'ordering': ['-created_at'],
            },
        ),
        migrations.CreateModel(
            name='Like',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ الإعجاب')),
                ('animal', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='likes',
                    to='animals.animal', verbose_name='الإعلان',
                )),
                ('user', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='likes',
                    to=settings.AUTH_USER_MODEL, verbose_name='المستخدم',
                )),
            ],
            options={
                'verbose_name': 'إعجاب',
                'verbose_name_plural': 'الإعجابات',
                'unique_together': {('animal', 'user')},
            },
        ),
        migrations.CreateModel(
            name='Favorite',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ الحفظ')),
                ('animal', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='favorited_by',
                    to='animals.animal', verbose_name='الإعلان',
                )),
                ('user', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='favorites',
                    to=settings.AUTH_USER_MODEL, verbose_name='المستخدم',
                )),
            ],
            options={
                'verbose_name': 'مفضلة',
                'verbose_name_plural': 'المفضلات',
                'unique_together': {('animal', 'user')},
            },
        ),
        migrations.CreateModel(
            name='Comment',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('text', models.CharField(max_length=500, verbose_name='النص')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ التعليق')),
                ('animal', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='comments',
                    to='animals.animal', verbose_name='الإعلان',
                )),
                ('user', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='comments',
                    to=settings.AUTH_USER_MODEL, verbose_name='المستخدم',
                )),
            ],
            options={
                'verbose_name': 'تعليق',
                'verbose_name_plural': 'التعليقات',
                'ordering': ['-created_at'],
            },
        ),
        migrations.CreateModel(
            name='AnimalImage',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('image', cloudinary.models.CloudinaryField(max_length=255, verbose_name='الصورة')),
                ('order', models.PositiveSmallIntegerField(default=0, verbose_name='الترتيب')),
                ('is_cover', models.BooleanField(default=False, verbose_name='صورة الغلاف')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ الرفع')),
                ('animal', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='images',
                    to='animals.animal', verbose_name='الإعلان',
                )),
            ],
            options={
                'verbose_name': 'صورة حيوان',
                'verbose_name_plural': 'صور الحيوانات',
                'ordering': ['order'],
            },
        ),
        migrations.AddIndex(
            model_name='animal',
            index=models.Index(fields=['status', '-created_at'], name='animals_ani_status_9c1a3e_idx'),
        ),
        migrations.AddIndex(
            model_name='animal',
            index=models.Index(fields=['governorate', 'category'], name='animals_ani_governo_3f2b71_idx'),
        ),
    ]
