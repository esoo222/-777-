from django.conf import settings
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from cloudinary.models import CloudinaryField


class Animal(models.Model):
    """إعلان بيع حيوان"""

    class Gender(models.TextChoices):
        MALE = 'male', 'ذكر'
        FEMALE = 'female', 'أنثى'

    class Status(models.TextChoices):
        ACTIVE = 'active', 'متاح'
        SOLD = 'sold', 'تم البيع'
        HIDDEN = 'hidden', 'مخفي'
        REMOVED = 'removed', 'محذوف من الإدارة'

    seller = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='animals', verbose_name='البائع'
    )
    category = models.ForeignKey(
        'core.AnimalCategory', on_delete=models.PROTECT, related_name='animals', verbose_name='النوع'
    )
    governorate = models.ForeignKey(
        'core.Governorate', on_delete=models.PROTECT, related_name='animals', verbose_name='المحافظة'
    )

    name = models.CharField('اسم الحيوان', max_length=100)
    breed = models.CharField('السلالة', max_length=100, blank=True)
    age_value = models.PositiveSmallIntegerField('العمر (رقم)')
    age_unit = models.CharField('وحدة العمر', max_length=10, choices=[('month', 'شهر'), ('year', 'سنة')], default='month')
    gender = models.CharField('الجنس', max_length=10, choices=Gender.choices)
    price = models.DecimalField('السعر (دينار عراقي)', max_digits=12, decimal_places=0,
                                 validators=[MinValueValidator(0)])
    is_negotiable = models.BooleanField('السعر قابل للتفاوض', default=True)
    description = models.TextField('الوصف', max_length=2000, blank=True)
    contact_phone = models.CharField('رقم التواصل', max_length=20)

    status = models.CharField('الحالة', max_length=10, choices=Status.choices, default=Status.ACTIVE)

    likes_count = models.PositiveIntegerField('عدد الإعجابات', default=0)
    comments_count = models.PositiveIntegerField('عدد التعليقات', default=0)
    views_count = models.PositiveIntegerField('عدد المشاهدات', default=0)
    saves_count = models.PositiveIntegerField('عدد مرات الحفظ', default=0)

    created_at = models.DateTimeField('تاريخ النشر', auto_now_add=True)
    updated_at = models.DateTimeField('تاريخ التحديث', auto_now=True)

    class Meta:
        verbose_name = 'إعلان حيوان'
        verbose_name_plural = 'إعلانات الحيوانات'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status', '-created_at']),
            models.Index(fields=['governorate', 'category']),
        ]

    def __str__(self):
        return f'{self.name} - {self.seller.username}'


class AnimalImage(models.Model):
    """صور الإعلان - حتى 10 صور مخزّنة على Cloudinary"""
    animal = models.ForeignKey(Animal, on_delete=models.CASCADE, related_name='images', verbose_name='الإعلان')
    image = CloudinaryField('الصورة', folder='baihaywanat/animals')
    order = models.PositiveSmallIntegerField('الترتيب', default=0)
    is_cover = models.BooleanField('صورة الغلاف', default=False)
    created_at = models.DateTimeField('تاريخ الرفع', auto_now_add=True)

    class Meta:
        verbose_name = 'صورة حيوان'
        verbose_name_plural = 'صور الحيوانات'
        ordering = ['order']

    def __str__(self):
        return f'صورة {self.animal.name} #{self.order}'


class Comment(models.Model):
    """تعليق على إعلان"""
    animal = models.ForeignKey(Animal, on_delete=models.CASCADE, related_name='comments', verbose_name='الإعلان')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='comments', verbose_name='المستخدم')
    text = models.CharField('النص', max_length=500)
    created_at = models.DateTimeField('تاريخ التعليق', auto_now_add=True)

    class Meta:
        verbose_name = 'تعليق'
        verbose_name_plural = 'التعليقات'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.user.username}: {self.text[:30]}'


class Like(models.Model):
    """إعجاب بإعلان"""
    animal = models.ForeignKey(Animal, on_delete=models.CASCADE, related_name='likes', verbose_name='الإعلان')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='likes', verbose_name='المستخدم')
    created_at = models.DateTimeField('تاريخ الإعجاب', auto_now_add=True)

    class Meta:
        verbose_name = 'إعجاب'
        verbose_name_plural = 'الإعجابات'
        unique_together = ('animal', 'user')

    def __str__(self):
        return f'{self.user.username} أعجب بـ {self.animal.name}'


class Favorite(models.Model):
    """حفظ إعلان في المفضلة"""
    animal = models.ForeignKey(Animal, on_delete=models.CASCADE, related_name='favorited_by', verbose_name='الإعلان')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='favorites', verbose_name='المستخدم')
    created_at = models.DateTimeField('تاريخ الحفظ', auto_now_add=True)

    class Meta:
        verbose_name = 'مفضلة'
        verbose_name_plural = 'المفضلات'
        unique_together = ('animal', 'user')

    def __str__(self):
        return f'{self.user.username} حفظ {self.animal.name}'


class Report(models.Model):
    """تبليغ عن إعلان مخالف"""

    class Reason(models.TextChoices):
        SCAM = 'scam', 'احتيال / نصب'
        FAKE = 'fake', 'معلومات مزيفة'
        INAPPROPRIATE = 'inappropriate', 'محتوى غير لائق'
        SOLD = 'sold', 'الحيوان تم بيعه بالفعل'
        OTHER = 'other', 'أخرى'

    class Status(models.TextChoices):
        PENDING = 'pending', 'قيد المراجعة'
        REVIEWED = 'reviewed', 'تمت المراجعة'
        DISMISSED = 'dismissed', 'مرفوض'

    animal = models.ForeignKey(Animal, on_delete=models.CASCADE, related_name='reports', verbose_name='الإعلان')
    reporter = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reports', verbose_name='المبلّغ')
    reason = models.CharField('السبب', max_length=20, choices=Reason.choices)
    details = models.TextField('تفاصيل إضافية', blank=True)
    status = models.CharField('حالة المراجعة', max_length=10, choices=Status.choices, default=Status.PENDING)
    created_at = models.DateTimeField('تاريخ التبليغ', auto_now_add=True)

    class Meta:
        verbose_name = 'تبليغ'
        verbose_name_plural = 'التبليغات'
        ordering = ['-created_at']

    def __str__(self):
        return f'تبليغ عن {self.animal.name} من {self.reporter.username}'
