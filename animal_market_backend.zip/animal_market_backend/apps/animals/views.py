from django.db.models import F
from rest_framework import viewsets, permissions, status, generics
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.filters import SearchFilter, OrderingFilter
from django_filters.rest_framework import DjangoFilterBackend

from apps.notifications.utils import create_notification
from .models import Animal, Comment, Like, Favorite, Report
from .filters import AnimalFilter
from .serializers import (
    AnimalListSerializer, AnimalDetailSerializer, AnimalCreateUpdateSerializer,
    CommentSerializer, FavoriteSerializer, ReportSerializer,
)


class IsOwnerOrReadOnly(permissions.BasePermission):
    """صاحب الإعلان فقط يمكنه التعديل أو الحذف"""
    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        return obj.seller_id == request.user.id


class AnimalViewSet(viewsets.ModelViewSet):
    """
    /api/animals/
    - GET: قائمة الإعلانات (الصفحة الرئيسية) مع فلترة وبحث
    - POST: إضافة إعلان جديد (حتى 10 صور)
    - GET /{id}/: تفاصيل الإعلان
    - PUT/PATCH/DELETE /{id}/: تعديل أو حذف (لصاحب الإعلان فقط)
    """
    queryset = Animal.objects.filter(status=Animal.Status.ACTIVE).select_related(
        'seller', 'seller__profile', 'category', 'governorate'
    ).prefetch_related('images')
    permission_classes = [permissions.IsAuthenticatedOrReadOnly, IsOwnerOrReadOnly]
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = AnimalFilter
    search_fields = ['name', 'breed', 'description']
    ordering_fields = ['created_at', 'price', 'likes_count']
    ordering = ['-created_at']

    def get_serializer_class(self):
        if self.action == 'list':
            return AnimalListSerializer
        if self.action == 'retrieve':
            return AnimalDetailSerializer
        return AnimalCreateUpdateSerializer

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        Animal.objects.filter(pk=instance.pk).update(views_count=F('views_count') + 1)
        instance.refresh_from_db(fields=['views_count'])
        serializer = self.get_serializer(instance)
        return Response(serializer.data)

    def perform_destroy(self, instance):
        instance.seller.profile.animals_count = max(0, instance.seller.profile.animals_count - 1)
        instance.seller.profile.save(update_fields=['animals_count'])
        instance.delete()

    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def like(self, request, pk=None):
        """POST /api/animals/{id}/like/ - إعجاب / إلغاء إعجاب"""
        animal = self.get_object()
        like, created = Like.objects.get_or_create(animal=animal, user=request.user)
        if not created:
            like.delete()
            Animal.objects.filter(pk=animal.pk).update(likes_count=F('likes_count') - 1)
            return Response({'message': 'تم إلغاء الإعجاب', 'is_liked': False})

        Animal.objects.filter(pk=animal.pk).update(likes_count=F('likes_count') + 1)
        create_notification(
            recipient=animal.seller, sender=request.user, notif_type='like',
            animal=animal, message=f'{request.user.username} أعجب بإعلانك "{animal.name}"'
        )
        return Response({'message': 'تم الإعجاب', 'is_liked': True})

    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def save(self, request, pk=None):
        """POST /api/animals/{id}/save/ - حفظ الإعلان في المفضلة"""
        animal = self.get_object()
        fav, created = Favorite.objects.get_or_create(animal=animal, user=request.user)
        if not created:
            fav.delete()
            Animal.objects.filter(pk=animal.pk).update(saves_count=F('saves_count') - 1)
            return Response({'message': 'تمت الإزالة من المفضلة', 'is_saved': False})

        Animal.objects.filter(pk=animal.pk).update(saves_count=F('saves_count') + 1)
        return Response({'message': 'تم الحفظ في المفضلة', 'is_saved': True})

    @action(detail=True, methods=['get', 'post'], permission_classes=[permissions.IsAuthenticatedOrReadOnly])
    def comments(self, request, pk=None):
        """GET/POST /api/animals/{id}/comments/ - عرض أو إضافة تعليق"""
        animal = self.get_object()
        if request.method == 'GET':
            qs = animal.comments.select_related('user', 'user__profile')
            page = self.paginate_queryset(qs)
            serializer = CommentSerializer(page or qs, many=True)
            return self.get_paginated_response(serializer.data) if page is not None else Response(serializer.data)

        serializer = CommentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save(user=request.user, animal=animal)
        Animal.objects.filter(pk=animal.pk).update(comments_count=F('comments_count') + 1)
        create_notification(
            recipient=animal.seller, sender=request.user, notif_type='comment',
            animal=animal, message=f'{request.user.username} علّق على إعلانك "{animal.name}"'
        )
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def report(self, request, pk=None):
        """POST /api/animals/{id}/report/ - تبليغ عن إعلان مخالف"""
        animal = self.get_object()
        serializer = ReportSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save(animal=animal, reporter=request.user)
        return Response({'message': 'تم استلام تبليغك، سيتم مراجعته من قبل الإدارة'}, status=status.HTTP_201_CREATED)

    @action(detail=False, methods=['get'], permission_classes=[permissions.IsAuthenticated])
    def my_animals(self, request):
        """GET /api/animals/my_animals/ - إعلانات المستخدم الحالي"""
        qs = Animal.objects.filter(seller=request.user).select_related('category', 'governorate').prefetch_related('images')
        page = self.paginate_queryset(qs)
        serializer = AnimalListSerializer(page or qs, many=True, context={'request': request})
        return self.get_paginated_response(serializer.data) if page is not None else Response(serializer.data)


class CommentDeleteView(generics.DestroyAPIView):
    """DELETE /api/animals/comments/{id}/ - حذف تعليق (صاحب التعليق أو الإدارة)"""
    queryset = Comment.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        if self.request.user.is_staff:
            return Comment.objects.all()
        return Comment.objects.filter(user=self.request.user)

    def perform_destroy(self, instance):
        Animal.objects.filter(pk=instance.animal_id).update(comments_count=F('comments_count') - 1)
        instance.delete()


class FavoriteListView(generics.ListAPIView):
    """GET /api/animals/favorites/ - قائمة الإعلانات المحفوظة للمستخدم الحالي"""
    serializer_class = FavoriteSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Favorite.objects.filter(user=self.request.user).select_related('animal').order_by('-created_at')
