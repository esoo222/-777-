from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import AnimalViewSet, CommentDeleteView, FavoriteListView

router = DefaultRouter()
router.register('', AnimalViewSet, basename='animal')

urlpatterns = [
    path('comments/<int:pk>/', CommentDeleteView.as_view(), name='comment-delete'),
    path('favorites/', FavoriteListView.as_view(), name='favorite-list'),
] + router.urls
