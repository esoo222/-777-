import json
from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer
from django.utils import timezone


class ChatConsumer(AsyncWebsocketConsumer):
    """
    WebSocket للدردشة الفورية بين البائع والمشتري
    الاتصال: ws://<host>/ws/chat/<conversation_id>/?token=<jwt_access_token>

    الرسائل المُرسلة من العميل (JSON):
      {"type": "message", "text": "...", "message_type": "text"}
      {"type": "message", "image_url": "...", "message_type": "image"}
      {"type": "typing"}                     # المستخدم يكتب الآن
      {"type": "read"}                        # تصنيف الرسائل كمقروءة

    الرسائل المُرسلة من السيرفر:
      {"type": "message", "message": {...}}
      {"type": "typing", "user_id": ...}
      {"type": "read", "user_id": ...}
    """

    async def connect(self):
        self.user = self.scope['user']
        self.conversation_id = self.scope['url_route']['kwargs']['conversation_id']
        self.room_group_name = f'chat_{self.conversation_id}'

        if not self.user or not self.user.is_authenticated:
            await self.close(code=4001)
            return

        is_participant = await self.is_participant()
        if not is_participant:
            await self.close(code=4003)
            return

        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(self.room_group_name, self.channel_name)

    async def receive(self, text_data):
        data = json.loads(text_data)
        msg_type = data.get('type')

        if msg_type == 'message':
            message = await self.save_message(
                text=data.get('text', ''),
                message_type=data.get('message_type', 'text'),
                image_url=data.get('image_url'),
            )
            await self.channel_layer.group_send(self.room_group_name, {
                'type': 'chat_message',
                'message': message,
            })

        elif msg_type == 'typing':
            await self.channel_layer.group_send(self.room_group_name, {
                'type': 'typing_notification',
                'user_id': self.user.id,
                'username': self.user.username,
            })

        elif msg_type == 'read':
            await self.mark_as_read()
            await self.channel_layer.group_send(self.room_group_name, {
                'type': 'read_notification',
                'user_id': self.user.id,
            })

    # ---------- معالجات إرسال الأحداث للعميل ----------
    async def chat_message(self, event):
        await self.send(text_data=json.dumps({'type': 'message', 'message': event['message']}))

    async def typing_notification(self, event):
        if event['user_id'] != self.user.id:
            await self.send(text_data=json.dumps({'type': 'typing', 'user_id': event['user_id'], 'username': event['username']}))

    async def read_notification(self, event):
        if event['user_id'] != self.user.id:
            await self.send(text_data=json.dumps({'type': 'read', 'user_id': event['user_id']}))

    # ---------- عمليات قاعدة البيانات ----------
    @database_sync_to_async
    def is_participant(self):
        from .models import Conversation
        return Conversation.objects.filter(id=self.conversation_id, participants=self.user).exists()

    @database_sync_to_async
    def save_message(self, text, message_type, image_url):
        from .models import Conversation, Message
        from apps.notifications.utils import create_notification

        conversation = Conversation.objects.get(id=self.conversation_id)
        message = Message.objects.create(
            conversation=conversation, sender=self.user, text=text,
            message_type=message_type, image=image_url or None,
        )
        conversation.save()  # لتحديث updated_at

        other = conversation.participants.exclude(id=self.user.id).first()
        if other:
            create_notification(
                recipient=other, sender=self.user, notif_type='message',
                message=f'رسالة جديدة من {self.user.username}',
            )

        return {
            'id': message.id,
            'conversation': conversation.id,
            'sender': self.user.id,
            'sender_username': self.user.username,
            'text': message.text,
            'message_type': message.message_type,
            'image': message.image if message.image else None,
            'created_at': message.created_at.isoformat(),
        }

    @database_sync_to_async
    def mark_as_read(self):
        from .models import Conversation
        conversation = Conversation.objects.get(id=self.conversation_id)
        conversation.messages.filter(is_read=False).exclude(sender=self.user).update(
            is_read=True, read_at=timezone.now()
        )
