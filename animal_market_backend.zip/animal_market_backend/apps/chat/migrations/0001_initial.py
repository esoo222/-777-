from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('animals', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Conversation',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ الإنشاء')),
                ('updated_at', models.DateTimeField(auto_now=True, verbose_name='آخر نشاط')),
                ('animal', models.ForeignKey(
                    blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL,
                    related_name='conversations', to='animals.animal', verbose_name='الإعلان المرتبط',
                )),
                ('participants', models.ManyToManyField(
                    related_name='conversations', to=settings.AUTH_USER_MODEL, verbose_name='المشاركون',
                )),
            ],
            options={
                'verbose_name': 'محادثة',
                'verbose_name_plural': 'المحادثات',
                'ordering': ['-updated_at'],
            },
        ),
        migrations.CreateModel(
            name='Message',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('message_type', models.CharField(
                    choices=[('text', 'نص'), ('image', 'صورة')], default='text', max_length=10, verbose_name='نوع الرسالة',
                )),
                ('text', models.TextField(blank=True, verbose_name='النص')),
                ('image', models.URLField(blank=True, max_length=500, null=True, verbose_name='رابط الصورة')),
                ('is_read', models.BooleanField(default=False, verbose_name='تمت القراءة')),
                ('read_at', models.DateTimeField(blank=True, null=True, verbose_name='تاريخ القراءة')),
                ('created_at', models.DateTimeField(auto_now_add=True, verbose_name='تاريخ الإرسال')),
                ('conversation', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='messages',
                    to='chat.conversation', verbose_name='المحادثة',
                )),
                ('sender', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE, related_name='sent_messages',
                    to=settings.AUTH_USER_MODEL, verbose_name='المرسل',
                )),
            ],
            options={
                'verbose_name': 'رسالة',
                'verbose_name_plural': 'الرسائل',
                'ordering': ['created_at'],
            },
        ),
    ]
