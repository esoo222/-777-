from django.contrib.auth import get_user_model
from django.utils import timezone
from rest_framework import generics, permissions, status
from rest_framework.parsers import MultiPartParser
from rest_framework.response import Response
from rest_framework.views import APIView
from cloudinary.uploader import upload as cloudinary_upload

from .models import Conversation, Message
from .serializers import ConversationSerializer, MessageSerializer

User = get_user_model()


class ConversationListView(generics.ListAPIView):
    """GET /api/chat/conversations/ - قائمة محادثات المستخدم الحالي مرتبة حسب آخر نشاط"""
    serializer_class = ConversationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Conversation.objects.filter(participants=self.request.user).prefetch_related('participants', 'messages')


class StartConversationView(APIView):
    """
    POST /api/chat/conversations/start/
    body: {"user_id": <بائع>, "animal_id": <اختياري>}
    يبدأ محادثة جديدة أو يعيد المحادثة الموجودة مسبقاً بين نفس الطرفين
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        other_user_id = request.data.get('user_id')
        animal_id = request.data.get('animal_id')

        if not other_user_id or int(other_user_id) == request.user.id:
            return Response({'error': 'معرّف مستخدم غير صالح'}, status=status.HTTP_400_BAD_REQUEST)

        other_user = generics.get_object_or_404(User, id=other_user_id)

        existing = Conversation.objects.filter(participants=request.user).filter(participants=other_user)
        if animal_id:
            existing = existing.filter(animal_id=animal_id)
        conversation = existing.first()

        if not conversation:
            conversation = Conversation.objects.create(animal_id=animal_id)
            conversation.participants.set([request.user, other_user])

        serializer = ConversationSerializer(conversation, context={'request': request})
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class MessageListView(generics.ListAPIView):
    """GET /api/chat/conversations/{id}/messages/ - رسائل محادثة معينة، وتصنيفها كمقروءة"""
    serializer_class = MessageSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        conversation = generics.get_object_or_404(
            Conversation, id=self.kwargs['conversation_id'], participants=self.request.user
        )
        # تصنيف الرسائل الواردة كمقروءة عند فتح المحادثة
        conversation.messages.filter(is_read=False).exclude(sender=self.request.user).update(
            is_read=True, read_at=timezone.now()
        )
        return conversation.messages.select_related('sender').order_by('created_at')


class ChatImageUploadView(APIView):
    """
    POST /api/chat/upload-image/  (multipart/form-data, حقل 'image')
    يرفع صورة إلى Cloudinary ويرجع رابطها المباشر - يُستخدم قبل إرسالها كرسالة عبر WebSocket
    (الواجهة ترفع الصورة هنا أولاً، ثم ترسل الرابط الناتج ضمن رسالة WebSocket من نوع "image")
    """
    permission_classes = [permissions.IsAuthenticated]
    parser_classes = [MultiPartParser]

    def post(self, request):
        image_file = request.FILES.get('image')
        if not image_file:
            return Response({'error': 'يرجى إرفاق صورة بالحقل image'}, status=status.HTTP_400_BAD_REQUEST)

        # حد أقصى بسيط لحجم الصورة (10 ميغابايت) لمنع إساءة الاستخدام
        if image_file.size > 10 * 1024 * 1024:
            return Response({'error': 'حجم الصورة يجب ألا يتجاوز 10 ميغابايت'}, status=status.HTTP_400_BAD_REQUEST)

        result = cloudinary_upload(image_file, folder='baihaywanat/chat')
        return Response({'url': result['secure_url']}, status=status.HTTP_201_CREATED)
