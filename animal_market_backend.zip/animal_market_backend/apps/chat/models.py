from django.conf import settings
from django.db import models


class Conversation(models.Model):
    """محادثة بين بائع ومشتري، مرتبطة اختيارياً بإعلان معيّن"""
    participants = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='conversations', verbose_name='المشاركون')
    animal = models.ForeignKey(
        'animals.Animal', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='conversations', verbose_name='الإعلان المرتبط'
    )
    created_at = models.DateTimeField('تاريخ الإنشاء', auto_now_add=True)
    updated_at = models.DateTimeField('آخر نشاط', auto_now=True)

    class Meta:
        verbose_name = 'محادثة'
        verbose_name_plural = 'المحادثات'
        ordering = ['-updated_at']

    def __str__(self):
        return f'محادثة #{self.id}'


class Message(models.Model):
    """رسالة داخل محادثة - نصية أو صورة"""

    class MessageType(models.TextChoices):
        TEXT = 'text', 'نص'
        IMAGE = 'image', 'صورة'

    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='messages', verbose_name='المحادثة')
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_messages', verbose_name='المرسل')
    message_type = models.CharField('نوع الرسالة', max_length=10, choices=MessageType.choices, default=MessageType.TEXT)
    text = models.TextField('النص', blank=True)
    # رابط الصورة على Cloudinary - يُرفع مسبقاً عبر /api/chat/upload-image/ ثم يُرسل رابطها هنا
    image = models.URLField('رابط الصورة', max_length=500, blank=True, null=True)

    is_read = models.BooleanField('تمت القراءة', default=False)
    read_at = models.DateTimeField('تاريخ القراءة', null=True, blank=True)
    created_at = models.DateTimeField('تاريخ الإرسال', auto_now_add=True)

    class Meta:
        verbose_name = 'رسالة'
        verbose_name_plural = 'الرسائل'
        ordering = ['created_at']

    def __str__(self):
        return f'{self.sender.username}: {self.text[:30] if self.text else "[صورة]"}'
