"""
سكربت اختياري لضبط إعدادات Cloudinary يدوياً (بديل عن متغيرات البيئة)
لا حاجة لاستخدامه إذا كانت متغيرات البيئة في .env مضبوطة بشكل صحيح
"""
import cloudinary
from decouple import config

cloudinary.config(
    cloud_name=config('CLOUDINARY_CLOUD_NAME', default=''),
    api_key=config('CLOUDINARY_API_KEY', default=''),
    api_secret=config('CLOUDINARY_API_SECRET', default=''),
    secure=True,
)
