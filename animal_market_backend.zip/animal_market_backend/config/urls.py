"""
الروابط الرئيسية لمشروع "بيع حيوانات"
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi

schema_view = get_schema_view(
    openapi.Info(
        title='بيع حيوانات API',
        default_version='v1',
        description='توثيق API الخاص بتطبيق بيع وشراء الحيوانات والمواشي والطيور في العراق',
        contact=openapi.Contact(email='support@baihaywanat.com'),
    ),
    public=True,
    permission_classes=[permissions.AllowAny],
)

urlpatterns = [
    path('admin/', admin.site.urls),

    # REST API
    path('api/accounts/', include('apps.accounts.urls')),
    path('api/core/', include('apps.core.urls')),
    path('api/animals/', include('apps.animals.urls')),
    path('api/chat/', include('apps.chat.urls')),
    path('api/notifications/', include('apps.notifications.urls')),

    # توثيق Swagger / ReDoc
    path('api/docs/', schema_view.with_ui('swagger', cache_timeout=0), name='swagger-ui'),
    path('api/redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='redoc-ui'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

admin.site.site_header = 'إدارة تطبيق بيع حيوانات'
admin.site.site_title = 'بيع حيوانات'
admin.site.index_title = 'لوحة التحكم الرئيسية'
