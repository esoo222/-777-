"""
ASGI config - يدعم HTTP العادي و WebSocket معاً (للدردشة الفورية)
"""
import os
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

# يجب استدعاء get_asgi_application() أولاً قبل استيراد أي شيء يستخدم django.setup()
django_asgi_app = get_asgi_application()

from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
from apps.chat.middleware import JWTAuthMiddlewareStack
import apps.chat.routing
import apps.notifications.routing

application = ProtocolTypeRouter({
    'http': django_asgi_app,
    'websocket': JWTAuthMiddlewareStack(
        URLRouter(
            apps.chat.routing.websocket_urlpatterns +
            apps.notifications.routing.websocket_urlpatterns
        )
    ),
})
