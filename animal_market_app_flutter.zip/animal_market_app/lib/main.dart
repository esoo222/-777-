import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timeago/timeago.dart' as timeago;

import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'core/theme/theme_provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // تفعيل الترجمة العربية لمكتبة "منذ x دقيقة" (timeago)
  timeago.setLocaleMessages('ar', timeago.ArMessages());

  runApp(const ProviderScope(child: AnimalMarketApp()));
}

/// التطبيق الرئيسي - "بيع حيوانات"
/// يفعّل دعم RTL الكامل عبر Locale('ar') ويدعم الوضعين الفاتح والداكن
class AnimalMarketApp extends ConsumerWidget {
  const AnimalMarketApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(routerProvider);
    final themeMode = ref.watch(themeModeProvider);

    return MaterialApp.router(
      title: 'بيع حيوانات',
      debugShowCheckedModeBanner: false,
      routerConfig: router,

      // دعم اللغة العربية بالكامل (RTL)
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],

      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: themeMode,

      builder: (context, child) {
        // فرض اتجاه RTL على كامل شجرة الواجهة بغض النظر عن اللوكيل الفعلي للجهاز
        return Directionality(textDirection: TextDirection.rtl, child: child!);
      },
    );
  }
}
