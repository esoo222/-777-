import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_constants.dart';
import '../../auth/providers/auth_provider.dart';

/// شاشة البداية - تظهر لثانيتين ثم تقرر الوجهة حسب حالة تسجيل الدخول
class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _scaleAnimation = CurvedAnimation(parent: _controller, curve: Curves.elasticOut);
    _controller.forward();
    _navigateNext();
  }

  Future<void> _navigateNext() async {
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;

    // ننتظر حتى يتحدد وضع تسجيل الدخول (يُقرأ من التخزين الآمن)
    var authState = ref.read(authNotifierProvider);
    while (authState.status == AuthStatus.unknown) {
      await Future.delayed(const Duration(milliseconds: 100));
      authState = ref.read(authNotifierProvider);
    }

    if (!mounted) return;
    if (authState.status == AuthStatus.authenticated) {
      context.go('/home');
    } else {
      context.go('/onboarding');
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      body: Center(
        child: ScaleTransition(
          scale: _scaleAnimation,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 130,
                height: 130,
                decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                // شعار وجه ماعز - نستخدم أيقونة مؤقتة، يُستبدل بملف assets/icons/app_icon.png
                child: const Icon(Icons.pets, size: 68, color: AppColors.primary),
              ),
              const SizedBox(height: 24),
              const Text(
                AppConstants.appName,
                style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
              ),
              const SizedBox(height: 8),
              const Text(
                'سوق الحيوانات والمواشي في العراق',
                style: TextStyle(color: Colors.white70, fontSize: 14, fontFamily: 'Cairo'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
