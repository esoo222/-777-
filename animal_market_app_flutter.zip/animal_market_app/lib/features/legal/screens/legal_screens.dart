import 'package:flutter/material.dart';
import '../../../core/constants/app_constants.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('سياسة الخصوصية')),
      body: const Padding(
        padding: EdgeInsets.all(AppDimens.paddingL),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Section(
                title: '1. البيانات التي نجمعها',
                body: 'نجمع بريدك الإلكتروني، اسم المستخدم، رقم الهاتف (إن أضفته)، صورك الشخصية وصور الإعلانات، '
                    'والمحافظة التي تختارها، وذلك فقط لتشغيل خدمات التطبيق الأساسية.',
              ),
              _Section(
                title: '2. كيفية استخدام البيانات',
                body: 'تُستخدم بياناتك لعرض إعلاناتك للمستخدمين الآخرين، لتمكين التواصل بين البائع والمشتري عبر '
                    'الدردشة، ولإرسال إشعارات متعلقة بنشاطك (إعجابات، تعليقات، رسائل).',
              ),
              _Section(
                title: '3. مشاركة البيانات',
                body: 'لا نبيع بياناتك الشخصية لأي طرف ثالث. تُخزَّن الصور فقط لدى مزوّد استضافة الصور (Cloudinary) '
                    'بغرض العرض داخل التطبيق.',
              ),
              _Section(
                title: '4. حقوقك',
                body: 'يمكنك تعديل أو حذف ملفك الشخصي وإعلاناتك في أي وقت من داخل التطبيق. لطلب حذف حسابك بالكامل '
                    'تواصل معنا عبر البريد الإلكتروني المذكور في صفحة "عن التطبيق".',
              ),
              _Section(
                title: '5. أمان البيانات',
                body: 'نستخدم تشفير الاتصال (HTTPS) وتوكنات JWT محمية لضمان أمان جلسات المستخدمين.',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class TermsOfServiceScreen extends StatelessWidget {
  const TermsOfServiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('شروط الاستخدام')),
      body: const Padding(
        padding: EdgeInsets.all(AppDimens.paddingL),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _Section(
                title: '1. قبول الشروط',
                body: 'باستخدامك تطبيق "${AppConstants.appName}" فإنك توافق على الالتزام بهذه الشروط بالكامل.',
              ),
              _Section(
                title: '2. مسؤولية المستخدم',
                body: 'أنت مسؤول عن دقة المعلومات التي تنشرها في إعلاناتك، وعن التأكد من مطابقة الحيوان المعروض '
                    'للوصف المذكور. يُمنع نشر إعلانات مضللة أو احتيالية.',
              ),
              _Section(
                title: '3. المحتوى المخالف',
                body: 'يحق للإدارة حذف أي إعلان أو تعليق يخالف القوانين العراقية أو يحتوي على محتوى غير لائق، '
                    'وحظر الحسابات المخالفة بشكل دائم أو مؤقت.',
              ),
              _Section(
                title: '4. المعاملات المالية',
                body: 'التطبيق منصة وسيطة لعرض الإعلانات فقط، ولا يتدخل في عمليات البيع أو الشراء أو الدفع بين '
                    'المستخدمين، وننصح بالتحقق الشخصي من الحيوان قبل إتمام أي صفقة.',
              ),
              _Section(
                title: '5. التبليغات',
                body: 'يمكن لأي مستخدم التبليغ عن إعلان مخالف، وستتم مراجعته من قبل فريق الإدارة خلال مدة معقولة.',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final String body;
  const _Section({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text(body, style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}
