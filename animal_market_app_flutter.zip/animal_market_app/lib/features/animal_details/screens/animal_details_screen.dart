import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:go_router/go_router.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:url_launcher/url_launcher.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/common_widgets.dart';
import '../models/animal_model.dart';
import '../providers/feed_provider.dart';

final _animalDetailProvider = FutureProvider.autoDispose.family<Animal, int>((ref, id) async {
  return ref.watch(animalRepositoryProvider).getAnimalDetail(id);
});

final _commentsProvider = FutureProvider.autoDispose.family<List<AnimalComment>, int>((ref, id) async {
  return ref.watch(animalRepositoryProvider).getComments(id);
});

class AnimalDetailsScreen extends ConsumerStatefulWidget {
  final int animalId;
  final bool openComments;

  const AnimalDetailsScreen({super.key, required this.animalId, this.openComments = false});

  @override
  ConsumerState<AnimalDetailsScreen> createState() => _AnimalDetailsScreenState();
}

class _AnimalDetailsScreenState extends ConsumerState<AnimalDetailsScreen> {
  int _currentImageIndex = 0;
  final _commentController = TextEditingController();

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  Future<void> _callSeller(String? phone) async {
    if (phone == null) return;
    final uri = Uri.parse('tel:$phone');
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  Future<void> _startChat(int sellerId) async {
    context.push('/chat/start/$sellerId?animalId=${widget.animalId}');
  }

  void _showReportSheet(BuildContext context) {
    final reasons = {
      'scam': 'احتيال / نصب',
      'fake': 'معلومات مزيفة',
      'inappropriate': 'محتوى غير لائق',
      'sold': 'الحيوان تم بيعه بالفعل',
      'other': 'أخرى',
    };
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(padding: EdgeInsets.all(16), child: Text('سبب التبليغ', style: TextStyle(fontWeight: FontWeight.bold))),
            ...reasons.entries.map((e) => ListTile(
                  title: Text(e.value),
                  onTap: () async {
                    Navigator.pop(context);
                    await ref.read(animalRepositoryProvider).reportAnimal(widget.animalId, reason: e.key);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم استلام التبليغ، شكراً لك')));
                    }
                  },
                )),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final animalAsync = ref.watch(_animalDetailProvider(widget.animalId));

    return Scaffold(
      body: animalAsync.when(
        loading: () => const AppLoader(),
        error: (e, _) => ErrorRetryWidget(
          message: e.toString(),
          onRetry: () => ref.invalidate(_animalDetailProvider(widget.animalId)),
        ),
        data: (animal) => CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              expandedHeight: 320,
              actions: [
                IconButton(icon: const Icon(Icons.flag_outlined), onPressed: () => _showReportSheet(context)),
              ],
              flexibleSpace: FlexibleSpaceBar(
                background: _buildImageCarousel(animal),
              ),
            ),
            SliverToBoxAdapter(child: _buildContent(animal)),
          ],
        ),
      ),
    );
  }

  Widget _buildImageCarousel(Animal animal) {
    final images = animal.images.isNotEmpty ? animal.images : [];
    if (images.isEmpty) {
      return Container(color: AppColors.primary.withOpacity(0.05), child: const Icon(Icons.pets, size: 80));
    }
    return Stack(
      children: [
        CarouselSlider(
          options: CarouselOptions(
            height: 320,
            viewportFraction: 1,
            onPageChanged: (index, _) => setState(() => _currentImageIndex = index),
          ),
          items: images
              .map((img) => CachedNetworkImage(imageUrl: img.imageUrl, fit: BoxFit.cover, width: double.infinity))
              .toList(),
        ),
        Positioned(
          bottom: 12,
          left: 0,
          right: 0,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: images.asMap().entries.map((e) {
              return Container(
                width: 7,
                height: 7,
                margin: const EdgeInsets.symmetric(horizontal: 3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _currentImageIndex == e.key ? Colors.white : Colors.white54,
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildContent(Animal animal) {
    return Padding(
      padding: const EdgeInsets.all(AppDimens.paddingM),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(animal.name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
              ),
              _likeSaveButtons(animal),
            ],
          ),
          const SizedBox(height: 6),
          Text(animal.priceLabel, style: const TextStyle(color: AppColors.primary, fontSize: 22, fontWeight: FontWeight.bold)),
          if (animal.isNegotiable)
            const Text('السعر قابل للتفاوض', style: TextStyle(color: AppColors.lightTextSecondary, fontSize: 12)),
          const SizedBox(height: 16),
          _infoChips(animal),
          const SizedBox(height: 16),
          if (animal.description != null && animal.description!.isNotEmpty) ...[
            Text('الوصف', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(animal.description!),
            const SizedBox(height: 16),
          ],
          _sellerCard(animal),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: PrimaryButton(icon: Icons.chat_bubble_outline, label: 'مراسلة البائع', onPressed: () => _startChat(animal.sellerId)),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _callSeller(animal.contactPhone),
                  icon: const Icon(Icons.call_outlined),
                  label: const Text('اتصال'),
                  style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Text('التعليقات (${animal.commentsCount})', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          _buildComments(),
          const SizedBox(height: 8),
          _commentInput(),
        ],
      ),
    );
  }

  Widget _likeSaveButtons(Animal animal) {
    return Row(
      children: [
        IconButton(
          icon: Icon(animal.isLiked ? Icons.favorite : Icons.favorite_border, color: animal.isLiked ? AppColors.like : null),
          onPressed: () async {
            await ref.read(animalRepositoryProvider).toggleLike(animal.id);
            ref.invalidate(_animalDetailProvider(widget.animalId));
          },
        ),
        IconButton(
          icon: Icon(animal.isSaved ? Icons.bookmark : Icons.bookmark_border),
          onPressed: () async {
            await ref.read(animalRepositoryProvider).toggleSave(animal.id);
            ref.invalidate(_animalDetailProvider(widget.animalId));
          },
        ),
      ],
    );
  }

  Widget _infoChips(Animal animal) {
    final chips = [
      ('السلالة', animal.breed),
      ('العمر', animal.ageLabel),
      ('الجنس', animal.genderLabel),
      ('المحافظة', animal.governorateName),
      ('النوع', animal.categoryName),
    ];
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: chips.map((c) {
        return Chip(
          label: Text('${c.$1}: ${c.$2}'),
          backgroundColor: AppColors.primary.withOpacity(0.08),
        );
      }).toList(),
    );
  }

  Widget _sellerCard(Animal animal) {
    return InkWell(
      onTap: () => context.push('/seller/${animal.sellerId}'),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          border: Border.all(color: Theme.of(context).dividerColor),
          borderRadius: BorderRadius.circular(AppDimens.radiusM),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: AppColors.primary.withOpacity(0.15),
              backgroundImage: animal.sellerAvatar != null ? CachedNetworkImageProvider(animal.sellerAvatar!) : null,
              child: animal.sellerAvatar == null ? const Icon(Icons.person, color: AppColors.primary) : null,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(animal.sellerUsername, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const Text('عرض صفحة البائع', style: TextStyle(fontSize: 12, color: AppColors.lightTextSecondary)),
                ],
              ),
            ),
            const Icon(Icons.arrow_back_ios, size: 14),
          ],
        ),
      ),
    );
  }

  Widget _buildComments() {
    final commentsAsync = ref.watch(_commentsProvider(widget.animalId));
    return commentsAsync.when(
      loading: () => const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator()),
      error: (e, _) => Text(e.toString()),
      data: (comments) {
        if (comments.isEmpty) return const Text('لا توجد تعليقات بعد، كن أول من يعلّق');
        return Column(
          children: comments.map((c) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 16,
                    backgroundColor: AppColors.primary.withOpacity(0.15),
                    backgroundImage: c.avatar != null ? CachedNetworkImageProvider(c.avatar!) : null,
                    child: c.avatar == null ? const Icon(Icons.person, size: 16, color: AppColors.primary) : null,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(c.username, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                        Text(c.text),
                        Text(timeago.format(c.createdAt, locale: 'ar'), style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        );
      },
    );
  }

  Widget _commentInput() {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: _commentController,
            decoration: const InputDecoration(hintText: 'أضف تعليقاً...'),
          ),
        ),
        IconButton(
          icon: const Icon(Icons.send, color: AppColors.primary),
          onPressed: () async {
            if (_commentController.text.trim().isEmpty) return;
            await ref.read(animalRepositoryProvider).addComment(widget.animalId, _commentController.text.trim());
            _commentController.clear();
            ref.invalidate(_commentsProvider(widget.animalId));
            ref.invalidate(_animalDetailProvider(widget.animalId));
          },
        ),
      ],
    );
  }
}
