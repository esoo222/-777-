import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../home/providers/feed_provider.dart';
import '../../home/widgets/animal_feed_card.dart';

class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});

  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  final _searchController = TextEditingController();
  int? _governorateId;
  int? _categoryId;
  String? _gender;
  final _minPriceController = TextEditingController();
  final _maxPriceController = TextEditingController();
  final _minAgeController = TextEditingController();
  final _maxAgeController = TextEditingController();

  void _applyFilters() {
    ref.read(feedFiltersProvider.notifier).state = FeedFilters(
      search: _searchController.text.trim().isEmpty ? null : _searchController.text.trim(),
      governorate: _governorateId,
      category: _categoryId,
      gender: _gender,
      minPrice: num.tryParse(_minPriceController.text),
      maxPrice: num.tryParse(_maxPriceController.text),
      minAge: int.tryParse(_minAgeController.text),
      maxAge: int.tryParse(_maxAgeController.text),
    );
  }

  void _clearFilters() {
    setState(() {
      _searchController.clear();
      _governorateId = null;
      _categoryId = null;
      _gender = null;
      _minPriceController.clear();
      _maxPriceController.clear();
      _minAgeController.clear();
      _maxAgeController.clear();
    });
    ref.read(feedFiltersProvider.notifier).state = const FeedFilters();
  }

  @override
  Widget build(BuildContext context) {
    final feedState = ref.watch(feedProvider);
    final categoriesAsync = ref.watch(categoriesProvider);
    final governoratesAsync = ref.watch(governoratesProvider);

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _searchController,
          textAlign: TextAlign.right,
          decoration: const InputDecoration(
            hintText: 'ابحث عن حيوان...',
            border: InputBorder.none,
          ),
          onSubmitted: (_) => _applyFilters(),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.search), onPressed: _applyFilters),
        ],
      ),
      body: Column(
        children: [
          _buildFiltersBar(categoriesAsync, governoratesAsync),
          const Divider(height: 1),
          Expanded(child: _buildResults(feedState)),
        ],
      ),
    );
  }

  Widget _buildFiltersBar(AsyncValue categoriesAsync, AsyncValue governoratesAsync) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Row(
        children: [
          _filterChipButton(
            label: _categoryId == null ? 'النوع' : 'النوع ✓',
            onTap: () => _showCategorySheet(categoriesAsync),
          ),
          const SizedBox(width: 8),
          _filterChipButton(
            label: _governorateId == null ? 'المحافظة' : 'المحافظة ✓',
            onTap: () => _showGovernorateSheet(governoratesAsync),
          ),
          const SizedBox(width: 8),
          _filterChipButton(
            label: _gender == null ? 'الجنس' : (_gender == 'male' ? 'ذكر' : 'أنثى'),
            onTap: _showGenderSheet,
          ),
          const SizedBox(width: 8),
          _filterChipButton(label: 'السعر والعمر', onTap: _showPriceAgeSheet),
          const SizedBox(width: 8),
          ActionChip(label: const Text('مسح الفلاتر'), onPressed: _clearFilters),
        ],
      ),
    );
  }

  Widget _filterChipButton({required String label, required VoidCallback onTap}) {
    return ActionChip(
      label: Text(label),
      avatar: const Icon(Icons.filter_list, size: 16),
      onPressed: onTap,
    );
  }

  void _showCategorySheet(AsyncValue categoriesAsync) {
    showModalBottomSheet(
      context: context,
      builder: (context) => categoriesAsync.when(
        loading: () => const SizedBox(height: 200, child: AppLoader()),
        error: (e, _) => Text('$e'),
        data: (categories) => ListView(
          shrinkWrap: true,
          children: (categories as List).map((c) {
            return ListTile(
              title: Text(c.nameAr),
              onTap: () {
                setState(() => _categoryId = c.id);
                Navigator.pop(context);
                _applyFilters();
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  void _showGovernorateSheet(AsyncValue governoratesAsync) {
    showModalBottomSheet(
      context: context,
      builder: (context) => governoratesAsync.when(
        loading: () => const SizedBox(height: 200, child: AppLoader()),
        error: (e, _) => Text('$e'),
        data: (govs) => ListView(
          shrinkWrap: true,
          children: (govs as List).map((g) {
            return ListTile(
              title: Text(g.nameAr),
              onTap: () {
                setState(() => _governorateId = g.id);
                Navigator.pop(context);
                _applyFilters();
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  void _showGenderSheet() {
    showModalBottomSheet(
      context: context,
      builder: (context) => ListView(
        shrinkWrap: true,
        children: [
          ListTile(title: const Text('ذكر'), onTap: () { setState(() => _gender = 'male'); Navigator.pop(context); _applyFilters(); }),
          ListTile(title: const Text('أنثى'), onTap: () { setState(() => _gender = 'female'); Navigator.pop(context); _applyFilters(); }),
        ],
      ),
    );
  }

  void _showPriceAgeSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          left: 16, right: 16, top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('نطاق السعر والعمر', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: TextField(controller: _minPriceController, decoration: const InputDecoration(labelText: 'أقل سعر'), keyboardType: TextInputType.number)),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: _maxPriceController, decoration: const InputDecoration(labelText: 'أعلى سعر'), keyboardType: TextInputType.number)),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: TextField(controller: _minAgeController, decoration: const InputDecoration(labelText: 'أقل عمر'), keyboardType: TextInputType.number)),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: _maxAgeController, decoration: const InputDecoration(labelText: 'أعلى عمر'), keyboardType: TextInputType.number)),
              ],
            ),
            const SizedBox(height: 16),
            PrimaryButton(label: 'تطبيق', onPressed: () { Navigator.pop(context); _applyFilters(); }),
          ],
        ),
      ),
    );
  }

  Widget _buildResults(FeedState state) {
    if (state.isLoading) return const AppLoader();
    if (state.animals.isEmpty) {
      return const EmptyState(icon: Icons.search_off, title: 'لا توجد نتائج مطابقة', subtitle: 'جرّب تعديل كلمات البحث أو الفلاتر');
    }
    return ListView.builder(
      itemCount: state.animals.length,
      itemBuilder: (context, index) => AnimalFeedCard(animal: state.animals[index]),
    );
  }
}
