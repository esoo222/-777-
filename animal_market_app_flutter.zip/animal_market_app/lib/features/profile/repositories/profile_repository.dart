import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';
import '../../../core/constants/api_endpoints.dart';
import '../../../core/network/api_client.dart';
import '../models/profile_model.dart';

class ProfileRepository {
  final Dio _dio = ApiClient.instance.dio;

  Future<Profile> getMyProfile() async {
    try {
      final res = await _dio.get(ApiEndpoints.myProfile);
      return Profile.fromJson(res.data);
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<Profile> getPublicProfile(int userId) async {
    try {
      final res = await _dio.get(ApiEndpoints.publicProfile(userId));
      return Profile.fromJson(res.data);
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<Profile> updateProfile({
    String? username,
    String? bio,
    int? governorateId,
    XFile? avatar,
  }) async {
    try {
      final formData = FormData.fromMap({
        if (username != null) 'username': username,
        if (bio != null) 'bio': bio,
        if (governorateId != null) 'governorate': governorateId,
        if (avatar != null) 'avatar': await MultipartFile.fromFile(avatar.path, filename: avatar.name),
      });
      final res = await _dio.patch(ApiEndpoints.myProfile, data: formData);
      return Profile.fromJson(res.data);
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<bool> toggleFollow(int userId) async {
    try {
      final res = await _dio.post(ApiEndpoints.followToggle(userId));
      return res.data['is_following'] as bool;
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<void> rateSeller(int userId, {required int stars, String? comment}) async {
    try {
      await _dio.post(ApiEndpoints.rateSeller(userId), data: {'stars': stars, if (comment != null) 'comment': comment});
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<bool> toggleBlock(int userId) async {
    try {
      final res = await _dio.post(ApiEndpoints.blockUser(userId));
      return res.data['is_blocked'] as bool;
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }
}
