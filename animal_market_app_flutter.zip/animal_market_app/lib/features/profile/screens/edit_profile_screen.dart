import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../home/providers/feed_provider.dart';
import '../providers/profile_provider.dart';
import '../repositories/profile_repository.dart';

class EditProfileScreen extends ConsumerStatefulWidget {
  const EditProfileScreen({super.key});

  @override
  ConsumerState<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends ConsumerState<EditProfileScreen> {
  final _usernameController = TextEditingController();
  final _bioController = TextEditingController();
  int? _governorateId;
  XFile? _newAvatar;
  bool _isLoading = false;
  bool _initialized = false;

  Future<void> _pickAvatar() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (picked != null) setState(() => _newAvatar = picked);
  }

  Future<void> _save() async {
    setState(() => _isLoading = true);
    try {
      await ref.read(profileRepositoryProvider).updateProfile(
            username: _usernameController.text.trim(),
            bio: _bioController.text.trim(),
            governorateId: _governorateId,
            avatar: _newAvatar,
          );
      ref.invalidate(myProfileProvider);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ التعديلات بنجاح')));
      context.pop();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()), backgroundColor: AppColors.error));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final profileAsync = ref.watch(myProfileProvider);
    final governoratesAsync = ref.watch(governoratesProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('تعديل الملف الشخصي')),
      body: profileAsync.when(
        loading: () => const AppLoader(),
        error: (e, _) => ErrorRetryWidget(message: e.toString(), onRetry: () => ref.invalidate(myProfileProvider)),
        data: (profile) {
          if (!_initialized) {
            _usernameController.text = profile.username;
            _bioController.text = profile.bio;
            _governorateId = profile.governorateId;
            _initialized = true;
          }
          return ListView(
            padding: const EdgeInsets.all(AppDimens.paddingM),
            children: [
              Center(
                child: GestureDetector(
                  onTap: _pickAvatar,
                  child: Stack(
                    children: [
                      CircleAvatar(
                        radius: AppDimens.avatarXL / 2,
                        backgroundColor: AppColors.primary.withOpacity(0.15),
                        backgroundImage: _newAvatar != null
                            ? FileImage(File(_newAvatar!.path))
                            : (profile.avatar != null ? CachedNetworkImageProvider(profile.avatar!) as ImageProvider : null),
                        child: (_newAvatar == null && profile.avatar == null)
                            ? const Icon(Icons.person, size: 48, color: AppColors.primary)
                            : null,
                      ),
                      const Positioned(
                        bottom: 0,
                        left: 0,
                        child: CircleAvatar(radius: 16, backgroundColor: AppColors.primary, child: Icon(Icons.camera_alt, size: 16, color: Colors.white)),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              AppTextField(controller: _usernameController, label: 'اسم المستخدم', prefixIcon: const Icon(Icons.person_outline)),
              const SizedBox(height: 16),
              AppTextField(controller: _bioController, label: 'نبذة تعريفية', maxLines: 3, maxLength: 500),
              const SizedBox(height: 16),
              governoratesAsync.when(
                loading: () => const LinearProgressIndicator(),
                error: (e, _) => Text('$e'),
                data: (govs) => DropdownButtonFormField<int>(
                  value: _governorateId,
                  decoration: const InputDecoration(labelText: 'المحافظة'),
                  items: govs.map((g) => DropdownMenuItem(value: g.id, child: Text(g.nameAr))).toList(),
                  onChanged: (v) => setState(() => _governorateId = v),
                ),
              ),
              const SizedBox(height: 24),
              PrimaryButton(label: 'حفظ التعديلات', isLoading: _isLoading, onPressed: _save),
            ],
          );
        },
      ),
    );
  }
}
