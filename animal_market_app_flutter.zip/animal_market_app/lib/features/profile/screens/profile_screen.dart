import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../auth/providers/auth_provider.dart';
import '../../home/models/animal_model.dart';
import '../../home/providers/feed_provider.dart';
import '../models/profile_model.dart';
import '../providers/profile_provider.dart';
import '../repositories/profile_repository.dart';

/// شاشة صفحة البائع - تعمل لعرض ملفك الشخصي (isMe=true) أو ملف بائع آخر
class ProfileScreen extends ConsumerStatefulWidget {
  final int? userId; // null يعني "ملفي الشخصي"

  const ProfileScreen({super.key, this.userId});

  bool get isMe => userId == null;

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  Future<List<Animal>> _loadSellerAnimals(int? sellerId) async {
    if (widget.isMe) {
      final result = await ref.read(animalRepositoryProvider).getMyAnimals();
      return result.results;
    }
    final result = await ref.read(animalRepositoryProvider).getAnimals();
    return result.results.where((a) => a.sellerId == sellerId).toList();
  }

  @override
  Widget build(BuildContext context) {
    final profileAsync =
        widget.isMe ? ref.watch(myProfileProvider) : ref.watch(publicProfileProvider(widget.userId!));

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isMe ? 'ملفي الشخصي' : 'صفحة البائع'),
        actions: [
          if (widget.isMe)
            IconButton(icon: const Icon(Icons.settings_outlined), onPressed: () => context.push('/settings'))
          else
            PopupMenuButton<String>(
              onSelected: (value) async {
                if (value == 'block') {
                  await ref.read(profileRepositoryProvider).toggleBlock(widget.userId!);
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حظر المستخدم')));
                } else if (value == 'rate') {
                  _showRatingDialog(context);
                }
              },
              itemBuilder: (context) => [
                const PopupMenuItem(value: 'rate', child: Text('تقييم البائع')),
                const PopupMenuItem(value: 'block', child: Text('حظر المستخدم')),
              ],
            ),
        ],
      ),
      body: profileAsync.when(
        loading: () => const AppLoader(),
        error: (e, _) => ErrorRetryWidget(message: e.toString(), onRetry: () => ref.invalidate(myProfileProvider)),
        data: (profile) => RefreshIndicator(
          onRefresh: () async => widget.isMe ? ref.invalidate(myProfileProvider) : ref.invalidate(publicProfileProvider(widget.userId!)),
          child: ListView(
            padding: const EdgeInsets.all(AppDimens.paddingM),
            children: [
              _buildHeader(profile),
              const SizedBox(height: 20),
              Text('الإعلانات (${profile.animalsCount})', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              _buildAnimalsGrid(profile.id),
            ],
          ),
        ),
      ),
    );
  }

  void _showRatingDialog(BuildContext context) {
    int stars = 5;
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('تقييم البائع'),
          content: Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(5, (i) {
              return IconButton(
                icon: Icon(i < stars ? Icons.star : Icons.star_border, color: Colors.amber),
                onPressed: () => setDialogState(() => stars = i + 1),
              );
            }),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            TextButton(
              onPressed: () async {
                Navigator.pop(context);
                await ref.read(profileRepositoryProvider).rateSeller(widget.userId!, stars: stars);
                ref.invalidate(publicProfileProvider(widget.userId!));
              },
              child: const Text('إرسال'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(Profile profile) {
    return Column(
      children: [
        CircleAvatar(
          radius: AppDimens.avatarXL / 2,
          backgroundColor: AppColors.primary.withOpacity(0.15),
          backgroundImage: profile.avatar != null ? CachedNetworkImageProvider(profile.avatar!) : null,
          child: profile.avatar == null ? const Icon(Icons.person, size: 48, color: AppColors.primary) : null,
        ),
        const SizedBox(height: 10),
        Text(profile.username, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
        if (profile.bio.isNotEmpty) ...[
          const SizedBox(height: 4),
          Text(profile.bio, textAlign: TextAlign.center),
        ],
        if (profile.governorateName != null) ...[
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.location_on_outlined, size: 16, color: AppColors.lightTextSecondary),
              Text(profile.governorateName!, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ],
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.star, color: Colors.amber, size: 18),
            const SizedBox(width: 4),
            Text('${profile.ratingAverage.toStringAsFixed(1)} (${profile.ratingCount})'),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _statColumn('الإعلانات', profile.animalsCount),
            _statColumn('المتابعون', profile.followersCount),
            _statColumn('يتابع', profile.followingCount),
          ],
        ),
        const SizedBox(height: 16),
        if (!widget.isMe)
          SizedBox(
            width: double.infinity,
            child: PrimaryButton(
              label: profile.isFollowing ? 'إلغاء المتابعة' : 'متابعة',
              color: profile.isFollowing ? AppColors.lightTextSecondary : null,
              onPressed: () async {
                await ref.read(profileRepositoryProvider).toggleFollow(widget.userId!);
                ref.invalidate(publicProfileProvider(widget.userId!));
              },
            ),
          )
        else
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => context.push('/edit-profile'),
              icon: const Icon(Icons.edit_outlined),
              label: const Text('تعديل الملف الشخصي'),
            ),
          ),
      ],
    );
  }

  Widget _statColumn(String label, int value) {
    return Column(
      children: [
        Text('$value', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        Text(label, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }

  Widget _buildAnimalsGrid(int sellerId) {
    return FutureBuilder<List<Animal>>(
      future: _loadSellerAnimals(sellerId),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()));
        }
        final animals = snapshot.data ?? [];
        if (animals.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: Text('لا توجد إعلانات بعد')),
          );
        }
        return MasonryGridView.count(
          crossAxisCount: 3,
          mainAxisSpacing: 4,
          crossAxisSpacing: 4,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: animals.length,
          itemBuilder: (context, index) {
            final animal = animals[index];
            return GestureDetector(
              onTap: () => context.push('/animal/${animal.id}'),
              child: AspectRatio(
                aspectRatio: 1,
                child: animal.coverImage != null
                    ? CachedNetworkImage(imageUrl: animal.coverImage!, fit: BoxFit.cover)
                    : Container(color: AppColors.primary.withOpacity(0.08), child: const Icon(Icons.pets)),
              ),
            );
          },
        );
      },
    );
  }
}
