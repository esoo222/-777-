class Profile {
  final int id;
  final String username;
  final String email;
  final String? avatar;
  final String bio;
  final int? governorateId;
  final String? governorateName;
  final double ratingAverage;
  final int ratingCount;
  final int followersCount;
  final int followingCount;
  final int animalsCount;
  final bool isFollowing;

  Profile({
    required this.id,
    required this.username,
    required this.email,
    this.avatar,
    required this.bio,
    this.governorateId,
    this.governorateName,
    required this.ratingAverage,
    required this.ratingCount,
    required this.followersCount,
    required this.followingCount,
    required this.animalsCount,
    required this.isFollowing,
  });

  factory Profile.fromJson(Map<String, dynamic> json) {
    return Profile(
      id: json['id'] as int,
      username: json['username'] as String,
      email: json['email'] as String? ?? '',
      avatar: json['avatar'] as String?,
      bio: json['bio'] as String? ?? '',
      governorateId: json['governorate'] as int?,
      governorateName: json['governorate_detail'] != null ? json['governorate_detail']['name_ar'] as String? : null,
      ratingAverage: double.tryParse('${json['rating_average'] ?? 0}') ?? 0,
      ratingCount: json['rating_count'] as int? ?? 0,
      followersCount: json['followers_count'] as int? ?? 0,
      followingCount: json['following_count'] as int? ?? 0,
      animalsCount: json['animals_count'] as int? ?? 0,
      isFollowing: json['is_following'] as bool? ?? false,
    );
  }
}
