import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/profile_model.dart';
import '../repositories/profile_repository.dart';

final profileRepositoryProvider = Provider((ref) => ProfileRepository());

final myProfileProvider = FutureProvider.autoDispose<Profile>((ref) async {
  return ref.watch(profileRepositoryProvider).getMyProfile();
});

final publicProfileProvider = FutureProvider.autoDispose.family<Profile, int>((ref, userId) async {
  return ref.watch(profileRepositoryProvider).getPublicProfile(userId);
});
