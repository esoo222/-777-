import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../home/providers/feed_provider.dart';

class AddAnimalScreen extends ConsumerStatefulWidget {
  const AddAnimalScreen({super.key});

  @override
  ConsumerState<AddAnimalScreen> createState() => _AddAnimalScreenState();
}

class _AddAnimalScreenState extends ConsumerState<AddAnimalScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _breedController = TextEditingController();
  final _ageController = TextEditingController();
  final _priceController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _phoneController = TextEditingController();

  int? _categoryId;
  int? _governorateId;
  String _ageUnit = 'month';
  String _gender = 'male';
  bool _isNegotiable = true;
  final List<XFile> _images = [];
  bool _isLoading = false;

  Future<void> _pickImages() async {
    if (_images.length >= AppConstants.maxAnimalImages) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لا يمكن رفع أكثر من 10 صور')),
      );
      return;
    }
    final picker = ImagePicker();
    final picked = await picker.pickMultiImage(imageQuality: 85);
    if (picked.isNotEmpty) {
      setState(() {
        final remaining = AppConstants.maxAnimalImages - _images.length;
        _images.addAll(picked.take(remaining));
      });
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_categoryId == null || _governorateId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى اختيار نوع الحيوان والمحافظة'), backgroundColor: AppColors.error),
      );
      return;
    }
    if (_images.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى إضافة صورة واحدة على الأقل'), backgroundColor: AppColors.error),
      );
      return;
    }

    setState(() => _isLoading = true);
    try {
      await ref.read(animalRepositoryProvider).createAnimal(
            categoryId: _categoryId!,
            governorateId: _governorateId!,
            name: _nameController.text.trim(),
            breed: _breedController.text.trim(),
            ageValue: int.parse(_ageController.text.trim()),
            ageUnit: _ageUnit,
            gender: _gender,
            price: num.parse(_priceController.text.trim()),
            isNegotiable: _isNegotiable,
            description: _descriptionController.text.trim(),
            contactPhone: _phoneController.text.trim(),
            images: _images,
          );
      if (!mounted) return;
      ref.read(feedProvider.notifier).refresh();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نشر الإعلان بنجاح')));
      context.pop();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()), backgroundColor: AppColors.error));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final categoriesAsync = ref.watch(categoriesProvider);
    final governoratesAsync = ref.watch(governoratesProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('إضافة إعلان جديد')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(AppDimens.paddingM),
          children: [
            _buildImagesPicker(),
            const SizedBox(height: 20),

            AppTextField(controller: _nameController, label: 'اسم الحيوان', validator: _req),
            const SizedBox(height: 12),
            AppTextField(controller: _breedController, label: 'السلالة', validator: _req),
            const SizedBox(height: 12),

            categoriesAsync.when(
              loading: () => const LinearProgressIndicator(),
              error: (e, _) => Text('تعذر تحميل الأنواع: $e'),
              data: (categories) => DropdownButtonFormField<int>(
                value: _categoryId,
                decoration: const InputDecoration(labelText: 'نوع الحيوان'),
                items: categories.map((c) => DropdownMenuItem(value: c.id, child: Text(c.nameAr))).toList(),
                onChanged: (v) => setState(() => _categoryId = v),
              ),
            ),
            const SizedBox(height: 12),

            governoratesAsync.when(
              loading: () => const LinearProgressIndicator(),
              error: (e, _) => Text('تعذر تحميل المحافظات: $e'),
              data: (govs) => DropdownButtonFormField<int>(
                value: _governorateId,
                decoration: const InputDecoration(labelText: 'المحافظة'),
                items: govs.map((g) => DropdownMenuItem(value: g.id, child: Text(g.nameAr))).toList(),
                onChanged: (v) => setState(() => _governorateId = v),
              ),
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: AppTextField(
                    controller: _ageController,
                    label: 'العمر',
                    keyboardType: TextInputType.number,
                    validator: _req,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _ageUnit,
                    decoration: const InputDecoration(labelText: 'الوحدة'),
                    items: const [
                      DropdownMenuItem(value: 'month', child: Text('شهر')),
                      DropdownMenuItem(value: 'year', child: Text('سنة')),
                    ],
                    onChanged: (v) => setState(() => _ageUnit = v!),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            DropdownButtonFormField<String>(
              value: _gender,
              decoration: const InputDecoration(labelText: 'الجنس'),
              items: const [
                DropdownMenuItem(value: 'male', child: Text('ذكر')),
                DropdownMenuItem(value: 'female', child: Text('أنثى')),
              ],
              onChanged: (v) => setState(() => _gender = v!),
            ),
            const SizedBox(height: 12),

            AppTextField(
              controller: _priceController,
              label: 'السعر (دينار عراقي)',
              keyboardType: TextInputType.number,
              validator: _req,
            ),
            SwitchListTile(
              value: _isNegotiable,
              onChanged: (v) => setState(() => _isNegotiable = v),
              title: const Text('السعر قابل للتفاوض'),
              contentPadding: EdgeInsets.zero,
            ),
            const SizedBox(height: 12),

            AppTextField(
              controller: _descriptionController,
              label: 'الوصف',
              maxLines: 4,
              maxLength: AppConstants.maxDescriptionLength,
            ),
            const SizedBox(height: 12),

            AppTextField(
              controller: _phoneController,
              label: 'رقم التواصل',
              keyboardType: TextInputType.phone,
              validator: _req,
            ),
            const SizedBox(height: 24),

            PrimaryButton(label: 'نشر الإعلان', isLoading: _isLoading, onPressed: _submit),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  String? _req(String? v) => (v == null || v.trim().isEmpty) ? 'هذا الحقل مطلوب' : null;

  Widget _buildImagesPicker() {
    return SizedBox(
      height: 100,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          ..._images.asMap().entries.map((entry) {
            return Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(AppDimens.radiusS),
                    child: Image.file(File(entry.value.path), width: 100, height: 100, fit: BoxFit.cover),
                  ),
                  Positioned(
                    top: 2,
                    right: 2,
                    child: GestureDetector(
                      onTap: () => setState(() => _images.removeAt(entry.key)),
                      child: const CircleAvatar(
                        radius: 12,
                        backgroundColor: Colors.black54,
                        child: Icon(Icons.close, size: 14, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
          if (_images.length < AppConstants.maxAnimalImages)
            GestureDetector(
              onTap: _pickImages,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  border: Border.all(color: Theme.of(context).dividerColor),
                  borderRadius: BorderRadius.circular(AppDimens.radiusS),
                ),
                child: const Icon(Icons.add_a_photo_outlined, color: AppColors.primary),
              ),
            ),
        ],
      ),
    );
  }
}
