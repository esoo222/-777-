import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';
import '../../../core/constants/api_endpoints.dart';
import '../../../core/network/api_client.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../home/models/animal_model.dart';
import '../../home/widgets/animal_feed_card.dart';

final favoriteAnimalsProvider = FutureProvider.autoDispose<List<Animal>>((ref) async {
  final dio = ApiClient.instance.dio;
  try {
    final res = await dio.get(ApiEndpoints.favorites);
    final list = res.data is Map ? res.data['results'] : res.data;
    return (list as List).map((e) => Animal.fromJson(e['animal_detail'])).toList();
  } on DioException catch (e) {
    throw ApiClient.parseError(e);
  }
});

/// شاشة الإعلانات المحفوظة (المفضلة)
class FavoritesScreen extends ConsumerWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favoritesAsync = ref.watch(favoriteAnimalsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('المفضلة')),
      body: favoritesAsync.when(
        loading: () => const AppLoader(),
        error: (e, _) => ErrorRetryWidget(message: e.toString(), onRetry: () => ref.invalidate(favoriteAnimalsProvider)),
        data: (animals) {
          if (animals.isEmpty) {
            return const EmptyState(icon: Icons.bookmark_border, title: 'لا توجد إعلانات محفوظة', subtitle: 'احفظ الإعلانات التي تعجبك للرجوع إليها لاحقاً');
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(favoriteAnimalsProvider),
            child: ListView.builder(
              itemCount: animals.length,
              itemBuilder: (context, index) => AnimalFeedCard(animal: animals[index]),
            ),
          );
        },
      ),
    );
  }
}
