import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../../../core/constants/api_endpoints.dart';
import '../../../core/network/api_client.dart';
import '../../../core/network/env_config.dart';
import '../../../core/network/token_storage.dart';
import '../models/chat_models.dart';

class ChatRepository {
  final Dio _dio = ApiClient.instance.dio;

  Future<List<Conversation>> getConversations() async {
    try {
      final res = await _dio.get(ApiEndpoints.conversations);
      final list = res.data is Map ? res.data['results'] : res.data;
      return (list as List).map((e) => Conversation.fromJson(e)).toList();
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<Conversation> startConversation({required int userId, int? animalId}) async {
    try {
      final res = await _dio.post(ApiEndpoints.startConversation, data: {
        'user_id': userId,
        if (animalId != null) 'animal_id': animalId,
      });
      return Conversation.fromJson(res.data);
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<List<ChatMessage>> getMessages(int conversationId) async {
    try {
      final res = await _dio.get(ApiEndpoints.conversationMessages(conversationId));
      final list = res.data is Map ? res.data['results'] : res.data;
      return (list as List).map((e) => ChatMessage.fromJson(e)).toList();
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  /// إنشاء اتصال WebSocket لمحادثة معينة (يستخدم JWT عبر query param)
  Future<WebSocketChannel> connectToConversation(int conversationId) async {
    final token = await TokenStorage.getAccessToken();
    final uri = Uri.parse('${EnvConfig.wsBaseUrl}/chat/$conversationId/?token=$token');
    return WebSocketChannel.connect(uri);
  }

  /// إنشاء اتصال WebSocket عام للإشعارات الفورية
  Future<WebSocketChannel> connectToNotifications() async {
    final token = await TokenStorage.getAccessToken();
    final uri = Uri.parse('${EnvConfig.wsBaseUrl}/notifications/?token=$token');
    return WebSocketChannel.connect(uri);
  }

  void sendTextMessage(WebSocketChannel channel, String text) {
    channel.sink.add(jsonEncode({'type': 'message', 'message_type': 'text', 'text': text}));
  }

  /// يرفع صورة إلى Cloudinary عبر REST أولاً، ثم يرسل رابطها كرسالة عبر WebSocket
  Future<void> sendImageMessage(WebSocketChannel channel, XFile imageFile) async {
    final url = await uploadChatImage(imageFile);
    channel.sink.add(jsonEncode({'type': 'message', 'message_type': 'image', 'image_url': url}));
  }

  /// يرفع صورة إلى السيرفر ويرجع رابطها المباشر على Cloudinary
  Future<String> uploadChatImage(XFile imageFile) async {
    try {
      final formData = FormData.fromMap({
        'image': await MultipartFile.fromFile(imageFile.path, filename: imageFile.name),
      });
      final res = await _dio.post(ApiEndpoints.chatUploadImage, data: formData);
      return res.data['url'] as String;
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  void sendTypingEvent(WebSocketChannel channel) {
    channel.sink.add(jsonEncode({'type': 'typing'}));
  }

  void sendReadEvent(WebSocketChannel channel) {
    channel.sink.add(jsonEncode({'type': 'read'}));
  }
}
