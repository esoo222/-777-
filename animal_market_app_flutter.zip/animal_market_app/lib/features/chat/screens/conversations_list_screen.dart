import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:go_router/go_router.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/common_widgets.dart';
import '../providers/chat_provider.dart';

class ConversationsListScreen extends ConsumerWidget {
  const ConversationsListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final conversationsAsync = ref.watch(conversationsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('الرسائل')),
      body: conversationsAsync.when(
        loading: () => const AppLoader(),
        error: (e, _) => ErrorRetryWidget(message: e.toString(), onRetry: () => ref.invalidate(conversationsProvider)),
        data: (conversations) {
          if (conversations.isEmpty) {
            return const EmptyState(icon: Icons.chat_bubble_outline, title: 'لا توجد محادثات بعد', subtitle: 'ابدأ محادثة من صفحة أي إعلان');
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(conversationsProvider),
            child: ListView.separated(
              itemCount: conversations.length,
              separatorBuilder: (_, __) => const Divider(height: 1, indent: 72),
              itemBuilder: (context, index) {
                final c = conversations[index];
                return ListTile(
                  onTap: () => context.push('/chat/${c.id}'),
                  leading: CircleAvatar(
                    radius: AppDimens.avatarM / 2,
                    backgroundColor: AppColors.primary.withOpacity(0.15),
                    backgroundImage: c.otherParticipant?.avatar != null
                        ? CachedNetworkImageProvider(c.otherParticipant!.avatar!)
                        : null,
                    child: c.otherParticipant?.avatar == null ? const Icon(Icons.person, color: AppColors.primary) : null,
                  ),
                  title: Text(c.otherParticipant?.username ?? 'مستخدم', style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(
                    c.lastMessage?.messageType == 'image'
                        ? '📷 صورة'
                        : (c.lastMessage?.text ?? (c.animalName != null ? 'بخصوص: ${c.animalName}' : '')),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(timeago.format(c.updatedAt, locale: 'ar'), style: Theme.of(context).textTheme.bodySmall),
                      if (c.unreadCount > 0) ...[
                        const SizedBox(height: 4),
                        CircleAvatar(
                          radius: 10,
                          backgroundColor: AppColors.primary,
                          child: Text('${c.unreadCount}', style: const TextStyle(fontSize: 10, color: Colors.white)),
                        ),
                      ],
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
