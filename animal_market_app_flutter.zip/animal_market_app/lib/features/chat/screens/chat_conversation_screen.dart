import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../auth/providers/auth_provider.dart';
import '../models/chat_models.dart';
import '../providers/chat_provider.dart';

/// شاشة المحادثة الفورية - تعرض الرسائل وترسل عبر WebSocket مباشرة
class ChatConversationScreen extends ConsumerStatefulWidget {
  final int conversationId;
  final String? otherUsername;

  const ChatConversationScreen({super.key, required this.conversationId, this.otherUsername});

  @override
  ConsumerState<ChatConversationScreen> createState() => _ChatConversationScreenState();
}

class _ChatConversationScreenState extends ConsumerState<ChatConversationScreen> {
  final _messageController = TextEditingController();
  final _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      ref.read(conversationChatProvider(widget.conversationId).notifier).markAsRead();
    });
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _send() {
    if (_messageController.text.trim().isEmpty) return;
    ref.read(conversationChatProvider(widget.conversationId).notifier).sendMessage(_messageController.text);
    _messageController.clear();
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
  }

  Future<void> _pickAndSendImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked == null) return;
    try {
      await ref.read(conversationChatProvider(widget.conversationId).notifier).sendImage(picked);
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()), backgroundColor: AppColors.error));
    }
  }

  @override
  Widget build(BuildContext context) {
    final chatState = ref.watch(conversationChatProvider(widget.conversationId));

    ref.listen(conversationChatProvider(widget.conversationId), (previous, next) {
      if ((previous?.messages.length ?? 0) != next.messages.length) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
      }
    });

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.otherUsername ?? 'محادثة'),
            if (chatState.otherUserTyping)
              const Text('يكتب الآن...', style: TextStyle(fontSize: 11, color: AppColors.primary))
            else
              Text(
                chatState.isConnected ? 'متصل' : 'غير متصل',
                style: TextStyle(fontSize: 11, color: chatState.isConnected ? AppColors.success : AppColors.lightTextSecondary),
              ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: chatState.isLoading
                ? const AppLoader()
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(AppDimens.paddingM),
                    itemCount: chatState.messages.length,
                    itemBuilder: (context, index) => _MessageBubble(message: chatState.messages[index]),
                  ),
          ),
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    final chatState = ref.watch(conversationChatProvider(widget.conversationId));
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(
          children: [
            chatState.isUploadingImage
                ? const Padding(
                    padding: EdgeInsets.all(8),
                    child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)),
                  )
                : IconButton(
                    icon: const Icon(Icons.image_outlined, color: AppColors.primary),
                    onPressed: _pickAndSendImage,
                  ),
            Expanded(
              child: TextField(
                controller: _messageController,
                decoration: const InputDecoration(hintText: 'اكتب رسالة...'),
                onChanged: (_) => ref.read(conversationChatProvider(widget.conversationId).notifier).notifyTyping(),
                onSubmitted: (_) => _send(),
              ),
            ),
            IconButton(icon: const Icon(Icons.send, color: AppColors.primary), onPressed: _send),
          ],
        ),
      ),
    );
  }
}

class _MessageBubble extends ConsumerWidget {
  final ChatMessage message;
  const _MessageBubble({required this.message});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final myUsername = ref.watch(authNotifierProvider).username;
    final isMine = myUsername != null && message.senderUsername == myUsername;
    return Align(
      alignment: isMine ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
        decoration: BoxDecoration(
          color: isMine ? AppColors.primary : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(AppDimens.radiusM),
        ),
        child: message.messageType == 'image' && message.image != null
            ? ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(message.image!, width: 180))
            : Text(message.text ?? '', style: TextStyle(color: isMine ? Colors.white : null)),
      ),
    );
  }
}
