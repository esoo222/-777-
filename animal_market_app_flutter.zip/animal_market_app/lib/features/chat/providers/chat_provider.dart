import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../models/chat_models.dart';
import '../repositories/chat_repository.dart';

final chatRepositoryProvider = Provider((ref) => ChatRepository());

final conversationsProvider = FutureProvider.autoDispose<List<Conversation>>((ref) async {
  return ref.watch(chatRepositoryProvider).getConversations();
});

/// حالة شاشة محادثة واحدة: الرسائل + اتصال WebSocket نشِط
class ConversationChatState {
  final List<ChatMessage> messages;
  final bool isLoading;
  final bool isConnected;
  final bool otherUserTyping;
  final bool isUploadingImage;

  const ConversationChatState({
    this.messages = const [],
    this.isLoading = false,
    this.isConnected = false,
    this.otherUserTyping = false,
    this.isUploadingImage = false,
  });

  ConversationChatState copyWith({
    List<ChatMessage>? messages,
    bool? isLoading,
    bool? isConnected,
    bool? otherUserTyping,
    bool? isUploadingImage,
  }) {
    return ConversationChatState(
      messages: messages ?? this.messages,
      isLoading: isLoading ?? this.isLoading,
      isConnected: isConnected ?? this.isConnected,
      otherUserTyping: otherUserTyping ?? this.otherUserTyping,
      isUploadingImage: isUploadingImage ?? this.isUploadingImage,
    );
  }
}

class ConversationChatNotifier extends StateNotifier<ConversationChatState> {
  final ChatRepository _repository;
  final int conversationId;
  WebSocketChannel? _channel;

  ConversationChatNotifier(this._repository, this.conversationId) : super(const ConversationChatState()) {
    _init();
  }

  Future<void> _init() async {
    state = state.copyWith(isLoading: true);
    try {
      final messages = await _repository.getMessages(conversationId);
      state = state.copyWith(messages: messages, isLoading: false);
    } catch (_) {
      state = state.copyWith(isLoading: false);
    }
    await _connectWebSocket();
  }

  Future<void> _connectWebSocket() async {
    try {
      _channel = await _repository.connectToConversation(conversationId);
      state = state.copyWith(isConnected: true);
      _channel!.stream.listen(
        (data) {
          final decoded = jsonDecode(data as String);
          if (decoded['type'] == 'message') {
            final msg = ChatMessage.fromJson(decoded['message']);
            state = state.copyWith(messages: [...state.messages, msg]);
          } else if (decoded['type'] == 'typing') {
            state = state.copyWith(otherUserTyping: true);
            Future.delayed(const Duration(seconds: 3), () {
              if (mounted) state = state.copyWith(otherUserTyping: false);
            });
          }
        },
        onDone: () => state = state.copyWith(isConnected: false),
        onError: (_) => state = state.copyWith(isConnected: false),
      );
    } catch (_) {
      state = state.copyWith(isConnected: false);
    }
  }

  void sendMessage(String text) {
    if (_channel == null || text.trim().isEmpty) return;
    _repository.sendTextMessage(_channel!, text.trim());
  }

  /// يرفع صورة ويرسلها كرسالة - يعرض حالة تحميل أثناء الرفع
  Future<void> sendImage(XFile imageFile) async {
    if (_channel == null) return;
    state = state.copyWith(isUploadingImage: true);
    try {
      await _repository.sendImageMessage(_channel!, imageFile);
    } finally {
      if (mounted) state = state.copyWith(isUploadingImage: false);
    }
  }

  void notifyTyping() {
    if (_channel != null) _repository.sendTypingEvent(_channel!);
  }

  void markAsRead() {
    if (_channel != null) _repository.sendReadEvent(_channel!);
  }

  @override
  void dispose() {
    _channel?.sink.close();
    super.dispose();
  }
}

final conversationChatProvider =
    StateNotifierProvider.autoDispose.family<ConversationChatNotifier, ConversationChatState, int>(
  (ref, conversationId) => ConversationChatNotifier(ref.watch(chatRepositoryProvider), conversationId),
);
