class ChatParticipant {
  final int id;
  final String username;
  final String? avatar;

  ChatParticipant({required this.id, required this.username, this.avatar});

  factory ChatParticipant.fromJson(Map<String, dynamic> json) {
    return ChatParticipant(id: json['id'] as int, username: json['username'] as String, avatar: json['avatar'] as String?);
  }
}

class ChatMessage {
  final int id;
  final int conversationId;
  final int senderId;
  final String senderUsername;
  final String messageType; // text | image
  final String? text;
  final String? image;
  final bool isRead;
  final DateTime createdAt;

  ChatMessage({
    required this.id,
    required this.conversationId,
    required this.senderId,
    required this.senderUsername,
    required this.messageType,
    this.text,
    this.image,
    required this.isRead,
    required this.createdAt,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: json['id'] as int,
      conversationId: json['conversation'] as int,
      senderId: json['sender'] as int,
      senderUsername: json['sender_username'] as String? ?? '',
      messageType: json['message_type'] as String? ?? 'text',
      text: json['text'] as String?,
      image: json['image'] as String?,
      isRead: json['is_read'] as bool? ?? false,
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ?? DateTime.now(),
    );
  }
}

class Conversation {
  final int id;
  final int? animalId;
  final String? animalName;
  final ChatParticipant? otherParticipant;
  final ChatMessage? lastMessage;
  final int unreadCount;
  final DateTime updatedAt;

  Conversation({
    required this.id,
    this.animalId,
    this.animalName,
    this.otherParticipant,
    this.lastMessage,
    required this.unreadCount,
    required this.updatedAt,
  });

  factory Conversation.fromJson(Map<String, dynamic> json) {
    return Conversation(
      id: json['id'] as int,
      animalId: json['animal'] as int?,
      animalName: json['animal_name'] as String?,
      otherParticipant: json['other_participant'] != null ? ChatParticipant.fromJson(json['other_participant']) : null,
      lastMessage: json['last_message'] != null ? ChatMessage.fromJson(json['last_message']) : null,
      unreadCount: json['unread_count'] as int? ?? 0,
      updatedAt: DateTime.tryParse(json['updated_at'] as String? ?? '') ?? DateTime.now(),
    );
  }
}
