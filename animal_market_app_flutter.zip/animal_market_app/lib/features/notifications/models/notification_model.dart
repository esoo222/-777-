class AppNotification {
  final int id;
  final String notifType; // like | comment | follow | message | rating | system
  final int? senderId;
  final String? senderUsername;
  final String? senderAvatar;
  final int? animalId;
  final String message;
  final bool isRead;
  final DateTime createdAt;

  AppNotification({
    required this.id,
    required this.notifType,
    this.senderId,
    this.senderUsername,
    this.senderAvatar,
    this.animalId,
    required this.message,
    required this.isRead,
    required this.createdAt,
  });

  factory AppNotification.fromJson(Map<String, dynamic> json) {
    return AppNotification(
      id: json['id'] as int,
      notifType: json['notif_type'] as String,
      senderId: json['sender'] as int?,
      senderUsername: json['sender_username'] as String?,
      senderAvatar: json['sender_avatar'] as String?,
      animalId: json['animal'] as int?,
      message: json['message'] as String,
      isRead: json['is_read'] as bool? ?? false,
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ?? DateTime.now(),
    );
  }
}
