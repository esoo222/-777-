import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/notification_model.dart';
import '../repositories/notifications_repository.dart';

final notificationsRepositoryProvider = Provider((ref) => NotificationsRepository());

final notificationsListProvider = FutureProvider.autoDispose<List<AppNotification>>((ref) async {
  return ref.watch(notificationsRepositoryProvider).getNotifications();
});

/// عدد الإشعارات غير المقروءة - يُستخدم لعرض شارة (badge) في الصفحة الرئيسية
final unreadNotificationsCountProvider = FutureProvider.autoDispose<int>((ref) async {
  return ref.watch(notificationsRepositoryProvider).getUnreadCount();
});
