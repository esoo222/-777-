import 'package:dio/dio.dart';
import '../../../core/constants/api_endpoints.dart';
import '../../../core/network/api_client.dart';
import '../models/notification_model.dart';

class NotificationsRepository {
  final Dio _dio = ApiClient.instance.dio;

  Future<List<AppNotification>> getNotifications() async {
    try {
      final res = await _dio.get(ApiEndpoints.notifications);
      final list = res.data is Map ? res.data['results'] : res.data;
      return (list as List).map((e) => AppNotification.fromJson(e)).toList();
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<int> getUnreadCount() async {
    try {
      final res = await _dio.get(ApiEndpoints.unreadCount);
      return res.data['unread_count'] as int;
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<void> markRead(int id) async {
    try {
      await _dio.post(ApiEndpoints.markRead(id));
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<void> markAllRead() async {
    try {
      await _dio.post(ApiEndpoints.markAllRead);
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }
}
