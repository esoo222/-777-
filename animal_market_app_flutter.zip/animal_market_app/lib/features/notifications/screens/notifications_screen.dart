import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:go_router/go_router.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/common_widgets.dart';
import '../models/notification_model.dart';
import '../providers/notifications_provider.dart';

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  IconData _iconFor(String type) {
    switch (type) {
      case 'like':
        return Icons.favorite;
      case 'comment':
        return Icons.mode_comment;
      case 'follow':
        return Icons.person_add;
      case 'message':
        return Icons.chat_bubble;
      case 'rating':
        return Icons.star;
      default:
        return Icons.notifications;
    }
  }

  Color _colorFor(String type) {
    switch (type) {
      case 'like':
        return AppColors.like;
      case 'comment':
        return AppColors.info;
      case 'follow':
        return AppColors.primary;
      case 'message':
        return AppColors.secondary;
      case 'rating':
        return Colors.amber;
      default:
        return AppColors.lightTextSecondary;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notificationsAsync = ref.watch(notificationsListProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الإشعارات'),
        actions: [
          TextButton(
            onPressed: () async {
              await ref.read(notificationsRepositoryProvider).markAllRead();
              ref.invalidate(notificationsListProvider);
              ref.invalidate(unreadNotificationsCountProvider);
            },
            child: const Text('تصنيف الكل كمقروء'),
          ),
        ],
      ),
      body: notificationsAsync.when(
        loading: () => const AppLoader(),
        error: (e, _) => ErrorRetryWidget(message: e.toString(), onRetry: () => ref.invalidate(notificationsListProvider)),
        data: (notifications) {
          if (notifications.isEmpty) {
            return const EmptyState(icon: Icons.notifications_none, title: 'لا توجد إشعارات بعد');
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(notificationsListProvider),
            child: ListView.separated(
              itemCount: notifications.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final n = notifications[index];
                return _buildTile(context, ref, n);
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildTile(BuildContext context, WidgetRef ref, AppNotification n) {
    return ListTile(
      tileColor: n.isRead ? null : AppColors.primary.withOpacity(0.05),
      leading: Stack(
        children: [
          CircleAvatar(
            backgroundColor: AppColors.primary.withOpacity(0.15),
            backgroundImage: n.senderAvatar != null ? CachedNetworkImageProvider(n.senderAvatar!) : null,
            child: n.senderAvatar == null ? const Icon(Icons.person, color: AppColors.primary) : null,
          ),
          Positioned(
            bottom: -2,
            right: -2,
            child: CircleAvatar(
              radius: 10,
              backgroundColor: _colorFor(n.notifType),
              child: Icon(_iconFor(n.notifType), size: 12, color: Colors.white),
            ),
          ),
        ],
      ),
      title: Text(n.message),
      subtitle: Text(timeago.format(n.createdAt, locale: 'ar'), style: Theme.of(context).textTheme.bodySmall),
      onTap: () async {
        await ref.read(notificationsRepositoryProvider).markRead(n.id);
        ref.invalidate(unreadNotificationsCountProvider);
        if (n.animalId != null) {
          if (context.mounted) context.push('/animal/${n.animalId}');
        } else if (n.notifType == 'follow' && n.senderId != null) {
          if (context.mounted) context.push('/seller/${n.senderId}');
        } else if (n.notifType == 'message') {
          if (context.mounted) context.push('/chat');
        }
      },
    );
  }
}
