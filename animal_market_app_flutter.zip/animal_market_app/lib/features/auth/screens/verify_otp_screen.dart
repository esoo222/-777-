import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/common_widgets.dart';
import '../providers/auth_provider.dart';

/// شاشة إدخال رمز OTP المرسل للبريد - تُستخدم عند التسجيل واستعادة كلمة المرور
class VerifyOtpScreen extends ConsumerStatefulWidget {
  final String email;
  final String purpose; // register | reset_password

  const VerifyOtpScreen({super.key, required this.email, this.purpose = 'register'});

  @override
  ConsumerState<VerifyOtpScreen> createState() => _VerifyOtpScreenState();
}

class _VerifyOtpScreenState extends ConsumerState<VerifyOtpScreen> {
  final List<TextEditingController> _controllers = List.generate(6, (_) => TextEditingController());
  final List<FocusNode> _focusNodes = List.generate(6, (_) => FocusNode());
  bool _isLoading = false;
  int _secondsRemaining = 60;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startResendTimer();
  }

  void _startResendTimer() {
    _secondsRemaining = 60;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_secondsRemaining == 0) {
        timer.cancel();
      } else {
        setState(() => _secondsRemaining--);
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    for (final c in _controllers) {
      c.dispose();
    }
    for (final f in _focusNodes) {
      f.dispose();
    }
    super.dispose();
  }

  String get _code => _controllers.map((c) => c.text).join();

  Future<void> _handleVerify() async {
    if (_code.length != AppConstants.otpLength) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى إدخال الرمز كاملاً (6 أرقام)'), backgroundColor: AppColors.error),
      );
      return;
    }

    setState(() => _isLoading = true);
    try {
      if (widget.purpose == 'register') {
        final success = await ref.read(authNotifierProvider.notifier).verifyOtpAndLogin(widget.email, _code);
        if (!mounted) return;
        if (success) {
          context.go('/onboarding');
        } else {
          final error = ref.read(authNotifierProvider).errorMessage ?? 'رمز التحقق غير صحيح';
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error), backgroundColor: AppColors.error));
        }
      } else {
        // استعادة كلمة المرور: ننتقل لشاشة تعيين كلمة مرور جديدة مع الرمز
        if (!mounted) return;
        context.push('/reset-password', extra: {'email': widget.email, 'code': _code});
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _resendCode() async {
    try {
      await ref.read(authRepositoryProvider).resendOtp(email: widget.email, purpose: widget.purpose);
      _startResendTimer();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرسال رمز جديد إلى بريدك')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التحقق من الرمز')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppDimens.paddingL),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Icon(Icons.mark_email_read_outlined, size: 64, color: AppColors.primary),
              const SizedBox(height: 16),
              Text(
                'تم إرسال رمز التحقق إلى',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              Text(
                widget.email,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(6, (index) {
                  return Container(
                    width: 44,
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    child: TextFormField(
                      controller: _controllers[index],
                      focusNode: _focusNodes[index],
                      textAlign: TextAlign.center,
                      keyboardType: TextInputType.number,
                      maxLength: 1,
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      decoration: const InputDecoration(counterText: ''),
                      onChanged: (value) {
                        if (value.isNotEmpty && index < 5) {
                          _focusNodes[index + 1].requestFocus();
                        } else if (value.isEmpty && index > 0) {
                          _focusNodes[index - 1].requestFocus();
                        }
                      },
                    ),
                  );
                }),
              ),
              const SizedBox(height: 32),
              PrimaryButton(label: 'تأكيد', isLoading: _isLoading, onPressed: _handleVerify),
              const SizedBox(height: 16),
              TextButton(
                onPressed: _secondsRemaining == 0 ? _resendCode : null,
                child: Text(_secondsRemaining == 0 ? 'إعادة إرسال الرمز' : 'إعادة الإرسال بعد $_secondsRemaining ثانية'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
