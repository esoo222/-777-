import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/network/token_storage.dart';
import '../repositories/auth_repository.dart';

final authRepositoryProvider = Provider((ref) => AuthRepository());

enum AuthStatus { unknown, authenticated, unauthenticated }

const _usernamePrefKey = 'current_username';

class AuthState {
  final AuthStatus status;
  final bool isLoading;
  final String? errorMessage;
  final String? username;

  const AuthState({this.status = AuthStatus.unknown, this.isLoading = false, this.errorMessage, this.username});

  AuthState copyWith({AuthStatus? status, bool? isLoading, String? errorMessage, String? username}) {
    return AuthState(
      status: status ?? this.status,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage,
      username: username ?? this.username,
    );
  }
}

/// مزود حالة تسجيل الدخول العام للتطبيق - يقرر أي شاشة تظهر أولاً (تسجيل دخول أم الرئيسية)
class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepository _repository;
  AuthNotifier(this._repository) : super(const AuthState()) {
    _checkInitialAuth();
  }

  Future<void> _checkInitialAuth() async {
    final hasTokens = await TokenStorage.hasTokens();
    final prefs = await SharedPreferences.getInstance();
    final savedUsername = prefs.getString(_usernamePrefKey);
    state = state.copyWith(
      status: hasTokens ? AuthStatus.authenticated : AuthStatus.unauthenticated,
      username: savedUsername,
    );
  }

  Future<void> _persistUsername(String username) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_usernamePrefKey, username);
  }

  Future<bool> login(String email, String password) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final user = await _repository.login(email: email, password: password);
      await _persistUsername(user.username);
      state = state.copyWith(isLoading: false, status: AuthStatus.authenticated, username: user.username);
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
      return false;
    }
  }

  /// بعد تفعيل OTP نجلب الملف الشخصي لمعرفة اسم المستخدم (يُستخدم لتمييز رسائلي في الدردشة)
  Future<bool> verifyOtpAndLogin(String email, String code) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      await _repository.verifyOtp(email: email, code: code, purpose: 'register');
      state = state.copyWith(isLoading: false, status: AuthStatus.authenticated);
      try {
        final profile = await _repository.fetchMyProfileUsername();
        if (profile != null) setUsername(profile);
      } catch (_) {}
      return true;
    } catch (e) {
      state = state.copyWith(isLoading: false, errorMessage: e.toString());
      return false;
    }
  }

  void setUsername(String username) {
    _persistUsername(username);
    state = state.copyWith(username: username);
  }

  Future<void> logout() async {
    await _repository.logout();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_usernamePrefKey);
    state = state.copyWith(status: AuthStatus.unauthenticated, username: null);
  }
}

final authNotifierProvider = StateNotifierProvider<AuthNotifier, AuthState>(
  (ref) => AuthNotifier(ref.watch(authRepositoryProvider)),
);
