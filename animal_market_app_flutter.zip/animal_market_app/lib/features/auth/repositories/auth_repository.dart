import 'package:dio/dio.dart';
import '../../../core/constants/api_endpoints.dart';
import '../../../core/network/api_client.dart';
import '../../../core/network/token_storage.dart';
import '../models/user_model.dart';

class AuthRepository {
  final Dio _dio = ApiClient.instance.dio;

  /// التسجيل بالبريد الإلكتروني - يرسل رمز OTP تلقائياً
  Future<String> register({
    required String email,
    required String username,
    required String password,
    required String passwordConfirm,
  }) async {
    try {
      final res = await _dio.post(ApiEndpoints.register, data: {
        'email': email,
        'username': username,
        'password': password,
        'password_confirm': passwordConfirm,
      });
      return res.data['message'] as String;
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  /// التحقق من رمز OTP - يُفعّل الحساب ويحفظ التوكنات مباشرة
  Future<void> verifyOtp({required String email, required String code, String purpose = 'register'}) async {
    try {
      final res = await _dio.post(ApiEndpoints.verifyOtp, data: {
        'email': email,
        'code': code,
        'purpose': purpose,
      });
      if (purpose == 'register') {
        await TokenStorage.saveTokens(access: res.data['access'], refresh: res.data['refresh']);
      }
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<void> resendOtp({required String email, String purpose = 'register'}) async {
    try {
      await _dio.post(ApiEndpoints.resendOtp, data: {'email': email, 'purpose': purpose});
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  /// تسجيل الدخول - يحفظ التوكنات محلياً
  Future<AppUser> login({required String email, required String password}) async {
    try {
      final res = await _dio.post(ApiEndpoints.login, data: {'email': email, 'password': password});
      await TokenStorage.saveTokens(access: res.data['access'], refresh: res.data['refresh']);
      return AppUser.fromJson(res.data['user']);
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<void> forgotPassword({required String email}) async {
    try {
      await _dio.post(ApiEndpoints.forgotPassword, data: {'email': email});
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<void> resetPassword({required String email, required String code, required String newPassword}) async {
    try {
      await _dio.post(ApiEndpoints.resetPassword, data: {
        'email': email,
        'code': code,
        'new_password': newPassword,
      });
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<void> changePassword({required String oldPassword, required String newPassword}) async {
    try {
      await _dio.post(ApiEndpoints.changePassword, data: {
        'old_password': oldPassword,
        'new_password': newPassword,
      });
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<void> logout() async {
    await TokenStorage.clear();
  }

  /// يجلب اسم المستخدم الحالي عبر /accounts/me/ (يُستخدم بعد تفعيل OTP مباشرة لتمييز رسائل الدردشة)
  Future<String?> fetchMyProfileUsername() async {
    try {
      final res = await _dio.get(ApiEndpoints.myProfile);
      return res.data['username'] as String?;
    } catch (_) {
      return null;
    }
  }
}
