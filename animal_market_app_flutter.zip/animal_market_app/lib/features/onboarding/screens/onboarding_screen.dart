import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/common_widgets.dart';

class _OnboardPage {
  final IconData icon;
  final String title;
  final String description;
  _OnboardPage({required this.icon, required this.title, required this.description});
}

final _pages = [
  _OnboardPage(
    icon: Icons.pets,
    title: 'كل أنواع الحيوانات في مكان واحد',
    description: 'أغنام، ماعز، أبقار، خيول، دواجن وطيور... تصفّح آلاف الإعلانات من كل محافظات العراق',
  ),
  _OnboardPage(
    icon: Icons.camera_alt_outlined,
    title: 'أضف إعلانك بسهولة',
    description: 'ارفع حتى 10 صور لحيوانك، حدد السعر والمحافظة، وابدأ البيع خلال دقائق',
  ),
  _OnboardPage(
    icon: Icons.chat_bubble_outline,
    title: 'تواصل مباشرة مع البائعين',
    description: 'دردشة فورية، إشعارات لحظية، وتقييم للبائعين لضمان تجربة شراء آمنة',
  ),
];

/// شاشات تعريفية تظهر للمستخدم الجديد قبل تسجيل الدخول
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int _currentPage = 0;

  void _next() {
    if (_currentPage < _pages.length - 1) {
      _controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
    } else {
      context.go('/login');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton(onPressed: () => context.go('/login'), child: const Text('تخطي')),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                onPageChanged: (i) => setState(() => _currentPage = i),
                itemCount: _pages.length,
                itemBuilder: (context, index) {
                  final page = _pages[index];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: AppDimens.paddingL),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 160,
                          height: 160,
                          decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), shape: BoxShape.circle),
                          child: Icon(page.icon, size: 80, color: AppColors.primary),
                        ),
                        const SizedBox(height: 32),
                        Text(page.title, style: Theme.of(context).textTheme.headlineSmall, textAlign: TextAlign.center),
                        const SizedBox(height: 12),
                        Text(page.description, style: Theme.of(context).textTheme.bodyMedium, textAlign: TextAlign.center),
                      ],
                    ),
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_pages.length, (i) {
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: _currentPage == i ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _currentPage == i ? AppColors.primary : AppColors.lightDivider,
                    borderRadius: BorderRadius.circular(4),
                  ),
                );
              }),
            ),
            Padding(
              padding: const EdgeInsets.all(AppDimens.paddingL),
              child: PrimaryButton(
                label: _currentPage == _pages.length - 1 ? 'ابدأ الآن' : 'التالي',
                onPressed: _next,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
