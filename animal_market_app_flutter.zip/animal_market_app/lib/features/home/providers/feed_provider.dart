import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/animal_model.dart';
import '../models/core_models.dart';
import '../repositories/animal_repository.dart';
import '../repositories/core_repository.dart';

final coreRepositoryProvider = Provider((ref) => CoreRepository());
final animalRepositoryProvider = Provider((ref) => AnimalRepository());

final governoratesProvider = FutureProvider<List<Governorate>>((ref) async {
  return ref.watch(coreRepositoryProvider).getGovernorates();
});

final categoriesProvider = FutureProvider<List<AnimalCategory>>((ref) async {
  return ref.watch(coreRepositoryProvider).getCategories();
});

/// فلاتر البحث/التصفح الحالية للصفحة الرئيسية
class FeedFilters {
  final String? search;
  final int? governorate;
  final int? category;
  final String? gender;
  final num? minPrice;
  final num? maxPrice;
  final int? minAge;
  final int? maxAge;

  const FeedFilters({
    this.search,
    this.governorate,
    this.category,
    this.gender,
    this.minPrice,
    this.maxPrice,
    this.minAge,
    this.maxAge,
  });

  FeedFilters copyWith({
    String? search,
    int? governorate,
    int? category,
    String? gender,
    num? minPrice,
    num? maxPrice,
    int? minAge,
    int? maxAge,
    bool clear = false,
  }) {
    if (clear) return const FeedFilters();
    return FeedFilters(
      search: search ?? this.search,
      governorate: governorate ?? this.governorate,
      category: category ?? this.category,
      gender: gender ?? this.gender,
      minPrice: minPrice ?? this.minPrice,
      maxPrice: maxPrice ?? this.maxPrice,
      minAge: minAge ?? this.minAge,
      maxAge: maxAge ?? this.maxAge,
    );
  }
}

final feedFiltersProvider = StateProvider<FeedFilters>((ref) => const FeedFilters());

/// حالة قائمة الإعلانات في الصفحة الرئيسية مع دعم التحميل التدريجي (Pagination)
class FeedState {
  final List<Animal> animals;
  final bool isLoading;
  final bool isLoadingMore;
  final String? error;
  final String? nextUrl;

  const FeedState({
    this.animals = const [],
    this.isLoading = false,
    this.isLoadingMore = false,
    this.error,
    this.nextUrl,
  });

  FeedState copyWith({
    List<Animal>? animals,
    bool? isLoading,
    bool? isLoadingMore,
    String? error,
    String? nextUrl,
    bool clearError = false,
  }) {
    return FeedState(
      animals: animals ?? this.animals,
      isLoading: isLoading ?? this.isLoading,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
      error: clearError ? null : (error ?? this.error),
      nextUrl: nextUrl,
    );
  }
}

class FeedNotifier extends StateNotifier<FeedState> {
  final AnimalRepository _repository;
  final Ref _ref;

  FeedNotifier(this._repository, this._ref) : super(const FeedState()) {
    loadFeed();
  }

  Future<void> loadFeed() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final filters = _ref.read(feedFiltersProvider);
      final result = await _repository.getAnimals(
        search: filters.search,
        governorate: filters.governorate,
        category: filters.category,
        gender: filters.gender,
        minPrice: filters.minPrice,
        maxPrice: filters.maxPrice,
        minAge: filters.minAge,
        maxAge: filters.maxAge,
      );
      state = state.copyWith(animals: result.results, isLoading: false, nextUrl: result.nextUrl);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<void> loadMore() async {
    if (state.nextUrl == null || state.isLoadingMore) return;
    state = state.copyWith(isLoadingMore: true);
    try {
      final result = await _repository.getAnimals(pageUrl: state.nextUrl);
      state = state.copyWith(
        animals: [...state.animals, ...result.results],
        isLoadingMore: false,
        nextUrl: result.nextUrl,
      );
    } catch (e) {
      state = state.copyWith(isLoadingMore: false);
    }
  }

  Future<void> refresh() => loadFeed();

  /// تحديث فوري لحالة الإعجاب/الحفظ داخل القائمة دون إعادة تحميل كامل (لتجربة استخدام سلسة)
  void toggleLikeLocally(int animalId, bool isLiked) {
    state = state.copyWith(
      animals: state.animals.map((a) {
        if (a.id != animalId) return a;
        return Animal(
          id: a.id, name: a.name, breed: a.breed, ageValue: a.ageValue, ageUnit: a.ageUnit,
          gender: a.gender, price: a.price, isNegotiable: a.isNegotiable, description: a.description,
          contactPhone: a.contactPhone, governorateId: a.governorateId, governorateName: a.governorateName,
          categoryId: a.categoryId, categoryName: a.categoryName, status: a.status, coverImage: a.coverImage,
          images: a.images, sellerId: a.sellerId, sellerUsername: a.sellerUsername, sellerAvatar: a.sellerAvatar,
          likesCount: isLiked ? a.likesCount + 1 : a.likesCount - 1, commentsCount: a.commentsCount,
          savesCount: a.savesCount, viewsCount: a.viewsCount, isLiked: isLiked, isSaved: a.isSaved,
          createdAt: a.createdAt,
        );
      }).toList(),
    );
  }
}

final feedProvider = StateNotifierProvider<FeedNotifier, FeedState>((ref) {
  ref.watch(feedFiltersProvider); // إعادة الإنشاء عند تغيّر الفلاتر
  return FeedNotifier(ref.watch(animalRepositoryProvider), ref);
});
