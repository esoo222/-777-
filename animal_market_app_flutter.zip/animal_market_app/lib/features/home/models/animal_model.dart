class AnimalImage {
  final int id;
  final String imageUrl;
  final bool isCover;

  AnimalImage({required this.id, required this.imageUrl, required this.isCover});

  factory AnimalImage.fromJson(Map<String, dynamic> json) {
    return AnimalImage(
      id: json['id'] as int,
      imageUrl: json['image'] as String,
      isCover: json['is_cover'] as bool? ?? false,
    );
  }
}

/// نموذج إعلان بيع حيوان - يغطي عرض القائمة الرئيسية وتفاصيل الإعلان معاً
class Animal {
  final int id;
  final String name;
  final String breed;
  final int ageValue;
  final String ageUnit; // month | year
  final String gender; // male | female
  final num price;
  final bool isNegotiable;
  final String? description;
  final String? contactPhone;
  final int governorateId;
  final String governorateName;
  final int categoryId;
  final String categoryName;
  final String status;
  final String? coverImage;
  final List<AnimalImage> images;
  final int sellerId;
  final String sellerUsername;
  final String? sellerAvatar;
  final int likesCount;
  final int commentsCount;
  final int savesCount;
  final int viewsCount;
  final bool isLiked;
  final bool isSaved;
  final DateTime createdAt;

  Animal({
    required this.id,
    required this.name,
    required this.breed,
    required this.ageValue,
    required this.ageUnit,
    required this.gender,
    required this.price,
    required this.isNegotiable,
    this.description,
    this.contactPhone,
    required this.governorateId,
    required this.governorateName,
    required this.categoryId,
    required this.categoryName,
    required this.status,
    this.coverImage,
    this.images = const [],
    required this.sellerId,
    required this.sellerUsername,
    this.sellerAvatar,
    required this.likesCount,
    required this.commentsCount,
    required this.savesCount,
    this.viewsCount = 0,
    required this.isLiked,
    required this.isSaved,
    required this.createdAt,
  });

  String get ageLabel => '$ageValue ${ageUnit == 'month' ? 'شهر' : 'سنة'}';
  String get genderLabel => gender == 'male' ? 'ذكر' : 'أنثى';
  String get priceLabel => '${_formatPrice(price)} د.ع';

  static String _formatPrice(num price) {
    final str = price.toInt().toString();
    final buffer = StringBuffer();
    for (int i = 0; i < str.length; i++) {
      if (i > 0 && (str.length - i) % 3 == 0) buffer.write(',');
      buffer.write(str[i]);
    }
    return buffer.toString();
  }

  factory Animal.fromJson(Map<String, dynamic> json) {
    return Animal(
      id: json['id'] as int,
      name: json['name'] as String,
      breed: json['breed'] as String? ?? '',
      ageValue: json['age_value'] as int,
      ageUnit: json['age_unit'] as String,
      gender: json['gender'] as String,
      price: json['price'] as num,
      isNegotiable: json['is_negotiable'] as bool? ?? false,
      description: json['description'] as String?,
      contactPhone: json['contact_phone'] as String?,
      governorateId: json['governorate'] as int,
      governorateName: json['governorate_name'] as String? ?? '',
      categoryId: json['category'] as int,
      categoryName: json['category_name'] as String? ?? '',
      status: json['status'] as String? ?? 'active',
      coverImage: json['cover_image'] as String?,
      images: (json['images'] as List<dynamic>?)
              ?.map((e) => AnimalImage.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
      sellerId: json['seller'] as int,
      sellerUsername: json['seller_username'] as String? ?? '',
      sellerAvatar: json['seller_avatar'] as String?,
      likesCount: json['likes_count'] as int? ?? 0,
      commentsCount: json['comments_count'] as int? ?? 0,
      savesCount: json['saves_count'] as int? ?? 0,
      viewsCount: json['views_count'] as int? ?? 0,
      isLiked: json['is_liked'] as bool? ?? false,
      isSaved: json['is_saved'] as bool? ?? false,
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ?? DateTime.now(),
    );
  }
}

class AnimalComment {
  final int id;
  final int userId;
  final String username;
  final String? avatar;
  final String text;
  final DateTime createdAt;

  AnimalComment({
    required this.id,
    required this.userId,
    required this.username,
    this.avatar,
    required this.text,
    required this.createdAt,
  });

  factory AnimalComment.fromJson(Map<String, dynamic> json) {
    return AnimalComment(
      id: json['id'] as int,
      userId: json['user'] as int,
      username: json['username'] as String,
      avatar: json['avatar'] as String?,
      text: json['text'] as String,
      createdAt: DateTime.tryParse(json['created_at'] as String? ?? '') ?? DateTime.now(),
    );
  }
}
