import 'package:flutter/material.dart' show IconData, Icons;

class Governorate {
  final int id;
  final String nameAr;

  Governorate({required this.id, required this.nameAr});

  factory Governorate.fromJson(Map<String, dynamic> json) {
    return Governorate(id: json['id'] as int, nameAr: json['name_ar'] as String);
  }
}

class AnimalCategory {
  final int id;
  final String nameAr;
  final String slug;
  final String? icon;

  AnimalCategory({required this.id, required this.nameAr, required this.slug, this.icon});

  factory AnimalCategory.fromJson(Map<String, dynamic> json) {
    return AnimalCategory(
      id: json['id'] as int,
      nameAr: json['name_ar'] as String,
      slug: json['slug'] as String,
      icon: json['icon'] as String?,
    );
  }
}

/// أيقونات Material لكل تصنيف حيوان (بديل بصري مؤقت لحين توفر أيقونات مخصصة)
IconData categoryIcon(String slug) {
  switch (slug) {
    case 'sheep':
      return Icons.cruelty_free;
    case 'goats':
      return Icons.pets;
    case 'cows':
      return Icons.emoji_nature;
    case 'buffalo':
      return Icons.emoji_nature;
    case 'horses':
      return Icons.directions_run;
    case 'camels':
      return Icons.landscape;
    case 'poultry':
      return Icons.egg_outlined;
    case 'birds':
      return Icons.flutter_dash;
    case 'cats':
      return Icons.pets;
    case 'dogs':
      return Icons.pets;
    default:
      return Icons.pets;
  }
}
