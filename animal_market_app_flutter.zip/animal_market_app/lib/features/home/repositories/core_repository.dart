import 'package:dio/dio.dart';
import '../../../core/constants/api_endpoints.dart';
import '../../../core/network/api_client.dart';
import 'core_models.dart';

class CoreRepository {
  final Dio _dio = ApiClient.instance.dio;

  Future<List<Governorate>> getGovernorates() async {
    try {
      final res = await _dio.get(ApiEndpoints.governorates);
      return (res.data as List).map((e) => Governorate.fromJson(e)).toList();
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<List<AnimalCategory>> getCategories() async {
    try {
      final res = await _dio.get(ApiEndpoints.categories);
      return (res.data as List).map((e) => AnimalCategory.fromJson(e)).toList();
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }
}
