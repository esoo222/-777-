import 'package:dio/dio.dart';
import '../../../core/constants/api_endpoints.dart';
import '../../../core/network/api_client.dart';
import 'package:image_picker/image_picker.dart';
import '../models/animal_model.dart';

/// نتيجة صفحة من الإعلانات مع رابط الصفحة التالية (Pagination من Django REST Framework)
class PaginatedAnimals {
  final List<Animal> results;
  final String? nextUrl;
  final int count;

  PaginatedAnimals({required this.results, this.nextUrl, required this.count});
}

class AnimalRepository {
  final Dio _dio = ApiClient.instance.dio;

  /// جلب قائمة الإعلانات مع دعم الفلاتر: المحافظة، النوع، السعر، العمر، الجنس، البحث النصي
  Future<PaginatedAnimals> getAnimals({
    String? search,
    int? governorate,
    int? category,
    String? gender,
    num? minPrice,
    num? maxPrice,
    int? minAge,
    int? maxAge,
    String? ordering,
    String? pageUrl,
  }) async {
    try {
      final res = pageUrl != null
          ? await _dio.get(pageUrl)
          : await _dio.get(ApiEndpoints.animals, queryParameters: {
              if (search != null && search.isNotEmpty) 'search': search,
              if (governorate != null) 'governorate': governorate,
              if (category != null) 'category': category,
              if (gender != null) 'gender': gender,
              if (minPrice != null) 'min_price': minPrice,
              if (maxPrice != null) 'max_price': maxPrice,
              if (minAge != null) 'min_age': minAge,
              if (maxAge != null) 'max_age': maxAge,
              if (ordering != null) 'ordering': ordering,
            });

      return PaginatedAnimals(
        results: (res.data['results'] as List).map((e) => Animal.fromJson(e)).toList(),
        nextUrl: res.data['next'] as String?,
        count: res.data['count'] as int? ?? 0,
      );
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<Animal> getAnimalDetail(int id) async {
    try {
      final res = await _dio.get(ApiEndpoints.animalDetail(id));
      return Animal.fromJson(res.data);
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<Animal> createAnimal({
    required int categoryId,
    required int governorateId,
    required String name,
    required String breed,
    required int ageValue,
    required String ageUnit,
    required String gender,
    required num price,
    required bool isNegotiable,
    required String description,
    required String contactPhone,
    required List<XFile> images,
  }) async {
    try {
      final formData = FormData.fromMap({
        'category': categoryId,
        'governorate': governorateId,
        'name': name,
        'breed': breed,
        'age_value': ageValue,
        'age_unit': ageUnit,
        'gender': gender,
        'price': price,
        'is_negotiable': isNegotiable,
        'description': description,
        'contact_phone': contactPhone,
        'uploaded_images': [
          for (final img in images) await MultipartFile.fromFile(img.path, filename: img.name),
        ],
      });
      final res = await _dio.post(ApiEndpoints.animals, data: formData);
      return Animal.fromJson(res.data);
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<void> deleteAnimal(int id) async {
    try {
      await _dio.delete(ApiEndpoints.animalDetail(id));
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<bool> toggleLike(int animalId) async {
    try {
      final res = await _dio.post(ApiEndpoints.animalLike(animalId));
      return res.data['is_liked'] as bool;
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<bool> toggleSave(int animalId) async {
    try {
      final res = await _dio.post(ApiEndpoints.animalSave(animalId));
      return res.data['is_saved'] as bool;
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<List<AnimalComment>> getComments(int animalId) async {
    try {
      final res = await _dio.get(ApiEndpoints.animalComments(animalId));
      final list = res.data is Map ? res.data['results'] : res.data;
      return (list as List).map((e) => AnimalComment.fromJson(e)).toList();
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<AnimalComment> addComment(int animalId, String text) async {
    try {
      final res = await _dio.post(ApiEndpoints.animalComments(animalId), data: {'text': text});
      return AnimalComment.fromJson(res.data);
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<void> reportAnimal(int animalId, {required String reason, String? details}) async {
    try {
      await _dio.post(ApiEndpoints.animalReport(animalId), data: {
        'reason': reason,
        if (details != null) 'details': details,
      });
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }

  Future<PaginatedAnimals> getMyAnimals() async {
    try {
      final res = await _dio.get(ApiEndpoints.myAnimals);
      return PaginatedAnimals(
        results: (res.data['results'] as List).map((e) => Animal.fromJson(e)).toList(),
        nextUrl: res.data['next'] as String?,
        count: res.data['count'] as int? ?? 0,
      );
    } on DioException catch (e) {
      throw ApiClient.parseError(e);
    }
  }
}
