import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:go_router/go_router.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../../core/constants/app_constants.dart';
import '../models/animal_model.dart';
import '../providers/feed_provider.dart';

/// بطاقة إعلان في الصفحة الرئيسية - تصميم مستوحى من إنستغرام
/// (رأس البائع، صورة الحيوان، شريط تفاعل: إعجاب/تعليق/مشاركة/حفظ)
class AnimalFeedCard extends ConsumerWidget {
  final Animal animal;

  const AnimalFeedCard({super.key, required this.animal});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 0, vertical: 6),
      clipBehavior: Clip.antiAlias,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(context),
          _buildImage(context),
          _buildActionsBar(context, ref),
          _buildInfo(context),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: InkWell(
        onTap: () => context.push('/seller/${animal.sellerId}'),
        child: Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: AppColors.primary.withOpacity(0.15),
              backgroundImage: animal.sellerAvatar != null ? CachedNetworkImageProvider(animal.sellerAvatar!) : null,
              child: animal.sellerAvatar == null ? const Icon(Icons.person, color: AppColors.primary) : null,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(animal.sellerUsername, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  Text(
                    '${animal.governorateName} · ${timeago.format(animal.createdAt, locale: 'ar')}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(animal.categoryName, style: const TextStyle(color: AppColors.primary, fontSize: 12, fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImage(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/animal/${animal.id}'),
      child: AspectRatio(
        aspectRatio: 1,
        child: animal.coverImage != null
            ? CachedNetworkImage(
                imageUrl: animal.coverImage!,
                fit: BoxFit.cover,
                placeholder: (context, url) => Container(color: Theme.of(context).colorScheme.surface),
                errorWidget: (context, url, error) => const Icon(Icons.image_not_supported_outlined),
              )
            : Container(
                color: AppColors.primary.withOpacity(0.05),
                child: const Icon(Icons.pets, size: 64, color: AppColors.primary),
              ),
      ),
    );
  }

  Widget _buildActionsBar(BuildContext context, WidgetRef ref) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      child: Row(
        children: [
          IconButton(
            icon: Icon(
              animal.isLiked ? Icons.favorite : Icons.favorite_border,
              color: animal.isLiked ? AppColors.like : null,
            ),
            onPressed: () async {
              ref.read(feedProvider.notifier).toggleLikeLocally(animal.id, !animal.isLiked);
              await ref.read(animalRepositoryProvider).toggleLike(animal.id);
            },
          ),
          IconButton(
            icon: const Icon(Icons.mode_comment_outlined),
            onPressed: () => context.push('/animal/${animal.id}', extra: {'openComments': true}),
          ),
          IconButton(
            icon: const Icon(Icons.share_outlined),
            onPressed: () {
              // مشاركة الإعلان - يمكن ربطه بحزمة share_plus
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ رابط الإعلان')));
            },
          ),
          const Spacer(),
          IconButton(
            icon: Icon(animal.isSaved ? Icons.bookmark : Icons.bookmark_border),
            onPressed: () => ref.read(animalRepositoryProvider).toggleSave(animal.id),
          ),
        ],
      ),
    );
  }

  Widget _buildInfo(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('${animal.likesCount} إعجاب', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          const SizedBox(height: 4),
          RichText(
            text: TextSpan(
              style: DefaultTextStyle.of(context).style,
              children: [
                TextSpan(text: '${animal.name} ', style: const TextStyle(fontWeight: FontWeight.bold)),
                TextSpan(text: '- ${animal.breed} - ${animal.ageLabel} - ${animal.genderLabel}'),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Text(
            animal.priceLabel + (animal.isNegotiable ? ' (قابل للتفاوض)' : ''),
            style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold, fontSize: 15),
          ),
          if (animal.commentsCount > 0) ...[
            const SizedBox(height: 4),
            InkWell(
              onTap: () => context.push('/animal/${animal.id}', extra: {'openComments': true}),
              child: Text('عرض كل التعليقات (${animal.commentsCount})', style: Theme.of(context).textTheme.bodySmall),
            ),
          ],
        ],
      ),
    );
  }
}
