/// روابط البيئة - يمكن تغييرها بسهولة بين التطوير والإنتاج
/// في التطبيق الحقيقي تُقرأ هذه القيم من ملف .env عبر flutter_dotenv
class EnvConfig {
  EnvConfig._();

  // عدّل هذا الرابط ليطابق سيرفر الـ Backend الخاص بك
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://127.0.0.1:8000/api',
  );

  static const String wsBaseUrl = String.fromEnvironment(
    'WS_BASE_URL',
    defaultValue: 'ws://127.0.0.1:8000/ws',
  );
}
