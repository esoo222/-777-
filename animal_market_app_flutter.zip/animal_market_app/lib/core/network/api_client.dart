import 'package:dio/dio.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';
import 'env_config.dart';
import 'token_storage.dart';

/// استثناء موحّد لأخطاء الـ API لعرض رسائل عربية واضحة للمستخدم
class ApiException implements Exception {
  final String message;
  final int? statusCode;
  ApiException(this.message, {this.statusCode});

  @override
  String toString() => message;
}

/// عميل الشبكة المركزي - يُضاف تلقائياً توكن JWT لكل طلب،
/// ويحاول تجديد التوكن عند انتهاء صلاحيته (401) قبل إعادة المحاولة مرة واحدة
class ApiClient {
  ApiClient._internal() {
    _dio = Dio(
      BaseOptions(
        baseUrl: EnvConfig.apiBaseUrl,
        connectTimeout: const Duration(seconds: 15),
        receiveTimeout: const Duration(seconds: 15),
        headers: {'Content-Type': 'application/json'},
      ),
    );

    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await TokenStorage.getAccessToken();
          if (token != null) {
            options.headers['Authorization'] = 'Bearer $token';
          }
          handler.next(options);
        },
        onError: (error, handler) async {
          if (error.response?.statusCode == 401) {
            final refreshed = await _tryRefreshToken();
            if (refreshed) {
              final newToken = await TokenStorage.getAccessToken();
              error.requestOptions.headers['Authorization'] = 'Bearer $newToken';
              try {
                final response = await _dio.fetch(error.requestOptions);
                return handler.resolve(response);
              } catch (_) {
                // تابع لإرجاع الخطأ الأصلي
              }
            }
          }
          handler.next(error);
        },
      ),
    );

    _dio.interceptors.add(
      PrettyDioLogger(requestBody: true, responseBody: true, error: true),
    );
  }

  static final ApiClient instance = ApiClient._internal();
  late final Dio _dio;

  Dio get dio => _dio;

  Future<bool> _tryRefreshToken() async {
    try {
      final refresh = await TokenStorage.getRefreshToken();
      if (refresh == null) return false;

      final response = await Dio(BaseOptions(baseUrl: EnvConfig.apiBaseUrl)).post(
        '/accounts/token/refresh/',
        data: {'refresh': refresh},
      );
      final newAccess = response.data['access'] as String;
      await TokenStorage.updateAccessToken(newAccess);
      return true;
    } catch (_) {
      await TokenStorage.clear();
      return false;
    }
  }

  /// يحوّل أي خطأ Dio إلى ApiException برسالة عربية مفهومة
  static ApiException parseError(DioException e) {
    if (e.response?.data is Map) {
      final data = e.response!.data as Map;
      // DRF يرجع أخطاء بأشكال متعددة: {"error": "..."} أو {"field": ["..."]}
      if (data['error'] != null) return ApiException(data['error'].toString(), statusCode: e.response?.statusCode);
      if (data['message'] != null) return ApiException(data['message'].toString(), statusCode: e.response?.statusCode);
      if (data['detail'] != null) return ApiException(data['detail'].toString(), statusCode: e.response?.statusCode);

      final firstKey = data.keys.isNotEmpty ? data.keys.first : null;
      if (firstKey != null && data[firstKey] is List && (data[firstKey] as List).isNotEmpty) {
        return ApiException(data[firstKey][0].toString(), statusCode: e.response?.statusCode);
      }
    }
    if (e.type == DioExceptionType.connectionTimeout || e.type == DioExceptionType.receiveTimeout) {
      return ApiException('انتهت مهلة الاتصال بالسيرفر، تحقق من الإنترنت');
    }
    if (e.type == DioExceptionType.connectionError) {
      return ApiException('تعذر الاتصال بالسيرفر، تحقق من اتصال الإنترنت');
    }
    return ApiException('حدث خطأ غير متوقع، حاول مرة أخرى', statusCode: e.response?.statusCode);
  }
}
