import 'package:flutter/material.dart';

/// اسم التطبيق وثوابته العامة
class AppConstants {
  static const String appName = 'بيع حيوانات';
  static const String appNameEn = 'Bai Haywanat';

  // حدود رفع الصور
  static const int maxAnimalImages = 10;
  static const int maxCommentLength = 500;
  static const int maxDescriptionLength = 2000;

  // OTP
  static const int otpLength = 6;
  static const int otpExpiryMinutes = 10;

  // Pagination
  static const int pageSize = 20;
}

/// ألوان التطبيق - هوية بصرية مستوحاة من الطبيعة والمواشي
class AppColors {
  // اللون الأساسي (أخضر ريفي)
  static const Color primary = Color(0xFF2E7D32);
  static const Color primaryDark = Color(0xFF1B5E20);
  static const Color primaryLight = Color(0xFF60AD5E);

  // اللون الثانوي (بني ترابي - يرمز للمواشي والأرض)
  static const Color secondary = Color(0xFFB8794E);
  static const Color secondaryDark = Color(0xFF8A5A38);

  // ألوان الحالة
  static const Color success = Color(0xFF43A047);
  static const Color error = Color(0xFFE53935);
  static const Color warning = Color(0xFFFB8C00);
  static const Color info = Color(0xFF1E88E5);

  // ألوان محايدة - الوضع الفاتح
  static const Color lightBackground = Color(0xFFFAFAF7);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightTextPrimary = Color(0xFF1C1C1C);
  static const Color lightTextSecondary = Color(0xFF6E6E6E);
  static const Color lightDivider = Color(0xFFE0E0E0);

  // ألوان محايدة - الوضع الداكن
  static const Color darkBackground = Color(0xFF121212);
  static const Color darkSurface = Color(0xFF1E1E1E);
  static const Color darkTextPrimary = Color(0xFFF5F5F5);
  static const Color darkTextSecondary = Color(0xFFB0B0B0);
  static const Color darkDivider = Color(0xFF2C2C2C);

  static const Color like = Color(0xFFE53935);
  static const Color verified = Color(0xFF1E88E5);
}

class AppDimens {
  static const double paddingXS = 4;
  static const double paddingS = 8;
  static const double paddingM = 16;
  static const double paddingL = 24;
  static const double paddingXL = 32;

  static const double radiusS = 8;
  static const double radiusM = 12;
  static const double radiusL = 16;
  static const double radiusXL = 24;

  static const double avatarS = 32;
  static const double avatarM = 44;
  static const double avatarL = 80;
  static const double avatarXL = 110;
}
