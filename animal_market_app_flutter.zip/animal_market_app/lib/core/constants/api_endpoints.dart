/// كل مسارات الـ API في مكان واحد لسهولة الصيانة
class ApiEndpoints {
  ApiEndpoints._();

  // ==================== الحسابات ====================
  static const String register = '/accounts/register/';
  static const String verifyOtp = '/accounts/verify-otp/';
  static const String resendOtp = '/accounts/resend-otp/';
  static const String login = '/accounts/login/';
  static const String tokenRefresh = '/accounts/token/refresh/';
  static const String forgotPassword = '/accounts/forgot-password/';
  static const String resetPassword = '/accounts/reset-password/';
  static const String changePassword = '/accounts/change-password/';
  static const String myProfile = '/accounts/me/';
  static String publicProfile(int userId) => '/accounts/users/$userId/';
  static String followToggle(int userId) => '/accounts/users/$userId/follow/';
  static String rateSeller(int userId) => '/accounts/users/$userId/rate/';
  static String blockUser(int userId) => '/accounts/users/$userId/block/';

  // ==================== الأساسيات ====================
  static const String governorates = '/core/governorates/';
  static const String categories = '/core/categories/';
  static const String adminStats = '/core/admin/stats/';

  // ==================== الإعلانات ====================
  static const String animals = '/animals/';
  static String animalDetail(int id) => '/animals/$id/';
  static String animalLike(int id) => '/animals/$id/like/';
  static String animalSave(int id) => '/animals/$id/save/';
  static String animalComments(int id) => '/animals/$id/comments/';
  static String animalReport(int id) => '/animals/$id/report/';
  static const String myAnimals = '/animals/my_animals/';
  static const String favorites = '/animals/favorites/';
  static String deleteComment(int id) => '/animals/comments/$id/';

  // ==================== الدردشة ====================
  static const String conversations = '/chat/conversations/';
  static const String startConversation = '/chat/conversations/start/';
  static String conversationMessages(int id) => '/chat/conversations/$id/messages/';
  static const String chatUploadImage = '/chat/upload-image/';

  // ==================== الإشعارات ====================
  static const String notifications = '/notifications/';
  static const String unreadCount = '/notifications/unread-count/';
  static const String markAllRead = '/notifications/read-all/';
  static String markRead(int id) => '/notifications/$id/read/';
}
