import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/splash/screens/splash_screen.dart';
import '../../features/onboarding/screens/onboarding_screen.dart';
import '../../features/auth/screens/login_screen.dart';
import '../../features/auth/screens/register_screen.dart';
import '../../features/auth/screens/verify_otp_screen.dart';
import '../../features/auth/screens/password_recovery_screens.dart';
import '../../features/animal_details/screens/animal_details_screen.dart';
import '../../features/add_animal/screens/add_animal_screen.dart';
import '../../features/search/screens/search_screen.dart';
import '../../features/profile/screens/profile_screen.dart';
import '../../features/profile/screens/edit_profile_screen.dart';
import '../../features/chat/screens/conversations_list_screen.dart';
import '../../features/chat/screens/chat_conversation_screen.dart';
import '../../features/chat/providers/chat_provider.dart';
import '../../features/notifications/screens/notifications_screen.dart';
import '../../features/settings/screens/settings_screen.dart';
import '../../features/settings/screens/change_password_screen.dart';
import '../../features/legal/screens/legal_screens.dart';
import '../widgets/common_widgets.dart';
import 'main_shell.dart';

final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/splash',
    routes: [
      GoRoute(path: '/splash', builder: (context, state) => const SplashScreen()),
      GoRoute(path: '/onboarding', builder: (context, state) => const OnboardingScreen()),

      // المصادقة
      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
      GoRoute(path: '/register', builder: (context, state) => const RegisterScreen()),
      GoRoute(
        path: '/verify-otp',
        builder: (context, state) {
          final extra = state.extra as Map<String, dynamic>? ?? {};
          return VerifyOtpScreen(email: extra['email'] as String? ?? '', purpose: extra['purpose'] as String? ?? 'register');
        },
      ),
      GoRoute(path: '/forgot-password', builder: (context, state) => const ForgotPasswordScreen()),
      GoRoute(
        path: '/reset-password',
        builder: (context, state) {
          final extra = state.extra as Map<String, dynamic>? ?? {};
          return ResetPasswordScreen(email: extra['email'] as String? ?? '', code: extra['code'] as String? ?? '');
        },
      ),

      // الحاوية الرئيسية (بعد تسجيل الدخول)
      GoRoute(path: '/home', builder: (context, state) => const MainShell()),

      // الإعلانات
      GoRoute(
        path: '/animal/:id',
        builder: (context, state) {
          final id = int.parse(state.pathParameters['id']!);
          final extra = state.extra as Map<String, dynamic>?;
          return AnimalDetailsScreen(animalId: id, openComments: extra?['openComments'] as bool? ?? false);
        },
      ),
      GoRoute(path: '/add-animal', builder: (context, state) => const AddAnimalScreen()),
      GoRoute(path: '/search', builder: (context, state) => const SearchScreen()),

      // الملف الشخصي
      GoRoute(path: '/edit-profile', builder: (context, state) => const EditProfileScreen()),
      GoRoute(
        path: '/seller/:id',
        builder: (context, state) => ProfileScreen(userId: int.parse(state.pathParameters['id']!)),
      ),

      // الدردشة
      GoRoute(path: '/chat', builder: (context, state) => const ConversationsListScreen()),
      GoRoute(
        path: '/chat/:id',
        builder: (context, state) => ChatConversationScreen(conversationId: int.parse(state.pathParameters['id']!)),
      ),
      GoRoute(
        path: '/chat/start/:sellerId',
        builder: (context, state) {
          final sellerId = int.parse(state.pathParameters['sellerId']!);
          final animalId = int.tryParse(state.uri.queryParameters['animalId'] ?? '');
          return ChatStarterScreen(sellerId: sellerId, animalId: animalId);
        },
      ),

      // الإشعارات
      GoRoute(path: '/notifications', builder: (context, state) => const NotificationsScreen()),

      // الإعدادات والصفحات القانونية
      GoRoute(path: '/settings', builder: (context, state) => const SettingsScreen()),
      GoRoute(path: '/change-password', builder: (context, state) => const ChangePasswordScreen()),
      GoRoute(path: '/privacy-policy', builder: (context, state) => const PrivacyPolicyScreen()),
      GoRoute(path: '/terms', builder: (context, state) => const TermsOfServiceScreen()),
    ],
  );
});

/// شاشة وسيطة: تبدأ محادثة مع بائع (أو تفتح المحادثة الموجودة مسبقاً) ثم تنتقل تلقائياً إليها
class ChatStarterScreen extends ConsumerStatefulWidget {
  final int sellerId;
  final int? animalId;

  const ChatStarterScreen({super.key, required this.sellerId, this.animalId});

  @override
  ConsumerState<ChatStarterScreen> createState() => _ChatStarterScreenState();
}

class _ChatStarterScreenState extends ConsumerState<ChatStarterScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  Future<void> _start() async {
    try {
      final conversation = await ref
          .read(chatRepositoryProvider)
          .startConversation(userId: widget.sellerId, animalId: widget.animalId);
      if (!mounted) return;
      context.pushReplacement('/chat/${conversation.id}');
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: AppLoader());
  }
}
