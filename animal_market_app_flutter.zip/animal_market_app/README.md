# 🐐 بيع حيوانات — تطبيق Flutter

تطبيق موبايل لبيع وشراء الحيوانات والمواشي والطيور في العراق، مبني بمعمارية نظيفة (Clean Architecture)
مع دعم كامل للغة العربية (RTL) والوضع الداكن.

## 🧱 التقنيات
- Flutter 3.x + Dart 3
- إدارة الحالة: Riverpod
- التنقل: go_router
- الشبكة: Dio + WebSocket (web_socket_channel) للدردشة والإشعارات الفورية
- تخزين آمن: flutter_secure_storage (لتوكنات JWT)

## 📂 هيكل المشروع (Feature-first Clean Architecture)
```
lib/
├── main.dart
├── core/
│   ├── constants/        # ثوابت التطبيق ومسارات API
│   ├── theme/             # الثيمات (فاتح/داكن) + مزود الثيم
│   ├── network/           # عميل Dio، تخزين التوكن، إعدادات البيئة
│   ├── router/             # go_router + الشاشة الرئيسية (Bottom Nav)
│   └── widgets/            # عناصر واجهة مشتركة
└── features/
    ├── splash/              # شاشة البداية
    ├── onboarding/          # تعريف بالتطبيق للمستخدم الجديد
    ├── auth/                 # تسجيل، دخول، OTP، استعادة كلمة المرور
    ├── home/                  # الصفحة الرئيسية (Feed) + نماذج ومستودعات الإعلانات
    ├── animal_details/       # تفاصيل الإعلان والتعليقات
    ├── add_animal/            # إضافة إعلان جديد (حتى 10 صور)
    ├── search/                 # البحث والفلاتر المتقدمة
    ├── profile/                # الملف الشخصي وصفحة البائع
    ├── chat/                    # قائمة المحادثات + الدردشة الفورية عبر WebSocket
    ├── notifications/           # الإشعارات
    ├── favorites/                # المفضلة
    ├── settings/                  # الإعدادات، الوضع الداكن، تغيير كلمة المرور
    └── legal/                      # سياسة الخصوصية وشروط الاستخدام
```

## ⚙️ التشغيل

### 1) المتطلبات
- Flutter SDK 3.19+ مثبّت (`flutter --version`)
- سيرفر الـ Backend (Django) قيد التشغيل - راجع مشروع `animal_market_backend`

### 2) تثبيت الحزم
```bash
flutter pub get
```

### 3) ضبط رابط الـ API
الرابط الافتراضي هو `http://127.0.0.1:8000/api`. لتغييره عند التشغيل:
```bash
flutter run --dart-define=API_BASE_URL=http://192.168.1.10:8000/api --dart-define=WS_BASE_URL=ws://192.168.1.10:8000/ws
```
> ملاحظة: عند التجربة على جهاز حقيقي أو محاكي، استبدل `127.0.0.1` بعنوان IP الفعلي لجهاز السيرفر
> على نفس الشبكة (محاكي Android يستخدم `10.0.2.2` للإشارة إلى localhost المضيف).

### 4) إضافة الخطوط والأيقونات
- ضع ملفات خط Cairo (Regular/Bold/SemiBold) داخل `assets/fonts/` (راجع الملاحظة داخل المجلد)
- ضع شعار التطبيق (وجه ماعز) في `assets/icons/app_icon.png` وشاشة البداية في `assets/icons/splash_logo.png`

### 5) توليد أيقونة التطبيق وشاشة البداية (بعد إضافة الصور)
```bash
flutter pub run flutter_launcher_icons
flutter pub run flutter_native_splash:create
```

### 6) تشغيل التطبيق
```bash
flutter run
```

### 7) بناء نسخة الإصدار (Release)
```bash
# Android (APK)
flutter build apk --release

# Android (App Bundle - لرفعه على Google Play)
flutter build appbundle --release

# iOS (يتطلب macOS + Xcode + حساب Apple Developer)
flutter build ios --release
```
> ملاحظة: بناء IPA موقّع فعلياً يتطلب شهادات وحساب Apple Developer، ولا يمكن توليده تلقائياً هنا.

## 🎨 دعم اللغة العربية والوضع الداكن
- التطبيق يفرض اتجاه RTL بالكامل عبر `Directionality` في `main.dart`
- الخط الأساسي: Cairo (خط عربي حديث وواضح)
- الوضع الداكن يُبدَّل من شاشة الإعدادات ويُحفظ محلياً عبر `shared_preferences`

## 🔌 نقاط الربط الرئيسية مع الـ Backend
كل مسارات الـ API معرّفة مركزياً في: `lib/core/constants/api_endpoints.dart`
لا حاجة لتعديل أي شاشة عند تغيير رابط السيرفر - فقط عدّل `EnvConfig` أو مرّر `--dart-define`.

## 🔧 ما يحتاج إكمالاً قبل الإنتاج (Production Checklist)
- [ ] إضافة ملفات خط Cairo الفعلية وأيقونة التطبيق (شعار وجه الماعز) في `assets/`
- [ ] إعداد Firebase Cloud Messaging للإشعارات Push الفعلية (المكتبات مضافة، ينقصها `google-services.json` و`GoogleService-Info.plist` الحقيقيين من Firebase Console)
- [ ] اختبار شامل على أجهزة Android/iOS حقيقية
- [ ] ضبط ATS/Network Security Config للسماح بـ HTTP في التطوير فقط (استخدم HTTPS في الإنتاج)

> ✅ رفع الصور داخل الدردشة مكتمل بالكامل (Backend + Flutter): الصورة تُرفع عبر `POST /api/chat/upload-image/`
> ثم يُرسل رابطها كرسالة عبر WebSocket تلقائياً - جرّب زر الصورة 🖼️ داخل شاشة المحادثة.

## ⚠️ ملاحظة مهمة عن Android و iOS
أضفنا يدوياً كل ملفات `android/` القياسية (build.gradle، AndroidManifest، MainActivity.kt، الأذونات...) وهي **جاهزة للعمل مباشرة**.

بالنسبة لـ iOS، أضفنا كل الملفات النصية القياسية (Info.plist، AppDelegate.swift، Podfile، Storyboards، Assets.xcassets)
**عدا ملف واحد**: `ios/Runner.xcodeproj/project.pbxproj` — وهو ملف مشروع Xcode الثنائي المعقّد الذي يربط كل شيء ببعضه
(المستهدفات build targets، مسارات الملفات بمعرّفات UUID داخلية، إعدادات التوقيع...). هذا الملف تحديداً **لا يمكن كتابته
يدوياً بأمان** لأن أي خطأ بسيط فيه يكسر فتح المشروع في Xcode بالكامل.

**الحل البسيط** (خطوة واحدة، على جهاز فيه Flutter مثبّت):
```bash
flutter create --platforms=ios --org com.baihaywanat .
```
هذا الأمر يولّد `project.pbxproj` الصحيح تلقائياً **دون** المساس بأي من ملفاتك الموجودة في `lib/`،
لأنه يكتشف أن مجلد `ios/` غير مكتمل فقط ويكمله. بعدها تقدر تفتح `ios/Runner.xcworkspace` في Xcode مباشرة.

بالنسبة لملف `android/gradlew` (سكربت تشغيل Gradle) - نفس الأمر أعلاه (بإضافة `--platforms=android`) يولّده أيضاً،
أو ببساطة افتح المشروع في Android Studio وهو يولّده تلقائياً عند أول فتح.

