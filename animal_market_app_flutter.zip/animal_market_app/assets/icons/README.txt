ضع هنا:
- app_icon.png (شعار وجه ماعز - 1024x1024) لأيقونة التطبيق
- app_icon_foreground.png (نسخة شفافة الخلفية لأيقونة Android التكيفية)
- splash_logo.png (لشاشة البداية native splash)
