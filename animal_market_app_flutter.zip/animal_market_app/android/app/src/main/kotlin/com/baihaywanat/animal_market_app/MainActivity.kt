package com.baihaywanat.animal_market_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
