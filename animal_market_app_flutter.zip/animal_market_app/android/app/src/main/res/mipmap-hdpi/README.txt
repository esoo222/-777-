سيُملأ هذا المجلد تلقائياً عند تشغيل:
flutter pub run flutter_launcher_icons
بعد وضع شعار وجه الماعز في assets/icons/app_icon.png
