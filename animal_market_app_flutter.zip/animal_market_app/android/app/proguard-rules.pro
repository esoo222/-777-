# قواعد ProGuard/R8 للحفاظ على عمل المكتبات الأساسية في وضع الإصدار (release)

# Flutter
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }

# Dio / OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# Firebase Messaging
-keep class com.google.firebase.messaging.** { *; }

# نماذج JSON (تجنب حذف أسماء الحقول عند التسلسل)
-keepattributes Signature
-keepattributes *Annotation*
