ضع هنا ملفات PNG لأيقونة التطبيق (شعار وجه الماعز) بالأحجام المذكورة في Contents.json
أو ببساطة نفّذ: flutter pub run flutter_launcher_icons
بعد وضع assets/icons/app_icon.png وسيولّدها تلقائياً.
